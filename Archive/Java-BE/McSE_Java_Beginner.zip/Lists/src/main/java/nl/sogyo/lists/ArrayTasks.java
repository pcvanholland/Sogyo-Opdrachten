/**
 * 
 */
package nl.sogyo.lists;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @author rvvugt
 *
 */
public class ArrayTasks {
	
	/**
	 * @param size
	 * @return
	 */
	public int[] generateWorkingIntArray(int size) {
		
		int[] resultArray = new int[size];
		
		for (int i = 0; i < size; i++) {
			resultArray[i] = new Random().nextInt(100);
		}
		
		return resultArray;
	}
	
	/**
	 * @return
	 */
	public String intArrayToString(int[] inputArray) {
		
		String result = "[";
		
		for (int item: inputArray) {
			result += item + ",";
		}
		
		if (result.length() > 1) {
			result = result.substring(0, result.length() - 1);
		}
		
		return result + "]";
	}
	
	/**
	 * @param inputArray
	 * @return
	 */
	private int[] bubbleSort(int[] inputArray) {

	    int arrayLength = inputArray.length;
	    int placeholder = 0;

	    for (int i = 0; i < arrayLength; i++) {
	        for (int j = 1; j < (arrayLength - i); j++) {

	            if (inputArray[j - 1] > inputArray[j]) {
	                placeholder = inputArray[j - 1];
	                inputArray[j - 1] = inputArray[j];
	                inputArray[j] = placeholder;
	            }
	        }
	    }
	    
	    return inputArray;
	}
	
	/**
	 * @param intputArray
	 * @return
	 */
	public int[] sortIntArray(int[] intputArray) {
		
		return this.bubbleSort(intputArray);
	}
	
	/**
	 * @param inputArray
	 * @return
	 */
	public int[] clone(int[] inputArray) {
		
		int[] resultArray = new int[inputArray.length];
		
		int index = 0;
		for (int number: inputArray) {
			resultArray[index] = number;
			index++;
		}
		
		return resultArray;
	}
	
	/**
	 * @param inputArray
	 * @return
	 */
	public int[] sortedCopyOfIntArray(int[] inputArray) {
		
		int[] resultArray = this.clone(inputArray);
//		Alternative to the line of code above.
//		int[] resultArray = inputArray.clone();
		return this.bubbleSort(resultArray);
	}
	
	/**
	 * @param inputArray
	 * @return
	 */
	public int retrieveHighestNumber(int[] inputArray) {
		
		int[] resultArray = this.clone(inputArray);
		this.bubbleSort(resultArray);
		return resultArray[resultArray.length - 1];
	}
	
	/**
	 * @param numberOfItems
	 * @return
	 */
	public int[] retrieveHighestNumbers(int[] inputArray, int numberOfItems) {
		
		int[] resultArray = new int[numberOfItems];
		int[] tempArray = this.clone(inputArray);
		this.bubbleSort(tempArray);
		
		int index = 0;
		for (int i = numberOfItems; i > 0; i--) {
			resultArray[index] = tempArray[tempArray.length - i];
			index++;
		}
		
		return resultArray;
	}
	
	/**
	 * @param inputArray
	 * @return
	 */
	public int retrieveLowestNumber(int[] inputArray) {
		
		int[] resultArray = this.clone(inputArray);
		this.bubbleSort(resultArray);
		return resultArray[0];
	}
	
	/**
	 * @param numberOfItems
	 * @return
	 */
	public int[] retrieveLowestNumbers(int[] inputArray, int numberOfItems) {
		
		int[] resultArray = new int[numberOfItems];
		int[] tempArray = this.clone(inputArray);
		this.bubbleSort(tempArray);
		
		for (int i = 0; i < numberOfItems; i++) {
			resultArray[i] = tempArray[i];
		}
		
		return resultArray;
	}
	
	/**
	 * @param list
	 * @return
	 */
	private int[] listToIntArray(List<Integer> list) {
		
		int[] resultArray = new int[list.size()];
		
		int index = 0;
		for (Integer number: list) {
			resultArray[index] = number;
			index++;
		}
		
		return resultArray;
	}
	
	/**
	 * @param inputArray
	 * @return
	 */
	public int[] retrieveEvenNumbers(int[] inputArray) {
		
		ArrayList<Integer> evenNumbersList = new ArrayList<Integer>();
		
		for (int number: inputArray) {
			if (number % 2 == 0) {
				evenNumbersList.add(number);
			}
		}
		
		return this.listToIntArray(evenNumbersList);
//		Alternative to the line of code above.
//		return evenNumbersArray.stream().mapToInt(i->i).toArray();
	}
	
	/**
	 * @param inputArray
	 * @return
	 */
	public int[] retrieveUnevenNumbers(int[] inputArray) {
		
		ArrayList<Integer> unevenNumbersList = new ArrayList<Integer>();
		
		for (int number: inputArray) {
			if (number % 2 != 0) {
				unevenNumbersList.add(number);
			}
		}
		
		return this.listToIntArray(unevenNumbersList);
	}
	
	/**
	 * @param inputArray
	 * @param number
	 * @return
	 */
	private boolean contains(int[] inputArray, int number) {
		
		for (int item: inputArray) {
			if (number == item) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * @param inputArray
	 * @param divisor
	 * @return
	 */
	public int[] retrieveNumbersDividableBy(int[] inputArray, int divisor) {
		
		ArrayList<Integer> resultList = new ArrayList<Integer>();
		
		for (int number: inputArray) {
			if (number % divisor == 0) {
				resultList.add(number);
			}
		}
		
		return this.listToIntArray(resultList);
	}
	
	/**
	 * @param inputArray
	 * @param divisors
	 * @return
	 */
	public int[] retrieveNumbersDividableBy(int[] inputArray, int[] divisors) {
		
		ArrayList<Integer> resultList = new ArrayList<Integer>();
		
		for (int number: inputArray) {
			for (int divisor: divisors) {
				if (number % divisor == 0) {
					resultList.add(number);
					break;
				}
			}
		}
		
		return this.listToIntArray(resultList);
	}
	
	/**
	 * @param inputArray
	 * @param divisor
	 * @return
	 */
	public int[] retrieveNumbersNotDividableBy(int[] inputArray, int divisor) {
		
		ArrayList<Integer> resultList = new ArrayList<Integer>();
		
		for (int number: inputArray) {
			if (number % divisor != 0) {
				resultList.add(number);
			}
		}
		
		return this.listToIntArray(resultList);
	}
	
	/**
	 * @param inputArray
	 * @param divisors
	 * @return
	 */
	public int[] retrieveNumbersNotDividableBy(int[] inputArray, int[] divisors) {
		
		ArrayList<Integer> resultList = new ArrayList<Integer>();
		int[] dividableByArray = this.retrieveNumbersDividableBy(inputArray, divisors);
		
		for (int number: inputArray) {
			if (! this.contains(dividableByArray, number)) {
				resultList.add(number);
			}
		}
		
		return this.listToIntArray(resultList);
	}
	
}
