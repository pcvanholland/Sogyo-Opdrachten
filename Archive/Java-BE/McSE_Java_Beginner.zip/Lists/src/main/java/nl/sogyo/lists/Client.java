/**
 * 
 */
package nl.sogyo.lists;



/**
 * @author rvvugt
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		ArrayTasks arrayTasks = new ArrayTasks();
		
		// Assignment 1
		int[] workingArray = arrayTasks.generateWorkingIntArray(10);
		System.out.println("Working array is: " + arrayTasks.intArrayToString(workingArray));
		
		// Assignment 2
		int highestNumber = arrayTasks.retrieveHighestNumber(workingArray);
		System.out.println("Highest number is: " + highestNumber);
		int lowestNumber = arrayTasks.retrieveLowestNumber(workingArray);
		System.out.println("Lowest number is: " + lowestNumber);
		
		// Assignment 3
		int[] highestNumbers = arrayTasks.retrieveHighestNumbers(workingArray, 2);
		System.out.println("Highest numbers are: " + arrayTasks.intArrayToString(highestNumbers));
//		Alternative to the line of code above.
//		System.out.println("Highest numbers are: " + Arrays.toString(highestNumbers));
		int[] lowestNumbers = arrayTasks.retrieveLowestNumbers(workingArray, 2);
		System.out.println("Lowest numbers are: " + arrayTasks.intArrayToString(lowestNumbers));
		
		// Assignment 4
		int[] evenNumbers = arrayTasks.retrieveEvenNumbers(workingArray);
		System.out.println("Even numbers are: " + arrayTasks.intArrayToString(evenNumbers));
		int[] unevenNumbers = arrayTasks.retrieveUnevenNumbers(workingArray);
		System.out.println("Uneven numbers are: " + arrayTasks.intArrayToString(unevenNumbers));
		
		// Assignment 5
		int[] dividableBy2 = arrayTasks.retrieveNumbersDividableBy(workingArray, 2);
		System.out.println("Numbers dividable by 2 are: " + arrayTasks.intArrayToString(dividableBy2));
		int[] dividableBy3 = arrayTasks.retrieveNumbersDividableBy(workingArray, 3);
		System.out.println("Numbers dividable by 3 are: " + arrayTasks.intArrayToString(dividableBy3));
		int[] dividableBy5 = arrayTasks.retrieveNumbersDividableBy(workingArray, 5);
		System.out.println("Numbers dividable by 5 are: " + arrayTasks.intArrayToString(dividableBy5));
		int[] dividableBy = arrayTasks.retrieveNumbersDividableBy(workingArray, new int[] {2, 3, 5});
		System.out.println("Union of numbers dividable by 2, 3, and 5 are: " + arrayTasks.intArrayToString(dividableBy));
		int[] notDividableBy = arrayTasks.retrieveNumbersNotDividableBy(workingArray, new int[] {2, 3, 5});
		System.out.println("Remaining numbers are: " + arrayTasks.intArrayToString(notDividableBy));
		
		// Assignment 6
		int[] sortedArray = arrayTasks.sortedCopyOfIntArray(workingArray);
		System.out.println("Sorted array is: " + arrayTasks.intArrayToString(sortedArray));
	}
	
}
