/**
 * 
 */
package nl.sogyo.lists;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class ArrayTasksTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void generateWorkingIntArrayTest() {

		int[] resultArray = new ArrayTasks().generateWorkingIntArray(10);
		assertEquals(10, resultArray.length);
	}

	@Test
	public void highestNumberTest() {

		int highestNumber = new ArrayTasks().retrieveHighestNumber(new int[] {1, 5, 10, 22});
		assertEquals(22, highestNumber);
	}

	@Test
	public void lowestNumberTest() {

		int lowestNumber = new ArrayTasks().retrieveLowestNumber(new int[] {3, 5, 10, 22});
		assertEquals(3, lowestNumber);
	}

	@Test
	public void highestNumbersTest() {

		int[] highestNumbers = new ArrayTasks().retrieveHighestNumbers(new int[] {5, 47, 3, 10, 22, 7, 36, 1}, 2);
		assertEquals(2, highestNumbers.length);
		assertEquals(36, highestNumbers[0]);
		assertEquals(47, highestNumbers[1]);
	}

	@Test
	public void lowestNumbersTest() {

		int[] lowestNumbers = new ArrayTasks().retrieveLowestNumbers(new int[] {5, 47, 3, 10, 22, 7, 36, 1}, 2);
		assertEquals(2, lowestNumbers.length);
		assertEquals(1, lowestNumbers[0]);
		assertEquals(3, lowestNumbers[1]);
	}

	@Test
	public void evenNumbersTest() {

		int[] evenNumbers = new ArrayTasks().retrieveEvenNumbers(new int[] {5, 47, 3, 10, 22, 7, 36, 1});
		assertEquals(3, evenNumbers.length);
		assertEquals(10, evenNumbers[0]);
		assertEquals(22, evenNumbers[1]);
		assertEquals(36, evenNumbers[2]);
	}

	@Test
	public void unevenNumbersTest() {

		int[] unevenNumbers = new ArrayTasks().retrieveUnevenNumbers(new int[] {5, 47, 3, 10, 22, 7, 36, 1});
		assertEquals(5, unevenNumbers.length);
		assertEquals(5, unevenNumbers[0]);
		assertEquals(3, unevenNumbers[2]);
		assertEquals(1, unevenNumbers[4]);
	}

	@Test
	public void dividableBy2Test() {

		int[] dividableBy2 = new ArrayTasks().retrieveNumbersDividableBy(new int[] {5, 47, 3, 10, 22, 7, 36, 1}, 2);
		assertEquals(3, dividableBy2.length);
		assertEquals(10, dividableBy2[0]);
		assertEquals(22, dividableBy2[1]);
		assertEquals(36, dividableBy2[2]);
	}

	@Test
	public void dividableBy3Test() {

		int[] dividableBy3 = new ArrayTasks().retrieveNumbersDividableBy(new int[] {5, 47, 3, 10, 22, 7, 36, 1}, 3);
		assertEquals(2, dividableBy3.length);
		assertEquals(3, dividableBy3[0]);
		assertEquals(36, dividableBy3[1]);
	}

	@Test
	public void dividableBy5Test() {

		int[] dividableBy5 = new ArrayTasks().retrieveNumbersDividableBy(new int[] {5, 47, 3, 10, 22, 7, 36, 1}, 5);
		assertEquals(2, dividableBy5.length);
		assertEquals(5, dividableBy5[0]);
		assertEquals(10, dividableBy5[1]);
	}

	@Test
	public void dividableByTest() {

		int[] dividableBy = new ArrayTasks().retrieveNumbersDividableBy(new int[] {5, 47, 3, 10, 22, 7, 36, 1}, new int[] {2, 3, 5});
		assertEquals(5, dividableBy.length);
		assertEquals(5, dividableBy[0]);
		assertEquals(36, dividableBy[4]);
	}

	@Test
	public void notDividableByTest() {

		int[] notDividableBy = new ArrayTasks().retrieveNumbersNotDividableBy(new int[] {5, 47, 3, 10, 22, 7, 36, 1}, new int[] {2, 3, 5});
		assertEquals(3, notDividableBy.length);
		assertEquals(47, notDividableBy[0]);
		assertEquals(7, notDividableBy[1]);
		assertEquals(1, notDividableBy[2]);
	}

	@Test
	public void sortTest() {

		int[] sorted = new ArrayTasks().sortedCopyOfIntArray(new int[] {5, 47, 3, 10, 22, 7, 36, 1});
		assertEquals(8, sorted.length);
		assertEquals(1, sorted[0]);
		assertEquals(5, sorted[2]);
		assertEquals(10, sorted[4]);
		assertEquals(47, sorted[7]);
	}

}
