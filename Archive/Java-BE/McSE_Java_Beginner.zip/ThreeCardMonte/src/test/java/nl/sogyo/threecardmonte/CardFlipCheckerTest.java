/**
 * 
 */
package nl.sogyo.threecardmonte;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class CardFlipCheckerTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void checkAceInMiddleTest() {
		
		CardFlipChecker cardFlipChecker = new CardFlipChecker();
		char[] cards = new char[] {'J', 'A', 'K'};
		assertTrue(cardFlipChecker.checkCardFlip(cards, 2));
	}

	@Test
	public void checkAceInLeftTest() {
		
		CardFlipChecker cardFlipChecker = new CardFlipChecker();
		char[] cards = new char[] {'A', 'J', 'K'};
		assertTrue(cardFlipChecker.checkCardFlip(cards, 1));
	}

	@Test
	public void checkAceInRightTest() {
		
		CardFlipChecker cardFlipChecker = new CardFlipChecker();
		char[] cards = new char[] {'J', 'K', 'A'};
		assertTrue(cardFlipChecker.checkCardFlip(cards, 3));
	}

	@Test
	public void checkWrongChoiceTest() {
		
		CardFlipChecker cardFlipChecker = new CardFlipChecker();
		char[] cards = new char[] {'J', 'K', 'A'};
		assertFalse(cardFlipChecker.checkCardFlip(cards, 1));
		assertFalse(cardFlipChecker.checkCardFlip(cards, 2));
	}

}
