/**
 * 
 */
package nl.sogyo.threecardmonte;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * @author rvvugt
 *
 */
public class CardFlipChecker {

	private char[] cards = new char[] { 'J', 'K', 'A' };

	/**
	 * @param guess
	 * @return
	 */
	public boolean checkCardFlip(int guess) {
		
		// The line of code below doesn't seem to work.
//		Collections.shuffle(Arrays.asList(this.cards));
		
		return this.checkCardFlip(this.shuffleArray(this.cards), guess);
	}

	/**
	 * @param cards
	 * @param guess
	 * @return
	 */
	public boolean checkCardFlip(char[] cards, int guess) {

		if ('A' == cards[guess - 1]) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Implementing Fisher�Yates shuffle
	 * 
	 * @param sourceArray
	 * @return
	 * @see https://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle
	 */
	private char[] shuffleArray(char[] sourceArray) {
	    
	    Random random = ThreadLocalRandom.current();
	    for (int i = sourceArray.length - 1; i > 0; i--) {
	    	
	      int index = random.nextInt(i + 1);
	      char temp = sourceArray[index];
	      sourceArray[index] = sourceArray[i];
	      sourceArray[i] = temp;
	    }
	    
	    return sourceArray;
	  }

	/**
	 * @return
	 */
	public char[] getCards() {

		return this.cards;
	}

}
