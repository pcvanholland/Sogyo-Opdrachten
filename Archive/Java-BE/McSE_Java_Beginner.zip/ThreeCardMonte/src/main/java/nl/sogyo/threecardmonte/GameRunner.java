/**
 * 
 */
package nl.sogyo.threecardmonte;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class GameRunner {

	private Scanner scanner;
	private int result = 0;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		GameRunner gameRunner = new GameRunner();
		gameRunner.initialize();
		gameRunner.play();
	}
	
	/**
	 * 
	 */
	private void initialize() {
		
		this.scanner = this.openScannerResource();
		
		System.out.println("This is Three-Card Monte, choose which one is the ACE.");
		System.out.println("Enter '-1' to exit the game.");
		System.out.println(this.printBlankCards());
	}
	
	/**
	 * 
	 */
	private void play() {
		
		int guess = -1;
		
		do {
			guess = this.askUserGuess();
			this.processGuess(guess);
		} while (guess != -1);
        
        try {
        	this.closeScannerResource(this.scanner);
        } catch ( IOException ioe ) {
        	System.err.println(ioe.getMessage());
        }
	}
		
	/**
	 * @param leapYear
	 */
	private void processGuess(int guess) {
		
        CardFlipChecker cardFlipChecker = new CardFlipChecker();
        boolean correctGuess = cardFlipChecker.checkCardFlip(guess);
        
        System.out.println(this.printCards(cardFlipChecker.getCards(), guess));
        
        System.out.println("");
        if (correctGuess) {
        	System.out.println("Correct!");
        	this.result++;
        } else {
        	System.out.println("Incorrect!");
        	this.result--;
        }
        
        System.out.println(this.printWinningStreak());
        System.out.println("");
	}

	/**
	 * @return
	 */
	private int askUserGuess() {
		
		int guess = -1;
		
		System.out.print("Which one is the ace (1, 2, or 3)? ");
		
        try {
        	guess = this.scanner.nextInt();
        } catch (Exception e) {
        	System.err.println("Invalid Format!");
        }
        
		if ( guess == -1 ) {
			System.err.println("Thank you for playing. Please come again!");
			System.exit(0);
		}
		
        return guess;
	}
	
	/**
	 * @param cards
	 * @param guess
	 * @return
	 */
	private String printCards(char[] cards, int guess) {
		
		StringBuffer sb = new StringBuffer();
		sb.append("\n");
		
		for (int i = 0; i < 3; i++) {
			if (i == (guess - 1)) {
				sb.append(cards[i]);
				sb.append(cards[i]);
			} else if ('A' == cards[i]) {
				sb.append(cards[i]);
				sb.append(cards[i]);				
			} else {
				sb.append("##");
			}
			sb.append(" ");
		}
		
		String result = sb.toString() + sb.toString();
		return result;
	}
	
	/**
	 * @return
	 */
	private String printBlankCards() {
		
		StringBuffer sb = new StringBuffer();
		sb.append("\n");
		sb.append("## ## ##");
		sb.append("\n");
		sb.append("## ## ##");
		sb.append("\n");
		
		return sb.toString();
	}
	
	/**
	 * @return
	 */
	private String printWinningStreak() {
		
		if (this.result >= 0) {
			return "Your winning streak is " + this.result;
		} else {
			return "Unfortunately your losing streak is " + this.result;
		}
	}
	
	/**
	 * @return
	 */
	private Scanner openScannerResource() {
		
		return new Scanner(System.in);
	}
	
	/**
	 * @param resource
	 */
	private void closeScannerResource(Closeable resource) throws IOException {
		
		resource.close();
	}
	
}
