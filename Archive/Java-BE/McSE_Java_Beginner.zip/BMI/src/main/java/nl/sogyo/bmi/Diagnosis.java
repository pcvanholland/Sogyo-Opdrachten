/**
 * 
 */
package nl.sogyo.bmi;

/**
 * @author rvvugt
 *
 */
public enum Diagnosis {
	
	Underweight,
	Normal_weight,
	Overweight ,
	Obese
}
