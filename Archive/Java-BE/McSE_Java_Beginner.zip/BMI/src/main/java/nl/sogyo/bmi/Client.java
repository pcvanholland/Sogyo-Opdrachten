/**
 * 
 */
package nl.sogyo.bmi;

import java.io.Closeable;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class Client {
	
	private Scanner scanner;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Client client = new Client();
		client.scanner = client.openScannerResource();
		
		int weight = 0;
		int height = 0;
		
		weight = client.askPersonsWeight(client.scanner);
		height = client.askPersonsHeight(client.scanner);
        
        client.processBMIDiagnosis(weight, height);
        
        try {
        	client.closeScannerResource(client.scanner);
        } catch ( IOException ioe ) {
        	System.err.println(ioe.getMessage());
        }
	}
	
	/**
	 * @param weight
	 * @param height
	 */
	private void processBMIDiagnosis(int weight, int height) {
		
		BMICalculator bmiCalculator = new BMICalculator();
		double bmi = bmiCalculator.calculateBMI(weight, height);
		Diagnosis diagnosis = bmiCalculator.giveDiagnosis(bmi);
		
		DecimalFormat formatter = new DecimalFormat("#0.0");
		
		StringBuffer sb = new StringBuffer();
		sb.append("Based on your weight of ");
		sb.append(weight);
		sb.append(" (kg) and your height of ");
		sb.append(height);
		sb.append(" (cm) you BMI is ");
		sb.append(formatter.format(bmi));
		sb.append(" and the diagnosis is: ");
		sb.append(diagnosis);
		System.out.println(sb.toString());
	}

	/**
	 * @param scanner
	 * @return
	 */
	private int askPersonsWeight(Scanner scanner) {
		
		int weight = 0;
		
		System.out.println("Please enter your weight in kilograms: ");
		
		try {
			weight = scanner.nextInt();
        } catch (Exception e) {
        	System.err.println("Invalid Format! Please try again!");
        }
		
		if ( weight == 0 ) {
			System.err.println("Invalid input. Please try again!");
			System.exit(0);
		}
		
        return weight;
	}
	
	/**
	 * @param scanner
	 * @return
	 */
	private int askPersonsHeight(Scanner scanner) {
		
		int height = 0;
		
		System.out.println("Please enter your height in centimeters: ");
		
		try {
			height = scanner.nextInt();
        } catch (Exception e) {
        	System.err.println("Invalid Format! Please try again!");
        }
		
		if ( height == 0 ) {
			System.err.println("Invalid input. Please try again!");
			System.exit(0);
		}
		
        return height;
	}
		
	/**
	 * @return
	 */
	private Scanner openScannerResource() {
		
		return new Scanner(System.in);
	}
	
	/**
	 * @param resource
	 */
	private void closeScannerResource(Closeable resource) throws IOException {
		
		resource.close();
	}
	
}
