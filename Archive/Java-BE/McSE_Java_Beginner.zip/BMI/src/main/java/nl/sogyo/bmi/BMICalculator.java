/**
 * 
 */
package nl.sogyo.bmi;

/**
 * @author rvvugt
 *
 */
public class BMICalculator {
	
	/**
	 * @param weight
	 * @param height
	 * @return
	 */
	public double calculateBMI(int weight, int height) {
		
		/*
		 * The line of code below will not work because
		 * the division by 10000 will be treated as an
		 * integer division. To get the right result 
		 * add a 'D' after the number to indicate that 
		 * the number is a decimal number.
		 */
//		return weight / ( (height * height) / 10000);
		return weight / ( (height * height) / 10000D);
	}
	
	/**
	 * @param bmi
	 * @return
	 */
	public Diagnosis giveDiagnosis(double bmi) {
		
		Diagnosis diagnosis = null;
		
		if (bmi < 18.5) {
			diagnosis = Diagnosis.Underweight;
		} else if (bmi < 25) {
			diagnosis = Diagnosis.Normal_weight;
		} else if (bmi < 30) {
			diagnosis = Diagnosis.Overweight;
		} else {
			diagnosis = Diagnosis.Obese;
		}
		
		return diagnosis;
	}
	
}
