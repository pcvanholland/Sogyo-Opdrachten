/**
 * 
 */
package nl.sogyo.bmi;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class BMICalculatorTest {
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void calculateBMI45Over153Test() {
		
		BMICalculator bmiCalculator = new BMICalculator();
		assertEquals(19.2, bmiCalculator.calculateBMI(45, 153), 0.1);
	}

	@Test
	public void diagnose19_2Test() {
		
		BMICalculator bmiCalculator = new BMICalculator();
		assertEquals(Diagnosis.Normal_weight, bmiCalculator.giveDiagnosis(19.2));
	}

	@Test
	public void calculateBMI34Over159Test() {
		
		BMICalculator bmiCalculator = new BMICalculator();
		assertEquals(13.4, bmiCalculator.calculateBMI(34, 159), 0.1);
	}

	@Test
	public void diagnose13_4Test() {
		
		BMICalculator bmiCalculator = new BMICalculator();
		assertEquals(Diagnosis.Underweight, bmiCalculator.giveDiagnosis(13.4));
	}

	@Test
	public void calculateBMI80Over176Test() {
		
		BMICalculator bmiCalculator = new BMICalculator();
		assertEquals(25.8, bmiCalculator.calculateBMI(80, 176), 0.1);
	}

	@Test
	public void diagnose25_8Test() {
		
		BMICalculator bmiCalculator = new BMICalculator();
		assertEquals(Diagnosis.Overweight, bmiCalculator.giveDiagnosis(25.8));
	}

	@Test
	public void calculateBMI128Over184Test() {
		
		BMICalculator bmiCalculator = new BMICalculator();
		assertEquals(37.8, bmiCalculator.calculateBMI(128, 184), 0.1);
	}

	@Test
	public void diagnose37_8Test() {
		
		BMICalculator bmiCalculator = new BMICalculator();
		assertEquals(Diagnosis.Obese, bmiCalculator.giveDiagnosis(37.8));
	}

}
