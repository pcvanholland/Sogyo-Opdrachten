/**
 * 
 */
package nl.sogyo.collatz;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Client client = new Client();
        int collatzNumber = -1;
		
        try {
        	collatzNumber = client.readInput();
        } catch (IOException ioe) {
        	System.out.println(ioe.getMessage());
        }
        
        if (collatzNumber < 0) {
        	System.err.println("The number entered should be a positive number!");
        	System.exit(0);
        }
                
        client.processCollatzConjecture(collatzNumber);
	}
	
	/**
	 * @param collatzNumber
	 */
	private void processCollatzConjecture(int collatzNumber) {
		
        CollatzConjecture collatzConjecture = new CollatzConjecture();
        String result = collatzConjecture.calculateSequence(collatzNumber);
        
        System.out.println("The calculated Collatz sequence is: " + result);
	}

	/**
	 * @return
	 */
	private int readInput() throws IOException {
		
		int collatzNumber = 0;
		System.out.print("Enter a positive number: ");
		
		Scanner scanner = new Scanner(System.in);
		Closeable resource = scanner;
        try {
        	collatzNumber = scanner.nextInt();
        } catch (Exception e) {
        	System.err.println("Invalid Format!");
        } finally {
        	resource.close();
        }
		
        return collatzNumber;
	}
	
}
