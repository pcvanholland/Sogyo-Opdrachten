/**
 * 
 */
package nl.sogyo.collatz;

/**
 * @author rvvugt
 *
 */
public class CollatzConjecture {

	private static final String SEPARATOR = ", ";
	
	/**
	 * @param year
	 * @return
	 */
	public String calculateSequence(int collatzNumber) {
		
		StringBuffer sb = new StringBuffer();
		sb.append(collatzNumber);
		
		while (collatzNumber != 1) {
			
			collatzNumber = this.calculateNextNumber(collatzNumber);
			sb.append(CollatzConjecture.SEPARATOR);
			sb.append(collatzNumber);
		}
		
		return sb.toString();
	}
	
	/**
	 * @param collatzNumber
	 * @return
	 */
	private int calculateNextNumber(int collatzNumber) {
		
		if (collatzNumber % 2 == 0) {
			return collatzNumber / 2;
		} else {
			return (collatzNumber * 3) + 1;
		}
	}
	
}
