/**
 * 
 */
package nl.sogyo.collatz;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import nl.sogyo.collatz.CollatzConjecture;

/**
 * @author rvvugt
 *
 */
public class CollatzConjectureTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void startNr5Test() {
		CollatzConjecture collatzConjecture = new CollatzConjecture();
		assertTrue("5, 16, 8, 4, 2, 1".equalsIgnoreCase(collatzConjecture.calculateSequence(5)));
	}

	@Test
	public void startNr7Test() {
		CollatzConjecture collatzConjecture = new CollatzConjecture();
		assertTrue("7, 22, 11, 34, 17, 52, 26, 13, 40, 20, 10, 5, 16, 8, 4, 2, 1".equalsIgnoreCase(collatzConjecture.calculateSequence(7)));
	}

	@Test
	public void startNr11Test() {
		CollatzConjecture collatzConjecture = new CollatzConjecture();
		assertTrue("11, 34, 17, 52, 26, 13, 40, 20, 10, 5, 16, 8, 4, 2, 1".equalsIgnoreCase(collatzConjecture.calculateSequence(11)));
	}

	@Test
	public void startNr12Test() {
		CollatzConjecture collatzConjecture = new CollatzConjecture();
		assertTrue("12, 6, 3, 10, 5, 16, 8, 4, 2, 1".equalsIgnoreCase(collatzConjecture.calculateSequence(12)));
	}

}
