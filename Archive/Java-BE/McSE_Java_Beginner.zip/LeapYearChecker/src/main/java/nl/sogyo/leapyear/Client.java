/**
 * 
 */
package nl.sogyo.leapyear;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Client client = new Client();
        int leapYear = -1;
		
        try {
        	leapYear = client.askYear();
        } catch (IOException ioe) {
        	System.out.println(ioe.getMessage());
        }
        
        if (leapYear < 0) {
        	System.err.println("Year should be a positive number!");
        	System.exit(0);
        }
        
        client.processLeapYear(leapYear);
	}
	
	/**
	 * @param leapYear
	 */
	private void processLeapYear(int leapYear) {
		
        LeapYearChecker leapYearChecker = new LeapYearChecker();
        
        if (leapYearChecker.isLeapYear(leapYear)) {
        	System.out.println(leapYear + " is a leap year");
        } else {
        	System.out.println(leapYear + " is NOT a leap year");
        }
	}

	/**
	 * @return
	 */
	private int askYear() throws IOException {
		
		int leapYear = -1;
		System.out.print("Enter year: ");
		
		Scanner scanner = new Scanner(System.in);
		Closeable resource = scanner;
        try {
        	leapYear = scanner.nextInt();
        } catch (Exception e) {
        	System.err.println("Invalid Format!");
        } finally {
        	resource.close();
        }
		
        return leapYear;
	}
	
}
