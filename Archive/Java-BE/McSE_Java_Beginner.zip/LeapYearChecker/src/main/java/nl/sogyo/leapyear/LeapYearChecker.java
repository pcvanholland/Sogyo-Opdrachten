/**
 * 
 */
package nl.sogyo.leapyear;

/**
 * @author rvvugt
 *
 */
public class LeapYearChecker {

	/**
	 * @param year
	 * @return
	 */
	public boolean isLeapYear(int year) {
		
		boolean leapYear = false;
		
		if (year % 400 == 0) {
			leapYear = true;
		} else if (year % 100 != 0 && year % 4 == 0) {
			leapYear = true;
		}
		
		return leapYear;
	}
	
}
