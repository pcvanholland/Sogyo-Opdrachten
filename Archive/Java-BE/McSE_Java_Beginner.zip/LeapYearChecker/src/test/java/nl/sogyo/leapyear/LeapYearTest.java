/**
 * 
 */
package nl.sogyo.leapyear;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class LeapYearTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void isLeapYear1808Test() {
		LeapYearChecker leapYearChecker = new LeapYearChecker();
		assertTrue(leapYearChecker.isLeapYear(1808));
	}

	@Test
	public void isLeapYear2352Test() {
		LeapYearChecker leapYearChecker = new LeapYearChecker();
		assertTrue(leapYearChecker.isLeapYear(2352));
	}

	@Test
	public void isLeapYear1809Test() {
		LeapYearChecker leapYearChecker = new LeapYearChecker();
		assertFalse(leapYearChecker.isLeapYear(1809));
	}

	@Test
	public void isLeapYear2000Test() {
		LeapYearChecker leapYearChecker = new LeapYearChecker();
		assertTrue(leapYearChecker.isLeapYear(2000));
	}

	@Test
	public void isLeapYear2400Test() {
		LeapYearChecker leapYearChecker = new LeapYearChecker();
		assertTrue(leapYearChecker.isLeapYear(2400));
	}

	@Test
	public void isLeapYear2100Test() {
		LeapYearChecker leapYearChecker = new LeapYearChecker();
		assertFalse(leapYearChecker.isLeapYear(2100));
	}

	@Test
	public void isLeapYear2600Test() {
		LeapYearChecker leapYearChecker = new LeapYearChecker();
		assertFalse(leapYearChecker.isLeapYear(2600));
	}

}
