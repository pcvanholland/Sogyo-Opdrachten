/**
 * 
 */
package nl.sogyo.hangman;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * @author rvvugt
 *
 */
public class GameRunner {
	
	private Scanner scanner;
	private static final String HANGMAN_FILENAME = "hangman-data.txt";
	private List<String> words;
//	private Hangman hangman;
	private Hangman2 hangman;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {
		
		GameRunner gameRunner = new GameRunner();
		gameRunner.initialize();
		gameRunner.play();
	}
	
	/**
	 * 
	 */
	private void initialize() {
		
		this.scanner = this.openScannerResource();
		
		HangmanFileProcessor fileProcessor = new HangmanFileProcessor(GameRunner.HANGMAN_FILENAME);
		this.words = fileProcessor.getWords();
//		this.hangman = new Hangman(getRandomWord());
		this.hangman = new Hangman2(getRandomWord());
		
		System.out.println("This is HANGMAN!");
		System.out.println("To quite the game enter a capital 'Q' as your choice.");
		System.out.println();
	}
	
	/**
	 * @return
	 */
	public String getRandomWord() {
		
		int randomNumber = new Random().nextInt(this.words.size()-1);
		return words.get(randomNumber);
	}
	
	/**
	 * 
	 */
	private void play() {
		
		System.out.println(this.hangman.getObfuscatedWord());
		
		char guess = 'Q';
		
		do {
			System.out.println();
			guess = this.askUserGuess();
			this.processGuess(guess);
		} while (guess != -1);
        
        try {
        	this.closeScannerResource(this.scanner);
        } catch ( IOException ioe ) {
        	System.err.println(ioe.getMessage());
        }
	}
	
	/**
	 * @param leapYear
	 */
	private void processGuess(char guess) {
		
		boolean wordIsGuessed = this.hangman.verifyGuess(guess);
		
		System.out.println();
		System.out.println("**********************************************************");
		System.out.println();
		System.out.println(this.hangman.getObfuscatedWord());
		System.out.println();
		
		if (wordIsGuessed) {
			System.out.println("We have a WINNER!");
			System.exit(0);
		}
		
		System.out.println("Number of guesses left is " + hangman.getNumberOfGuessesLeft());
		System.out.println("Letters already used are: " + String.valueOf(hangman.getLettersTried()));
		
		if (hangman.getNumberOfGuessesLeft() == 0) {
			System.out.println();
			System.out.println("I'm sorry but you lost!");
			System.out.println();
			System.out.println("The word was: " + hangman.getWord());
			System.exit(0);
		}
	}

	/**
	 * @return
	 */
	private char askUserGuess() {
		
		char guess = 'Q';
		boolean guessing = true;
		
		while (guessing) {
			System.out.print("Which letter do you choose [a-z]? ");
			
			try {
				guess = this.scanner.next(Pattern.compile("[a-zQ]")).charAt(0);
				guessing = false;
			} catch (Exception e) {
				System.out.println();
				System.out.println("Invalid Choice! Only [a-z] and 'Q' are valid guesses");
				System.out.println("Please try again.");
				System.out.println();
				this.scanner.nextLine();
			}
		}
        
		if ( guess == 'Q' ) {
			System.err.println("Thank you for playing. Please come again!");
			System.exit(0);
		}
		
        return guess;
	}
	
	/**
	 * @return
	 */
	private Scanner openScannerResource() {
		
		return new Scanner(System.in);
	}
	
	/**
	 * @param resource
	 */
	private void closeScannerResource(Closeable resource) throws IOException {
		
		resource.close();
	}
	
}
