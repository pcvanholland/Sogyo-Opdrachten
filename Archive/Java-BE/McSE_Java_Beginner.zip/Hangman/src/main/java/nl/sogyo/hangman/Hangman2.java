/**
 * 
 */
package nl.sogyo.hangman;

import java.util.ArrayList;

/**
 * @author rvvugt
 *
 */
public class Hangman2 {
	
	public static final int MAX_NUMBER_OF_GUESSES = 10;
	
	private String word;
	private char[] obfuscatedWord;
	private int numberOfGuessesLeft = 10;
	private ArrayList<Character> lettersTried = new ArrayList<Character>();
	
	/**
	 * @param word
	 */
	public Hangman2(String word) {
		
		this.word = word.toLowerCase();
		
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < word.length(); i++) {
			sb.append("-");
		}
		this.obfuscatedWord = sb.toString().toCharArray();
	}
	
	/**
	 * @return
	 */
	public String getWord() {
		
		return this.word;
	}
	
	/**
	 * @return
	 */
	public String getObfuscatedWord() {
		
		return String.valueOf(this.obfuscatedWord);
	}
	
	/**
	 * @return
	 */
	public int getNumberOfGuessesLeft() {
		
		return this.numberOfGuessesLeft;
	}
	
	/**
	 * @return
	 */
	public char[] getLettersTried() {
		
		return this.lettersTried.toString().toCharArray();
	}
	
	/**
	 * @param guess
	 * @return
	 */
	public boolean verifyGuess(char guess) {
		
		if (this.numberOfGuessesLeft <= 0) {
			return false;
		}
		
		this.lettersTried.add(guess);
		char[] options = word.toCharArray();
		boolean correctGuess = this.processGuess(guess, options);
		
		if ( !correctGuess ) {
			this.numberOfGuessesLeft--;
		}
		
		return ! String.valueOf(this.obfuscatedWord).contains("-");
	}
	
	/**
	 * @param guess
	 * @param options
	 * @return
	 */
	private boolean processGuess(char guess, char[] options) {
		
		boolean correctGuess = false;
		
		for (int i = 0; i < options.length; i++) {
			boolean optionIsGood = this.processOption(i, guess, options[i]);
			if ( !correctGuess && optionIsGood ) {
				correctGuess = true;
			}
		}
		
		return correctGuess;
	}
	
	/**
	 * @param index
	 * @param guess
	 * @param option
	 */
	private boolean processOption(int index, char guess, char option) {
		
		if (guess == option) {
			this.obfuscatedWord[index] = guess;
			return true;
		} else {
			return false;
		}
	}
	
}
