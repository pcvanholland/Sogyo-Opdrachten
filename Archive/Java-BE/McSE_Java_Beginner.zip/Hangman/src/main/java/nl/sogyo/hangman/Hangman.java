/**
 * 
 */
package nl.sogyo.hangman;

/**
 * @author rvvugt
 *
 */
public class Hangman {
	
	public static final int MAX_NUMBER_OF_GUESSES = 10;
	
	private String word;
	private char[] obfuscatedWord;
	private int numberOfGuessesLeft = 10;
	private char[] lettersTried = new char[10];
	
	/**
	 * @param word
	 */
	public Hangman(String word) {
		
		this.word = word.toLowerCase();
		
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < word.length(); i++) {
			sb.append("-");
		}
		this.obfuscatedWord = sb.toString().toCharArray();
	}
	
	/**
	 * @return
	 */
	public String getWord() {
		
		return this.word;
	}
	
	/**
	 * @return
	 */
	public String getObfuscatedWord() {
		
		return String.valueOf(this.obfuscatedWord);
	}
	
	/**
	 * @return
	 */
	public int getNumberOfGuessesLeft() {
		
		return this.numberOfGuessesLeft;
	}
	
	/**
	 * @return
	 */
	public char[] getLettersTried() {
		
		return this.lettersTried;
	}
	
	/**
	 * @param guess
	 * @return
	 */
	public boolean verifyGuess(char guess) {
		
		if (this.numberOfGuessesLeft <= 0) {
			return false;
		}
		
		this.numberOfGuessesLeft--;
		this.lettersTried[Hangman.MAX_NUMBER_OF_GUESSES - this.numberOfGuessesLeft -1] = guess;
		
		char[] options = word.toCharArray();
		
		for (int i = 0; i < options.length; i++) {
			this.processOption(i, guess, options[i]);
		}
		
		return ! String.valueOf(this.obfuscatedWord).contains("-");
	}
	
	/**
	 * @param index
	 * @param guess
	 * @param option
	 */
	private void processOption(int index, char guess, char option) {
		
		if (guess == option) {
			this.obfuscatedWord[index] = guess;
		}
	}
	
}
