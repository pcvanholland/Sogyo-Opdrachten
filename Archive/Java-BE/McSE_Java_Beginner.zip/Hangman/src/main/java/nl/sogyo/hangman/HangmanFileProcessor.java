/**
 * 
 */
package nl.sogyo.hangman;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @author rvvugt
 * 
 * @see https://www.hangmanwords.com/words
 */
public class HangmanFileProcessor {
	
	private List<String> words = new ArrayList<String>();
	
	/**
	 * @param filename
	 */
	public HangmanFileProcessor(String filename) {
		
		try {
			this.processFile(this.getFile(filename));
		} catch (IOException ioe) {
			System.out.println("Error reading file '" + filename + "'!");
		}
	}
	
	/**
	 * @param filename
	 * @return
	 */
	private File getFile(String filename) {
		
		ClassLoader classLoader = this.getClass().getClassLoader();
		File file = new File(classLoader.getResource(filename).getFile());
		
		return file;
	}
	
	/**
	 * @param file
	 * @return
	 * @throws IOException
	 */
	private void processFile(File file) throws IOException {
		
		Scanner scanner = new Scanner(file);
		
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			this.words.add(line.trim());
		}

		scanner.close();
	}
	
	/**
	 * @return
	 */
	public List<String> getWords() {
		
		return this.words;
	}
	
}
