/**
 * 
 */
package nl.sogyo.hangman;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class HangmanTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void initializationTest() {
		
		Hangman hangman = new Hangman("Robbert");
		assertTrue(10 == hangman.getNumberOfGuessesLeft());
		assertTrue("Robbert".equalsIgnoreCase(hangman.getWord()));
		assertTrue("-------".equals(hangman.getObfuscatedWord()));
	}

	@Test
	public void afterFirstGuessTest() {
		
		Hangman hangman = new Hangman("Robbert");
		hangman.verifyGuess('r');
		assertTrue(9 == hangman.getNumberOfGuessesLeft());
		assertTrue("r----r-".equals(hangman.getObfuscatedWord()));
	}

	@Test
	public void afterTenGuessesTest() {
		
		Hangman hangman = new Hangman("Robbert");
		hangman.verifyGuess('z');
		hangman.verifyGuess('y');
		hangman.verifyGuess('x');
		hangman.verifyGuess('w');
		hangman.verifyGuess('v');
		hangman.verifyGuess('u');
		hangman.verifyGuess('s');
		hangman.verifyGuess('q');
		hangman.verifyGuess('p');
		hangman.verifyGuess('n');
		assertTrue(0 == hangman.getNumberOfGuessesLeft());
		assertTrue("-------".equals(hangman.getObfuscatedWord()));
	}

	@Test
	public void weHaveAWinnerTest() {
		
		Hangman hangman = new Hangman("Robbert");
		hangman.verifyGuess('r');
		hangman.verifyGuess('o');
		hangman.verifyGuess('b');
		hangman.verifyGuess('e');
		boolean result = hangman.verifyGuess('t');
		assertTrue(result);
		assertTrue(5 == hangman.getNumberOfGuessesLeft());
		assertTrue("robbert".equals(hangman.getObfuscatedWord()));
	}

	@Test
	public void afterTwelfGuessesTest() {
		
		Hangman hangman = new Hangman("Robbert");
		hangman.verifyGuess('z');
		hangman.verifyGuess('y');
		hangman.verifyGuess('x');
		hangman.verifyGuess('w');
		hangman.verifyGuess('v');
		hangman.verifyGuess('u');
		hangman.verifyGuess('s');
		hangman.verifyGuess('q');
		hangman.verifyGuess('p');
		hangman.verifyGuess('n');
		hangman.verifyGuess('m');
		hangman.verifyGuess('l');
		assertTrue(0 == hangman.getNumberOfGuessesLeft());
		assertTrue("-------".equals(hangman.getObfuscatedWord()));
	}

}
