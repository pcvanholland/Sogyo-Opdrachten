/**
 * 
 */
package nl.sogyo.palindrome;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class Client {
	
	private Scanner scanner;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Client client = new Client();
		client.scanner = client.openScannerResource();
		
       	client.processPalindrome(client.askForWord(client.scanner));
        
        try {
        	client.closeScannerResource(client.scanner);
        } catch ( IOException ioe ) {
        	System.err.println(ioe.getMessage());
        }
	}
	
	/**
	 * @param word
	 */
	private void processPalindrome(String word) {
		
       	boolean palindrome = new PalindromeChecker().checkPalindromeWord(word);
       	
       	String result = null;
       	if (palindrome) {
       		result = "is";
       	} else {
       		result = "is not";
       	}
        
       	StringBuffer sb = new StringBuffer();
       	sb.append("The word '");
       	sb.append(word);
       	sb.append("' ");
       	sb.append(result);
       	sb.append(" a palindrome!");
       	
        System.out.println(sb.toString());
	}

	/**
	 * @param scanner
	 * @return
	 */
	private String askForWord(Scanner scanner) {
		
		String word = null;
		
		System.out.print("Please enter your word: ");
		
		try {
			word = scanner.next();
        } catch (Exception e) {
        	System.err.println("Invalid Format! Please try again!");
        }
		
		if ( word == null ) {
			System.err.println("Invalid input. Please try again!");
			System.exit(0);
		}
		
        return word;
	}
	
	/**
	 * @return
	 */
	private Scanner openScannerResource() {
		
		return new Scanner(System.in);
	}
	
	/**
	 * @param resource
	 */
	private void closeScannerResource(Closeable resource) throws IOException {
		
		resource.close();
	}
	
}
