/**
 * 
 */
package nl.sogyo.palindrome;

/**
 * @author rvvugt
 *
 */
public class PalindromeChecker {
	
	/**
	 * @param word
	 * @return
	 */
	public boolean checkPalindromeWord(String word) {
		
		String reverse = "";
		
		for(int i = word.length() - 1; i >= 0; i--) {
			reverse = reverse + word.charAt(i);
		}
		
		return word.equalsIgnoreCase(reverse);
	}
	
}
