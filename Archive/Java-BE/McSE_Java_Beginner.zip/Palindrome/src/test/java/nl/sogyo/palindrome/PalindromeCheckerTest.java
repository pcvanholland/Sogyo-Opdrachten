/**
 * 
 */
package nl.sogyo.palindrome;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class PalindromeCheckerTest {
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void checkPalindromeWord_Robbert_Test() {
		
		PalindromeChecker palindromeChecker = new PalindromeChecker();
		assertFalse(palindromeChecker.checkPalindromeWord("Robbert"));
	}

	@Test
	public void checkPalindromeWord_Rotator_Test() {
		
		PalindromeChecker palindromeChecker = new PalindromeChecker();
		assertTrue(palindromeChecker.checkPalindromeWord("Rotator"));
	}

	@Test
	public void checkPalindromeWord_Anna_Test() {
		
		PalindromeChecker palindromeChecker = new PalindromeChecker();
		assertTrue(palindromeChecker.checkPalindromeWord("Anna"));
	}

	@Test
	public void checkPalindromeWord_tattarrattat_Test() {
		
		PalindromeChecker palindromeChecker = new PalindromeChecker();
		assertTrue(palindromeChecker.checkPalindromeWord("tattarrattat"));
	}

}
