/**
 * 
 */
package nl.sogyo.unitconversion;

import java.io.Closeable;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class Client {
	
	private Scanner scanner;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Client client = new Client();
		client.scanner = client.openScannerResource();
		
		int conversionType = 0;
		UnitType unitType = null;
		double unitValue = Double.NaN;
		
       	conversionType = client.askForConversionType(client.scanner);
       	unitType = client.processUnitType(conversionType);
       	unitValue = client.askForConversionValue(client.scanner);
        
        client.processConversion(conversionType, unitType, unitValue);
        
        try {
        	client.closeScannerResource(client.scanner);
        } catch ( IOException ioe ) {
        	System.err.println(ioe.getMessage());
        }
	}
	
	/**
	 * @param conversionType
	 * @param unitType
	 * @param unitValue
	 */
	private void processConversion(int conversionType, UnitType unitType, double unitValue) {
		
		UnitConverter unitConverter = new UnitConverter();
		Unit unit = unitConverter.convert(conversionType, new Unit(unitType, unitValue));
		
		DecimalFormat formatter = new DecimalFormat("#0.00");
		
		System.out.println("Input was: " + formatter.format(unitValue) + " " + unitType);
		System.out.println("Conversion result is: " + formatter.format(unit.getValue()) + " " + unit.getType());
	}

	/**
	 * @param scanner
	 * @return
	 * @throws Exception
	 */
	private int askForConversionType(Scanner scanner) {
		
		int conversionType = 0;
		
		System.out.println("Which type of conversion do you want?");
		System.out.println("(1) KM to Miles");
		System.out.println("(2) Miles to KM");
		System.out.println("(3) Celcius to Fahrenheit");
		System.out.println("(4) Fahrenheit to Celcius");
		System.out.println("");
		System.out.print("Please enter you choice (by entering a value of 1, 2, 3, or 4): ");
		
		try {
        	conversionType = scanner.nextInt();
        } catch (Exception e) {
        	System.err.println("Invalid Format! Please try again!");
        }
		
		if ( conversionType < 1 || conversionType > 4 ) {
			System.err.println("Invalid input. Please try again!");
			System.exit(0);
		}
		
        return conversionType;
	}
	
	/**
	 * @param scanner
	 * @return
	 * @throws Exception
	 */
	private double askForConversionValue(Scanner scanner) {
		
		double unitValue = Double.NaN;
		
    	System.out.print("Enter the value to be converted: ");
    	
		try {
			unitValue = scanner.nextDouble();
		} catch (Exception e) {
			System.err.println("Invalid Format! Please try again!");
		}
		
		if ( unitValue == Double.NaN ) {
			System.err.println("Invalid input. Please try again!");
			System.exit(0);
		}
		
        return unitValue;
	}
	
	/**
	 * @param conversionType
	 * @return
	 */
	private UnitType processUnitType(int conversionType) {
		
		UnitType result = null;
		
		switch(conversionType) {
			case 1: {
				result = UnitType.KM;
				break;
			}
			case 2: {
				result = UnitType.MI;
				break;
			}
			case 3: {
				result = UnitType.C;
				break;
			}
			case 4: {
				result = UnitType.F;
				break;
			}
		}
		
		return result;
	}
	
	/**
	 * @return
	 */
	private Scanner openScannerResource() {
		
		return new Scanner(System.in);
	}
	
	/**
	 * @param resource
	 */
	private void closeScannerResource(Closeable resource) throws IOException {
		
		resource.close();
	}
	
}
