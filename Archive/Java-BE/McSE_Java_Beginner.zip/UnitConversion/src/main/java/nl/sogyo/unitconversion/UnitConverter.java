/**
 * 
 */
package nl.sogyo.unitconversion;

/**
 * @author rvvugt
 *
 */
public class UnitConverter {
	
	public static final double MILE_CONVERSION = 1.609344;

	/**
	 * @param conversionUnit
	 * @return
	 */
	public Unit convert(int conversionType, Unit unit) {
		
		Unit convertedUnit = null;
		
		switch(conversionType) {
			case 1: {
				convertedUnit = this.kilometers2Miles(unit);
				break;
			}
			case 2: {
				convertedUnit = this.miles2Kilometers(unit);
				break;
			}
			case 3: {
				convertedUnit = this.celcius2Fahrenheid(unit);
				break;
			}
			case 4: {
				convertedUnit = this.fahrenheit2Celcius(unit);
				break;
			}
		}
		
		return convertedUnit;
	}
	
	/**
	 * @param unit
	 * @return
	 */
	public Unit kilometers2Miles(Unit unit) {
		
		double unitValue = unit.getValue() / UnitConverter.MILE_CONVERSION;
		
		return new Unit(UnitType.MI, unitValue);
	}
	
	/**
	 * @param unit
	 * @return
	 */
	public Unit miles2Kilometers(Unit unit) {
		
		double unitValue = unit.getValue() * UnitConverter.MILE_CONVERSION;
		
		return new Unit(UnitType.KM, unitValue);
	}
	
	/**
	 * @param unit
	 * @return
	 */
	public Unit celcius2Fahrenheid(Unit unit) {
		
		/*
		 * The line of code below will not work because
		 * (9 / 5) will result in 1 NOT 1.8 since it
		 * will be an integer division. To get the right
		 * result add a 'D' after the numbers to indicate
		 * that the numbers are decimal numbers.
		 */
//		double unitValue = unit.getValue() * (9 / 5) + 32;
		double unitValue = unit.getValue() * (9D / 5D) + 32;
		
		return new Unit(UnitType.F, unitValue);
	}
	
	/**
	 * @param unit
	 * @return
	 */
	public Unit fahrenheit2Celcius(Unit unit) {
		
		double unitValue = (unit.getValue() - 32) * (5D / 9D);
		
		return new Unit(UnitType.C, unitValue);
	}
	
}
