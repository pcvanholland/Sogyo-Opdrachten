/**
 * 
 */
package nl.sogyo.unitconversion;

/**
 * @author rvvugt
 *
 */
public class Unit {
	
	private UnitType type;
	private double value;
	
	/**
	 * @param type
	 * @param value
	 */
	public Unit(UnitType type, double value) {
		
		this.type = type;
		this.value = value;
	}
	
	/**
	 * @return
	 */
	public UnitType getType() {
		
		return this.type;
	}
	
	/**
	 * @return
	 */
	public double getValue() {
		
		return this.value;
	}
	
}
