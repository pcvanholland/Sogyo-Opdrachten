/**
 * 
 */
package nl.sogyo.unitconversion;

/**
 * @author rvvugt
 *
 */
public enum UnitType {
	
	KM, // Kilometer
	MI, // Mile
	C, // Celcius
	F // Fahrenheit
}
