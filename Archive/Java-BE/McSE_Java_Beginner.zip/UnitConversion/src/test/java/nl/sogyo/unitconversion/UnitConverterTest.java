/**
 * 
 */
package nl.sogyo.unitconversion;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import nl.sogyo.unitconversion.UnitConverter;

/**
 * @author rvvugt
 *
 */
public class UnitConverterTest {
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void convert50KM2MITest() {
		
		UnitConverter unitConverter = new UnitConverter();
		Unit unit = new Unit(UnitType.KM, 50);
		assertEquals(31.07, unitConverter.convert(1, unit).getValue(), 0.01);
	}

	@Test
	public void convert50MI2KMTest() {
		
		UnitConverter unitConverter = new UnitConverter();
		Unit unit = new Unit(UnitType.MI, 50);
		assertEquals(80.47, unitConverter.convert(2, unit).getValue(), 0.01);
	}

	@Test
	public void convert25C2FTest() {
		
		UnitConverter unitConverter = new UnitConverter();
		Unit unit = new Unit(UnitType.C, 25);
		assertEquals(77.00, unitConverter.convert(3, unit).getValue(), 0.01);
	}

	@Test
	public void convert77F2CTest() {
		
		UnitConverter unitConverter = new UnitConverter();
		Unit unit = new Unit(UnitType.F, 77);
		assertEquals(25.00, unitConverter.convert(4, unit).getValue(), 0.01);
	}

}
