/**
 * 
 */
package nl.sogyo.prime;

/**
 * @author rvvugt
 *
 */
public class PrimeDisplayer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		int maxNumber = 100;

		System.out.println("Prime numbers between 0 and " + maxNumber);

		for (int i = 0; i < maxNumber; i++) {
			
			if (i < 2) {
				continue;
			}
			
			boolean isPrime = true;

			for (int j = 2; j < i; j++) {

				if (i % j == 0) {
					isPrime = false;
					break;
				}
			}
			
			if (isPrime)
				System.out.print(i + " ");
		}
	}

}
