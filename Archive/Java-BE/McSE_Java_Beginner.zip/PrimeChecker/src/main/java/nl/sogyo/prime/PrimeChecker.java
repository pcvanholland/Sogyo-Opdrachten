/**
 * 
 */
package nl.sogyo.prime;

import java.util.ArrayList;

/**
 * @author rvvugt
 *
 */
public class PrimeChecker {
	
	private ArrayList<Integer> primes = new ArrayList<Integer>();
	
	/**
	 * @param index
	 * @return
	 */
	public long givePrime(int index) {
		
		if (index < 0) {
			throw new IllegalArgumentException("Index cannot be a negative number.");
		}
		
		int primeCount = 0;
		int number = 0;
		
		while (primeCount != index) {
			
			number++;
			if (this.isPrimeNumber(number)) {
				primeCount++;
				primes.add(number);
			}
		}
		
		return number;
	}
	
	/*
	The first "isPrime()" method uses an if-else structure
	The second "isPrime()" method uses an switch and is a bit faster.
	The third "isPrime()" method uses an switch the calculated prime numbers so far and is much faster.
	*/
	
//	/**
//	 * @param number
//	 * @return
//	 */
//	private boolean isPrimeNumber(int number) {
//		
//		if (number < 0) {
//			throw new IllegalArgumentException("Primenumber cannot be a negative number.");
//		}
//	
//		boolean isPrime = true;
//		
//		if (number > 1) {
//			
//			for (int i = 2; i < number; i++) {
//				
//				if (number % i == 0) {
//					isPrime = false;
//					break;
//				}
//			}
//		} else {
//			isPrime = false;
//		}
//		
//		return isPrime;
//	}

//	/**
//	 * @param number
//	 * @return
//	 */
//	private boolean isPrimeNumber(int number) {
//		
//		if (number < 0) {
//			throw new IllegalArgumentException("Primenumber cannot be a negative number.");
//		}
//		
//		switch(number) {
//			case 0:
//			case 1:
//				return false;
//			case 2:
//			case 3:
//				return true;
//			default: {
//				if (number % 2 == 0) {
//					return false;
//				} else {
//					for (int i = 3; i < number; i += 2) {
//						
//						if (number % i == 0) {
//							return false;
//						}
//					}
//					return true;
//				}
//			}
//		}
//	}
	
	/**
	 * @param number
	 * @return
	 */
	private boolean isPrimeNumber(int number) {
		
		if (number < 0) {
			throw new IllegalArgumentException("Primenumber cannot be a negative number.");
		}
		
		switch(number) {
			case 0:
			case 1:
				return false;
			case 2:
			case 3:
				return true;
			default: {
				if (number % 2 == 0) {
					return false;
				} else {
					for (int i: primes) {
						
						if (number % i == 0) {
							return false;
						}
					}
					return true;
				}
			}
		}
	}
	
	/**
	 * @param number
	 * @return
	 */
	public boolean isPrime(int number) {
		
		if (number < 0) {
			throw new IllegalArgumentException("Primenumber cannot be a negative number.");
		}
		
		if (number < 2) {
			return false;
		} else {
			return this.calculatePrime(number);
		}
	}
	
	/**
	 * @param number
	 * @return
	 */
	private boolean calculatePrime(int number) {
		
		boolean isPrime = true;

		for (int j = 2; j < number; j++) {

			if (number % j == 0) {
				isPrime = false;
				break;
			}
		}
		
		return isPrime;
	}
	
}
