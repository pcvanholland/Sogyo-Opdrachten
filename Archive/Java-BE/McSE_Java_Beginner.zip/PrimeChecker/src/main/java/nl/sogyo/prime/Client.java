/**
 * 
 */
package nl.sogyo.prime;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 * @author rvvugt
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Client client = new Client();
		int index = -1;
		
		try {
			index = client.readInput();
        } catch (IOException ioe) {
        	System.out.println(ioe.getMessage());
        }
		
		long startTime = System.nanoTime();
		
		client.processPrime(index);

		long estimatedTime = System.nanoTime() - startTime;
		long durationInMs = TimeUnit.MILLISECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS);
		System.out.println("Runningtime: " + durationInMs + "Ms");
	}
	
	/**
	 * @param index
	 */
	private void processPrime(int index) {
		
        PrimeChecker primeChecker = new PrimeChecker();
		System.out.println("The prime number for index " + index + ": " + primeChecker.givePrime(index));
		
	}

	/**
	 * @return
	 */
	private int readInput() throws IOException {
		
		int index = 0;
		System.out.print("Enter index: ");
		
		Scanner scanner = new Scanner(System.in);
		Closeable resource = scanner;
        try {
        	index = scanner.nextInt();
        } catch (Exception e) {
        	System.err.println("Invalid Format!");
        } finally {
        	resource.close();
        }
		
//		Alternative to the codeblock above.
/*
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Closeable resource = br;
        try {
        	index = Integer.parseInt(br.readLine());
        } catch(NumberFormatException | IOException e) {
        	System.err.println("Invalid Format!");
        } finally {
        	resource.close();
        }
*/
		
        return index;
	}

}
