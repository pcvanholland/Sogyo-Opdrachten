/**
 * 
 */
package nl.sogyo.prime;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class PrimeTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void primeTest1() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertFalse(primeChecker.isPrime(1));
	}

	@Test
	public void primeTest2() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertTrue(primeChecker.isPrime(2));
	}

	@Test
	public void primeTest3() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertTrue(primeChecker.isPrime(3));
	}

	@Test
	public void primeTest4() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertFalse(primeChecker.isPrime(4));
	}

	@Test
	public void primeTest5() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertTrue(primeChecker.isPrime(5));
	}

	@Test
	public void primeTest6() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertFalse(primeChecker.isPrime(6));
	}

	@Test
	public void primeTest7() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertTrue(primeChecker.isPrime(7));
	}

	@Test
	public void primeTest9() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertFalse(primeChecker.isPrime(9));
	}

	@Test
	public void primeTest11() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertTrue(primeChecker.isPrime(11));
	}

	@Test
	public void primeTest12() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertFalse(primeChecker.isPrime(12));
	}

	@Test
	public void primeTest13() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertTrue(primeChecker.isPrime(13));
	}

	@Test
	public void givePrime20Test() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertEquals(71, primeChecker.givePrime(20));
	}

	@Test
	public void givePrime30Test() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertEquals(113, primeChecker.givePrime(30));
	}

	@Test
	public void givePrime45Test() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertEquals(197, primeChecker.givePrime(45));
	}

	@Test
	public void givePrime233Test() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertEquals(1471, primeChecker.givePrime(233));
	}

	@Test
	public void givePrime10001Test() {
		
		PrimeChecker primeChecker = new PrimeChecker();
		assertEquals(104743, primeChecker.givePrime(10001));
	}

}
