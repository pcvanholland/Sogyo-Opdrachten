/**
 * 
 */
package nl.sogyo.coinflip;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class GameRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		GameRunner gameRunner = new GameRunner();
//		gameRunner.initialize();
		gameRunner.play();
	}
	
	private void play() {
		
        int guess = -1;
		
        try {
        	guess = this.askUserGuess();
        } catch (IOException ioe) {
        	System.out.println(ioe.getMessage());
        }
        
        this.processGuess(guess);
	}
	
	/**
	 * @param leapYear
	 */
	private void processGuess(int guess) {
		
        CoinFlipChecker coinFlipChecker = new CoinFlipChecker();
        boolean correctGuess = coinFlipChecker.checkCoinFlip(guess);
        if (correctGuess) {
        	System.out.println("Correct!");
        } else {
        	System.out.println("Incorrect!");
        }
	}

	/**
	 * @return
	 */
	private int askUserGuess() throws IOException {
		
		String guess = null;
		int result = 0;
		
		System.out.print("Heads or tails? ");
		
		Scanner scanner = new Scanner(System.in);
		Closeable resource = scanner;
        try {
        	guess = scanner.next();
        } catch (Exception e) {
        	System.err.println("Invalid Format!");
        } finally {
        	resource.close();
        }
		
		if ( "TAILS".equalsIgnoreCase(guess) ) {
			result = 0;
		} else if ("HEADS".equalsIgnoreCase(guess)) {
			result = 1;
		} else {
			System.err.println("Invalid input. Please try again!");
			System.exit(0);
		}
		
        return result;
	}
	
}
