/**
 * 
 */
package nl.sogyo.coinflip;

import java.util.Random;

/**
 * @author rvvugt
 *
 */
public class CoinFlipChecker {

	/**
	 * @param guess
	 * @return
	 */
	public boolean checkCoinFlip(int guess) {
		
		int flip = new Random().nextInt(2);
		
		return flip == guess;
	}
	
}
