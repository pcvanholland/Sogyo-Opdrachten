/**
 * 
 */
package nl.sogyo.fibonacci;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Client client = new Client();
		int index = -1;
		try {
			index = client.readInput();
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		}
        
        Fibonacci fibonacci = new Fibonacci();
		System.out.println("Fibonacci term for " + index + ": " + fibonacci.generateFibonacciTerm(index));
        
//        long sum = 0;
//        long result = -1;
//        for (int i = index; i > 0; i--) {
//        	result = fibonacci.generateFibonacciTerm(i);
//        	if (result % 2 == 0) {
//        		sum = sum + result;
//        	}
//        }
//        System.out.println("Fibonacci term for " + index + ": " + result);
//        System.out.println("Total for fibonacci term: " + sum);
	}

	/**
	 * @return
	 */
	private int readInput() throws IOException {
		
		int index = 0;
		System.out.print("Enter index: ");
		
		Scanner scanner = new Scanner(System.in);
		Closeable resource = scanner;
        try {
        	index = scanner.nextInt();
        } catch (Exception e) {
        	System.err.println("Invalid Format!");
        } finally {
        	resource.close();
        }
		
        return index;
	}

}
