/**
 * 
 */
package nl.sogyo.fibonacci;


/**
 * @author rvvugt
 *
 */
public class Fibonacci {
	
	/**
	 * @param index
	 * @return
	 */
	public long generateFibonacciTerm(int index) {
		
		if (index < 1) {
			throw new IllegalArgumentException("Index should be greater than 0.");
		}
		
		return this.generateFibonacciTermForNumber(--index);
	}
	
	/**
	 * @param number
	 * @return
	 */
	private long generateFibonacciTermForNumber(int number) {
		
		if (number == 0 || number == 1) {
			return number;
		} else {
			return (this.generateFibonacciTermForNumber(number - 1) + this.generateFibonacciTermForNumber(number - 2));  
		}
	}

}
