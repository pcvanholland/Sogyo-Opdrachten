/**
 * 
 */
package nl.sogyo.fibonacci;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class FibonacciTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void fibonacciTest1() {
		Fibonacci fibonacci = new Fibonacci();
		assertEquals(0, fibonacci.generateFibonacciTerm(1));
	}

	@Test
	public void fibonacciTest2() {
		Fibonacci fibonacci = new Fibonacci();
		assertEquals(1, fibonacci.generateFibonacciTerm(2));
	}

	@Test
	public void fibonacciTest3() {
		Fibonacci fibonacci = new Fibonacci();
		assertEquals(1, fibonacci.generateFibonacciTerm(3));
	}

	@Test
	public void fibonacciTest4() {
		Fibonacci fibonacci = new Fibonacci();
		assertEquals(2, fibonacci.generateFibonacciTerm(4));
	}

	@Test
	public void fibonacciTest5() {
		Fibonacci fibonacci = new Fibonacci();
		assertEquals(3, fibonacci.generateFibonacciTerm(5));
	}

	@Test
	public void fibonacciTest10() {
		Fibonacci fibonacci = new Fibonacci();
		assertEquals(34, fibonacci.generateFibonacciTerm(10));
	}

}
