/**
 * 
 */
package nl.sogyo.guessing;

import static org.junit.Assert.*;

import java.lang.reflect.Field;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class GuessingGameTest {

	private GuessingGame guessingGame = new GuessingGame();
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		
		Field field = GuessingGame.class.getDeclaredField("randomNumber");
        field.setAccessible(true);
        field.setInt(guessingGame, 25);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void verifyGuessHigherTest() {
		
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(10)));
		assertEquals(1, guessingGame.getNumberOfGuesses());
	}

	@Test
	public void verifyGuessLowerTest() {
		
		assertTrue(Result.Lower.equals(guessingGame.verifyGuess(33)));
		assertEquals(1, guessingGame.getNumberOfGuesses());
	}

	@Test
	public void verifyGuessCorrectTest() {
		
		assertTrue(Result.Correct.equals(guessingGame.verifyGuess(25)));
		assertEquals(1, guessingGame.getNumberOfGuesses());
	}

	@Test
	public void verifyGuessCorrectTest2() {
		
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(1)));
		assertEquals(1, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(2)));
		assertEquals(2, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(3)));
		assertEquals(3, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(4)));
		assertEquals(4, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Correct.equals(guessingGame.verifyGuess(25)));
		assertEquals(5, guessingGame.getNumberOfGuesses());
	}

	@Test
	public void verifyGuessFailTest() {
		
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(1)));
		assertEquals(1, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(2)));
		assertEquals(2, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(3)));
		assertEquals(3, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(4)));
		assertEquals(4, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(5)));
		assertEquals(5, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(6)));
		assertEquals(6, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(7)));
		assertEquals(7, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(8)));
		assertEquals(8, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Higher.equals(guessingGame.verifyGuess(9)));
		assertEquals(9, guessingGame.getNumberOfGuesses());
		assertTrue(Result.Fail.equals(guessingGame.verifyGuess(10)));
		assertEquals(10, guessingGame.getNumberOfGuesses());
	}

	@Test
	public void verifyGuessExceptionTest() {
		
		try {
			guessingGame.verifyGuess(-3);
			fail("Illegal guess of -3");
		} catch (IllegalArgumentException iae) {
			
		}
	}

}
