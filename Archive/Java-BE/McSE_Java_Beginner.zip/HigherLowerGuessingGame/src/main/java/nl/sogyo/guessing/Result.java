/**
 * 
 */
package nl.sogyo.guessing;

/**
 * @author rvvugt
 *
 */
public enum Result {
	
	Initialized,
	Higher,
	Lower,
	Correct,
	Fail;
	
}
