/**
 * 
 */
package nl.sogyo.guessing;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class GameRunner {

	private GuessingGame guessingGame;
	private Result result;
	private Scanner scanner;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		GameRunner gameRunner = new GameRunner();
		gameRunner.initialize();
		gameRunner.play();
	}
	
	/**
	 * 
	 */
	private void initialize() {
		
		this.guessingGame = new GuessingGame();
		this.result = Result.Initialized;
		this.scanner = new Scanner(System.in);
		
		System.out.println("Enter a number between 0 and 50.");
	}
	
	/**
	 * 
	 */
	private void play() {
		
		int guess = -1;
		
		do {	
			guess = this.readGuess();
			try {
				this.result = guessingGame.verifyGuess(guess);
			} catch (IllegalArgumentException iae) {
				System.out.println(iae.getMessage());
				System.out.println("Please try again!");
				continue;
			}
			
			System.out.println(result);
			if (!(Result.Correct.equals(this.result) || Result.Fail.equals(this.result))) {
				System.out.println("You have " + (10 - guessingGame.getNumberOfGuesses()) + " guesses left.");
			}
		} while (!(Result.Correct.equals(this.result) || Result.Fail.equals(this.result)));
		
		try {
			((Closeable) this.scanner).close();
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		}
	}
	
	/**
	 * @return
	 */
	private int readGuess() {
		
		int guess = -1;
		
		System.out.print("Enter guess: ");
		
        try {
        	guess = scanner.nextInt();
        } catch (Exception e) {
        	System.err.println("Invalid Format!");
        }
        
		return guess;
	}

}
