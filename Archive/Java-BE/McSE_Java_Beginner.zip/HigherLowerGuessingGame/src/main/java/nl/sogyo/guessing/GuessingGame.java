/**
 * 
 */
package nl.sogyo.guessing;

import java.util.Random;

/**
 * @author rvvugt
 *
 */
public class GuessingGame {
	
	private int randomNumber = new Random().nextInt(51);
	
	private int numberOfGuesses = 0;
	
	/**
	 * @param guess
	 * @return
	 */
	public Result verifyGuess(int guess) {
		
		if (guess < 0 || guess > 50) {
			throw new IllegalArgumentException("Your guess cannot be a negative number, and no greater than 50.");
		}
		
		this.numberOfGuesses++;
		
		if (this.numberOfGuesses == 10) {
			return this.finishGame(guess);
		} else {
			return this.verifyCurrentGuess(guess);
		}
	}
	
	/**
	 * @param guess
	 * @return
	 */
	private Result finishGame(int guess) {
		
		if (guess == this.randomNumber) {
			return Result.Correct;
		} else {
			return Result.Fail;
		}
	}
	
	/**
	 * @param guess
	 * @return
	 */
	private Result verifyCurrentGuess(int guess) {
		
		if (guess == this.randomNumber) {
			return Result.Correct;
		} else if (guess > this.randomNumber) {
			return Result.Lower;
		} else {
			return Result.Higher;
		}
	}
	
	/**
	 * @return
	 */
	public int getNumberOfGuesses() {
		return this.numberOfGuesses;
	}

}
