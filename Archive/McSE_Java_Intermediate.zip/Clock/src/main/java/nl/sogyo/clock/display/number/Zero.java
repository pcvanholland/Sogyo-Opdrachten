/**
 * 
 */
package nl.sogyo.clock.display.number;

import nl.sogyo.clock.display.DisplayItem;
import nl.sogyo.clock.display.EnlargedCharacterResult;

/**
 * @author rvvugt
 *
 */
public class Zero extends Number {
	
	public static final char[][] ZERO = {
		{'#', '#', '#'},
		{'#', ' ', '#'},
		{'#', ' ', '#'},
		{'#', ' ', '#'},
		{'#', '#', '#'}
	};
	
	/**
	 * 
	 */
	public Zero() {
		
		super(Zero.ZERO);
	}
	
	/**
	 * 
	 */
	public Zero(int size) {
		
		super(Zero.ZERO, size);
	}
	
	@Override
	public char[][] getNumber() {
		
		if (1 == this.getSize()) {
			return Zero.ZERO;
		} else {
			return this.enlargeDisplayItem(Zero.ZERO, this.getSize());
		}
	}
	
	@Override
	protected EnlargedCharacterResult enlarge(String line, int increaseFactor, EnlargedCharacterResult enlargedNumberResult) {
		
// TAKE ANOTHER LOOK AND REFACTOR THIS METHOD!
// TODO: REFACTOR
				
		String replacement = "";
		switch(line) {
			case "###":
				for (int i = 0; i < increaseFactor; i++) {
					line += DisplayItem.DISPLAY_CHAR;
				}
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				break;
			case "# #":
				for (int i = 0; i <= increaseFactor; i++) {
					replacement += " ";
				}
				line = line.replace(" ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				while (enlargedNumberResult.getNumberOfLinesAdded() < increaseFactor) {
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
		}
		
		return enlargedNumberResult;
	}
	
}
