/**
 * 
 */
package nl.sogyo.clock.display.letters;

import nl.sogyo.clock.display.DisplayItem;
import nl.sogyo.clock.display.EnlargedCharacterResult;


/**
 * @author rvvugt
 *
 */
public class A extends Letter {

	public static final char[][] LETTER_A = {
		{' ', '#', ' '},
		{'#', ' ', '#'},
		{'#', '#', '#'},
		{'#', ' ', '#'},
		{'#', ' ', '#'}
	};
	
	/**
	 * 
	 */
	public A() {
		
		super(A.LETTER_A);
	}
	
	/**
	 * 
	 */
	public A(int size) {
		
		super(A.LETTER_A, size);
	}

	@Override
	public char[][] getLetter() {
		
		if (1 == this.getSize()) {
			return A.LETTER_A;
		} else {
			return this.enlargeDisplayItem(A.LETTER_A, this.getSize());
		}
	}
	
	@Override
	protected EnlargedCharacterResult enlarge(String line, int increaseFactor, EnlargedCharacterResult enlargedNumberResult) {
		
// TAKE ANOTHER LOOK AND REFACTOR THIS METHOD!
// TODO: REFACTOR
		
		String replacement = "";
		switch(line) {
			case "###":
				for (int i = 0; i < increaseFactor; i++) {
					line += DisplayItem.DISPLAY_CHAR;
				}
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				break;
			case " # ":
				for (int i = 0; i < (increaseFactor / 2) + 1; i++) {
					replacement += " ";
				}
				replacement = replacement + "#" + replacement;
				line = line.replace(" # ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				break;
			case "# #":
				if (enlargedNumberResult.getNumberOfLinesAdded() == 0) {
					for (int i = 0; i < (increaseFactor / 2); i++) {
						replacement += " ";
					}
					replacement = replacement + line + replacement;
					line = line.replace(line, replacement);
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					replacement = "  ";
					String originalLine = "# #";
					String newLine;
					while (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor / 2)) {
						originalLine = " " + originalLine + " ";
						newLine = "# " + replacement + "#";
						line = line.replaceFirst(originalLine, newLine);
						enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
						enlargedNumberResult.increaseNumberOfLinesAdded();
						originalLine = newLine;
						replacement = replacement + "  ";
					}
				} else {
					for (int i = 0; i <= increaseFactor; i++) {
						replacement += " ";
					}
					line = line.replace(" ", replacement);
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					while (enlargedNumberResult.getNumberOfLinesAdded() < increaseFactor) {
						enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
						enlargedNumberResult.increaseNumberOfLinesAdded();
					}
				}
				break;
		}
		
		return enlargedNumberResult;
	}

}
