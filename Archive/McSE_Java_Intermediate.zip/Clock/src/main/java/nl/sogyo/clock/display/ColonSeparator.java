/**
 * 
 */
package nl.sogyo.clock.display;



/**
 * @author rvvugt
 *
 */
public class ColonSeparator extends DisplayItem {
	
	public static final char[][] COLON = {
		{' ', ' ', ' '},
		{' ', '#', ' '},
		{' ', ' ', ' '},
		{' ', '#', ' '},
		{' ', ' ', ' '}
	};
	
	/**
	 * 
	 */
	public ColonSeparator() {
		
		super(ColonSeparator.COLON);
	}
	
	/**
	 * 
	 */
	public ColonSeparator(int size) {
		
		super(ColonSeparator.COLON, size);
	}

	/**
	 * @return
	 */
	public char[][] getLines() {
		
		if (1 == this.getSize()) {
			return ColonSeparator.COLON;
		} else {
			return this.enlargeDisplayItem(ColonSeparator.COLON, this.getSize());
		}
	}
	
	@Override
	protected char[][] enlargeDisplayItem(char[][] displayItem, int size) {
		
		int increaseFactor = (size - 1) * 2;
		char[][] enlargedItem = new char[DisplayItem.DEFAULT_SIZE + increaseFactor][];
		
		for (int i = 0; i < enlargedItem.length; i++) {
			enlargedItem[i] = new char[] {' ', ' ', ' '};
		}
		
		return this.processColon(enlargedItem, size);
	}
	
	/**
	 * @param displayItem
	 * @param size
	 * @return
	 */
	private char[][] processColon(char[][] displayItem, int size) {
		
		int colonSize = 1;
		if (size > 2) {
			colonSize = 2;
		}
		
		int colonSpace = 1;
		if (size > 3) {
			colonSpace = 3;
		}
		
		return this.addColon(displayItem, colonSize, colonSpace);
	}
	
	/**
	 * @param displayItem
	 * @param colonSize
	 * @param colonSpace
	 * @return
	 */
	private char[][] addColon(char[][] displayItem, int colonSize, int colonSpace) {
		
		int startIndex = ((displayItem.length - (2 * colonSize) - colonSpace) / 2);
		
		int index = 0; 
		while (index < ((colonSize * 2) + colonSpace)) {
			
			char[] line = displayItem[startIndex + index];
			line[((line.length - 1) / 2)] = DisplayItem.DISPLAY_CHAR;
			index++;
			
			if (index == colonSize) {
				index = index + colonSpace;
			}
		}
		
		return displayItem;
	}
	
}
