/**
 * 
 */
package nl.sogyo.clock;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import nl.sogyo.clock.display.BlankSeparator;
import nl.sogyo.clock.display.ColonSeparator;
import nl.sogyo.clock.display.DisplayItem;
import nl.sogyo.clock.display.TimeDisplayer;
import nl.sogyo.clock.display.letters.A;
import nl.sogyo.clock.display.letters.M;
import nl.sogyo.clock.display.letters.P;
import nl.sogyo.clock.display.number.Eight;
import nl.sogyo.clock.display.number.Five;
import nl.sogyo.clock.display.number.Four;
import nl.sogyo.clock.display.number.Nine;
import nl.sogyo.clock.display.number.One;
import nl.sogyo.clock.display.number.Seven;
import nl.sogyo.clock.display.number.Six;
import nl.sogyo.clock.display.number.Three;
import nl.sogyo.clock.display.number.Two;
import nl.sogyo.clock.display.number.Zero;

/**
 * @author rvvugt
 *
 */
public class Clock {
	
	// See:
	//	- http://patorjk.com/software/taag/#p=display&f=3x5&t=0123456789%20AM%20PM
	//	- http://intranet.bloomu.edu/documents/fin_bus_svcs/MilitaryTimeConversion.pdf

	private boolean is24HourDisplay = true;
	private int size = 1;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Clock clock = new Clock();
		clock.processInputArguments(Arrays.asList(args));
		
		LocalTime time = LocalTime.now();
		int hours = time.getHour();
		int minutes = time.getMinute();

		List<DisplayItem> timeList = new ArrayList<DisplayItem>();
		clock.processHours(timeList, hours, clock.size);
		timeList.add(new ColonSeparator(clock.size));
		clock.processHoursAndMinutes(timeList, minutes, clock.size);
		clock.addAM_PM(timeList, time, clock.size);

// FOR TESTING:
//		timeList.add(new Zero(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new One(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new Two(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new Three(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new Four(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new Five(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new Six(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new Seven(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new Eight(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new Nine(size));
//		timeList.add(new ColonSeparator(size));
//		timeList.add(new A(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new P(size));
//		timeList.add(new BlankSeparator(size));
//		timeList.add(new M(size));
		
		TimeDisplayer timeDisplayer = new TimeDisplayer();
		timeDisplayer.printTime(timeDisplayer.processTime(timeList, clock.size));
	}
	
	/**
	 * @param args
	 */
	private void processInputArguments(List<String> args) {
		
		if (args.size() > 3) {
			throw new IllegalArgumentException("Invalid number of arguments.");
		}
		
		this.processDisplaySize(args);
		this.process12Or24HourDisplay(args);
	}
	
	/**
	 * @param args
	 */
	private void processDisplaySize(List<String> args) {
		
		int indexOfSize = args.indexOf("-s");
		if (indexOfSize >= 0) {
			if (indexOfSize + 1 == args.size()) {
				throw new IllegalArgumentException("'-s' argument should be followed by a number (min=1 and max=5).");
			}
			this.size = Integer.parseInt(args.get(indexOfSize + 1));
			if (size < 1 || size > 5) {
				throw new IllegalArgumentException("Invalid value for '-s' argument, should be a number (min=1 and max=5).");
			}
		}		
	}
	
	/**
	 * @param args
	 */
	private void process12Or24HourDisplay(List<String> args) {
		
		int _12HourDisplay = args.indexOf("-12");
		int _24HourDisplay = args.indexOf("-24");
		if (_12HourDisplay >= 0 & _24HourDisplay >= 0) {
			throw new IllegalArgumentException("Invalid to specify both 12 and 24 hour display at the same time.");
		}
		if (_12HourDisplay >= 0) {
			this.is24HourDisplay = false;
		}
	}
	
	/**
	 * @param timeList
	 * @param time
	 * @param size
	 */
	private void processHours(List<DisplayItem> timeList, int time, int size) {
		
		if ( !this.is24HourDisplay ) {
			if (time > 12) {
				time -= 12;
			}
			if (time == 0) {
				time += 12;
			}
		}
		
		this.processHoursAndMinutes(timeList, time, size);
	}
	
	/**
	 * @param timeList
	 * @param time
	 * @param size
	 */
	private void processHoursAndMinutes(List<DisplayItem> timeList, int time, int size) {
		
		int firstNumber = time / 10;
		this.addNumberToTime(timeList, firstNumber, size);
		timeList.add(new BlankSeparator(size));
		int secondNumber = time % 10;
		this.addNumberToTime(timeList, secondNumber, size);		
	}
	
	/**
	 * @param timeList
	 * @param number
	 * @param size
	 */
	private void addNumberToTime(List<DisplayItem> timeList, int number, int size) {
		
		switch(number) {
			case 0:
				timeList.add(new Zero(size));
				break;
			case 1:
				timeList.add(new One(size));
				break;
			case 2:
				timeList.add(new Two(size));
				break;
			case 3:
				timeList.add(new Three(size));
				break;
			case 4:
				timeList.add(new Four(size));
				break;
			case 5:
				timeList.add(new Five(size));
				break;
			case 6:
				timeList.add(new Six(size));
				break;
			case 7:
				timeList.add(new Seven(size));
				break;
			case 8:
				timeList.add(new Eight(size));
				break;
			case 9:
				timeList.add(new Nine(size));
				break;
		}
	}
	
	/**
	 * @param timeList
	 * @param time
	 * @param size
	 */
	private void addAM_PM(List<DisplayItem> timeList, LocalTime time, int size) {
		
		if ( !this.is24HourDisplay ) {
			timeList.add(new BlankSeparator(size));
			if (time.getHour() < 12) {
				timeList.add(new A(size));
			} else {
				timeList.add(new P(size));
			}
			timeList.add(new BlankSeparator(size));
			timeList.add(new M(size));
		}
	}
	
}
