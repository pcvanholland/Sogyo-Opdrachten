/**
 * 
 */
package nl.sogyo.clock.display.number;

import nl.sogyo.clock.display.DisplayItem;
import nl.sogyo.clock.display.EnlargedCharacterResult;

/**
 * @author rvvugt
 *
 */
public class Three extends Number {
	
	public static final char[][] THREE = {
		{'#', '#', '#'},
		{' ', ' ', '#'},
		{' ', '#', '#'},
		{' ', ' ', '#'},
		{'#', '#', '#'}
	};
	
	/**
	 * 
	 */
	public Three() {
		
		super(Three.THREE);
	}
	
	/**
	 * 
	 */
	public Three(int size) {
		
		super(Three.THREE, size);
	}

	@Override
	public char[][] getNumber() {
		
		if (1 == this.getSize()) {
			return Three.THREE;
		} else {
			return this.enlargeDisplayItem(Three.THREE, this.getSize());
		}
	}
	
	@Override
	protected EnlargedCharacterResult enlarge(String line, int increaseFactor, EnlargedCharacterResult enlargedNumberResult) {
		
// TAKE ANOTHER LOOK AND REFACTOR THIS METHOD!
// TODO: REFACTOR
				
		String replacement = "";
		String replacement2 = "";
		switch(line) {
			case "###":
				for (int i = 0; i < increaseFactor; i++) {
					line += DisplayItem.DISPLAY_CHAR;
				}
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				break;
			case "  #":
				for (int i = 0; i <= (increaseFactor / 2); i++) {
					replacement += " ";
				}
				replacement += replacement;
				line = line.replace("  ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				for (int i = 0; i < (increaseFactor / 2); i++) {
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
			case " ##":
				for (int i = 0; i <= (increaseFactor / 2); i++) {
					replacement += " ";
				}
				line = line.replace(" ", replacement);
				for (int i = 0; i <= (increaseFactor / 2); i++) {
					replacement2 += "#";
				}
				replacement2 = replacement2 + "#";
				line = line.replace("##", replacement2);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				break;
		}
		
		return enlargedNumberResult;
	}
	
}
