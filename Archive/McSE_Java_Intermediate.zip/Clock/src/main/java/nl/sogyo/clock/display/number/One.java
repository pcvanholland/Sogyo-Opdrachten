/**
 * 
 */
package nl.sogyo.clock.display.number;

import nl.sogyo.clock.display.DisplayItem;
import nl.sogyo.clock.display.EnlargedCharacterResult;

/**
 * @author rvvugt
 *
 */
public class One extends Number {
	
	public static final char[][] ONE = {
		{' ', '#', ' '},
		{'#', '#', ' '},
		{' ', '#', ' '},
		{' ', '#', ' '},
		{'#', '#', '#'}
	};
	
	/**
	 * 
	 */
	public One() {
		
		super(One.ONE);
	}
	
	/**
	 * 
	 */
	public One(int size) {
		
		super(One.ONE, size);
	}

	@Override
	public char[][] getNumber() {
		
		if (1 == this.getSize()) {
			return One.ONE;
		} else {
			return this.enlargeDisplayItem(One.ONE, this.getSize());
		}
	}
	
	@Override
	protected EnlargedCharacterResult enlarge(String line, int increaseFactor, EnlargedCharacterResult enlargedNumberResult) {
		
// TAKE ANOTHER LOOK AND REFACTOR THIS METHOD!
// TODO: REFACTOR
				
		String replacement = "";
		switch(line) {
			case "###":
				for (int i = 0; i < increaseFactor; i++) {
					line += DisplayItem.DISPLAY_CHAR;
				}
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				break;
			case " # ":
				for (int i = 0; i < (increaseFactor / 2) + 1; i++) {
					replacement += " ";
				}
				replacement = replacement + "#" + replacement;
				line = line.replace(" # ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				if (enlargedNumberResult.getNumberOfLinesAdded() > 0) {
					while (enlargedNumberResult.getNumberOfLinesAdded() < increaseFactor) {
						enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
						enlargedNumberResult.increaseNumberOfLinesAdded();
					}
				}
				break;
			case "## ":
				for (int i = 0; i < (increaseFactor / 2); i++) {
					replacement += " ";
				}
				replacement = replacement + "## " + replacement;
				line = line.replace("## ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				while (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor / 2)) {
					line = line.replaceFirst(" #", "# ");
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
		}
		
		return enlargedNumberResult;
	}
	
}
