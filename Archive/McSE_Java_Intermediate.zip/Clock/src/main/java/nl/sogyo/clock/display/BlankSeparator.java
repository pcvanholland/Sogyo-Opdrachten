/**
 * 
 */
package nl.sogyo.clock.display;

/**
 * @author rvvugt
 *
 */
public class BlankSeparator extends DisplayItem {
	
	public static final char[][] BLANK = {
		{' '},
		{' '},
		{' '},
		{' '},
		{' '}
	};
	
	/**
	 * 
	 */
	public BlankSeparator() {
		
		super(BlankSeparator.BLANK);
	}
	
	/**
	 * 
	 */
	public BlankSeparator(int size) {
		
		super(BlankSeparator.BLANK, size);
	}
	
	/**
	 * @return
	 */
	public char[][] getLines() {
		
		if (1 == this.getSize()) {
			return BlankSeparator.BLANK;
		} else {
			return this.enlargeDisplayItem(BlankSeparator.BLANK, this.getSize());
		}
	}
	
	@Override
	protected char[][] enlargeDisplayItem(char[][] displayItem, int size) {
		
		char[] separator;
		if (size <= 3) {
			separator = new char[] {' '};
		} else {
			separator = new char[] {' ', ' '};
		}
		
		int increaseFactor = (size - 1) * 2;
		char[][] enlargedItem = new char[DisplayItem.DEFAULT_SIZE + increaseFactor][];
		
		for (int i = 0; i < enlargedItem.length; i++) {
			enlargedItem[i] = separator;
		}
		
		return enlargedItem;
	}
	
}
