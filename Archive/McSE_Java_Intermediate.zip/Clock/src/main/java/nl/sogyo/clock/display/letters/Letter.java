/**
 * 
 */
package nl.sogyo.clock.display.letters;

import nl.sogyo.clock.display.NumberOrLetterCharacter;

/**
 * @author rvvugt
 *
 */
public abstract class Letter extends NumberOrLetterCharacter {
	
	/**
	 * @param letter
	 */
	public Letter(char[][] letter) {
		
		super(letter);
	}

	/**
	 * @param letter
	 */
	public Letter(char[][] letter, int size) {
		
		super(letter, size);
	}
	
	@Override
	public char[][] getLines() {
		
		return this.getLetter();
	}
	
	/**
	 * @return
	 */
	public abstract char[][] getLetter();
	
}
