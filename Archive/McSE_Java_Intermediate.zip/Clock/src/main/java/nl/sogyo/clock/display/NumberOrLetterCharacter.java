/**
 * 
 */
package nl.sogyo.clock.display;


/**
 * @author rvvugt
 *
 */
public abstract class NumberOrLetterCharacter extends DisplayItem {

	/**
	 * @param numberOrLetter
	 */
	public NumberOrLetterCharacter(char[][] numberOrLetter) {
		
		super(numberOrLetter);
	}

	/**
	 * @param numberOrLetter
	 * @param size
	 */
	public NumberOrLetterCharacter(char[][] numberOrLetter, int size) {
		
		super(numberOrLetter, size);
	}
	
	@Override
	protected char[][] enlargeDisplayItem(char[][] displayItem, int size) {
		
		int increaseFactor = (size - 1) * 2;
		char[][] enlargedCharacter = new char[DisplayItem.DEFAULT_SIZE + increaseFactor][DisplayItem.DEFAULT_WIDTH + increaseFactor];
		EnlargedCharacterResult enlargedCharacterResult = new EnlargedCharacterResult(enlargedCharacter);
		
		for (char[] line: displayItem) {
			enlargedCharacterResult = this.processCharacterLine(line, increaseFactor, enlargedCharacterResult);
		}
		
		return enlargedCharacterResult.getEnlargedNumber();
	}
	
	/**
	 * @param line
	 * @param increaseFactor
	 * @param enlargedCharacterResult
	 * @return
	 */
	protected EnlargedCharacterResult processCharacterLine(char[] line, int increaseFactor, EnlargedCharacterResult enlargedCharacterResult) {
		
		String inputLine = "";
		for (char character: line) {
			inputLine += character;
		}
		return this.enlarge(inputLine, increaseFactor, enlargedCharacterResult);
	}
	
	/**
	 * @param line
	 * @param increaseFactor
	 * @param enlargedCharacterResult
	 * @return
	 */
	protected abstract EnlargedCharacterResult enlarge(String line, int increaseFactor, EnlargedCharacterResult enlargedCharacterResult);
	
	/**
	 * @param line
	 * @param enlargedNumber
	 * @return
	 */
	protected EnlargedCharacterResult processResultLine(String line, EnlargedCharacterResult enlargedCharacterResult) {
		
		enlargedCharacterResult.increaseCurrentLineIndex();
		if (enlargedCharacterResult.getCurrentLineIndex() + 1 <= enlargedCharacterResult.getEnlargedNumber().length) {
			
			enlargedCharacterResult.getEnlargedNumber()[enlargedCharacterResult.getCurrentLineIndex()] = line.toCharArray();
		}
		
		return enlargedCharacterResult;
	}
	
}
