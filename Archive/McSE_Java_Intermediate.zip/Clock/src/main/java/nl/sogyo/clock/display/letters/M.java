/**
 * 
 */
package nl.sogyo.clock.display.letters;

import nl.sogyo.clock.display.DisplayItem;
import nl.sogyo.clock.display.EnlargedCharacterResult;


/**
 * @author rvvugt
 *
 */
public class M extends Letter {

	public static final char[][] LETTER_M = {
		{'#', ' ', '#'},
		{'#', '#', '#'},
		{'#', '#', '#'},
		{'#', ' ', '#'},
		{'#', ' ', '#'}
	};
	
	/**
	 * 
	 */
	public M() {
		
		super(M.LETTER_M);
	}
	
	/**
	 * 
	 */
	public M(int size) {
		
		super(M.LETTER_M, size);
	}

	@Override
	public char[][] getLetter() {
		
		if (1 == this.getSize()) {
			return M.LETTER_M;
		} else {
			return this.enlargeDisplayItem(M.LETTER_M, this.getSize());
		}
	}
	
	@Override
	protected EnlargedCharacterResult enlarge(String line, int increaseFactor, EnlargedCharacterResult enlargedNumberResult) {
		
// TAKE ANOTHER LOOK AND REFACTOR THIS METHOD!
// TODO: REFACTOR
				
		String replacement = "";
		switch(line) {
			case "###":
				if (enlargedNumberResult.getNumberOfLinesAdded() == 0) {
					for (int i = 0; i < (increaseFactor - 1); i++) {
						replacement += " ";
					}
					line = line.replaceFirst("##", "##" + replacement + "#");
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
					if (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor / 2)) {
						String insertSpace = " ";
						String toReplace = "#" + replacement + "#";
						for (int i = 0; i < (increaseFactor / 2 - 1); i++) {
							replacement = replacement.substring(0, replacement.length() - 2);
							StringBuilder replaceWith = new StringBuilder();
							replaceWith.append(insertSpace);
							replaceWith.append(DisplayItem.DISPLAY_CHAR);
							replaceWith.append(replacement);
							replaceWith.append(DisplayItem.DISPLAY_CHAR);
							replaceWith.append(insertSpace);						
							line = line.replace(toReplace, replaceWith.toString());
							enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
							enlargedNumberResult.increaseNumberOfLinesAdded();
							toReplace = replaceWith.toString();
							insertSpace = insertSpace + " ";
						}
					}
				} else {
					for (int i = 0; i < (increaseFactor / 2); i++) {
						replacement += " ";
					}
					line = line.replaceFirst("##", "#" + replacement + "#");
					line = line.replaceFirst("##", "#" + replacement + "#");
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				}
				break;
			case "# #":
				for (int i = 0; i <= increaseFactor; i++) {
					replacement += " ";
				}
				line = line.replace(" ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				if (enlargedNumberResult.getNumberOfLinesAdded() != 0) {
					while (enlargedNumberResult.getNumberOfLinesAdded() < increaseFactor) {
						enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
						enlargedNumberResult.increaseNumberOfLinesAdded();
					}
				}
				break;
		}
		
		return enlargedNumberResult;
	}

}
