/**
 * 
 */
package nl.sogyo.clock.display.number;

import nl.sogyo.clock.display.DisplayItem;
import nl.sogyo.clock.display.EnlargedCharacterResult;

/**
 * @author rvvugt
 *
 */
public class Two extends Number {
	
	public static final char[][] TWO = {
		{'#', '#', '#'},
		{' ', ' ', '#'},
		{'#', '#', '#'},
		{'#', ' ', ' '},
		{'#', '#', '#'}
	};
	
	/**
	 * 
	 */
	public Two() {
		
		super(Two.TWO);
	}
	
	/**
	 * 
	 */
	public Two(int size) {
		
		super(Two.TWO, size);
	}
	
	@Override
	public char[][] getNumber() {
		
		if (1 == this.getSize()) {
			return Two.TWO;
		} else {
			return this.enlargeDisplayItem(Two.TWO, this.getSize());
		}
	}
	
	@Override
	protected EnlargedCharacterResult enlarge(String line, int increaseFactor, EnlargedCharacterResult enlargedNumberResult) {
		
// TAKE ANOTHER LOOK AND REFACTOR THIS METHOD!
// TODO: REFACTOR
				
		String replacement = "";
		switch(line) {
			case "###":
				for (int i = 0; i < increaseFactor; i++) {
					line += DisplayItem.DISPLAY_CHAR;
				}
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				break;
			case "  #":
				for (int i = 0; i <= (increaseFactor / 2); i++) {
					replacement += " ";
				}
				replacement += replacement;
				line = line.replace("  ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				while (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor / 2)) {
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
			case "#  ":
				for (int i = 0; i <= (increaseFactor / 2); i++) {
					replacement += " ";
				}
				replacement += replacement;
				line = line.replace("  ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				while (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor)) {
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
		}
		
		return enlargedNumberResult;
	}
	
}
