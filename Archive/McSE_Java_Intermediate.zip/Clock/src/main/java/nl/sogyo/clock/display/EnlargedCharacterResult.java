/**
 * 
 */
package nl.sogyo.clock.display;

/**
 * @author rvvugt
 *
 */
public class EnlargedCharacterResult {
	
	private char[][] enlargedNumber;
	private int currentLineIndex = -1;
	private int numberOfLinesAdded = 0;
	
	/**
	 * @param enlargedNumber
	 */
	public EnlargedCharacterResult(char[][] enlargedNumber) {
		this.enlargedNumber = enlargedNumber;
	}

	/**
	 * @return
	 */
	public int getCurrentLineIndex() {
		
		return currentLineIndex;
	}

	/**
	 * 
	 */
	public void increaseCurrentLineIndex() {
		
		this.currentLineIndex++;
	}

	/**
	 * @return
	 */
	public int getNumberOfLinesAdded() {
		
		return numberOfLinesAdded;
	}

	/**
	 * 
	 */
	public void increaseNumberOfLinesAdded() {
		
		this.numberOfLinesAdded++;
	}

	/**
	 * @return
	 */
	public char[][] getEnlargedNumber() {
		
		return enlargedNumber;
	}
	
}
