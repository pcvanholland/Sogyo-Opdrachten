/**
 * 
 */
package nl.sogyo.clock.display;

import java.util.ArrayList;
import java.util.List;

/**
 * @author rvvugt
 *
 */
public class TimeDisplayer {

	/**
	 * @param time
	 * @param size
	 * @return
	 */
	public char[][] processTime(List<DisplayItem> time, int size) {
		
		int numberOfLines = DisplayItem.DEFAULT_SIZE + ((size - 1) * 2);
		List<ArrayList<Character>> lines = new ArrayList<ArrayList<Character>>();
		for (int i = 0; i < numberOfLines; i++) {
			lines.add(new ArrayList<Character>());
		}
		
		for (DisplayItem displayItem: time) {
			this.processDisplayItem(lines, displayItem);
		}
		
		return this.processResult(lines);
	}
	
	/**
	 * @param lines
	 * @param displayItem
	 */
	private void processDisplayItem(List<ArrayList<Character>> lines, DisplayItem displayItem) {
		
		char[][] currentDisplayItem = displayItem.getLines();
		int index = 0;
		for (char[] line: currentDisplayItem) {
			
			this.processLine(lines.get(index), line);
			index++;
		}
	}
	
	/**
	 * @param resultLine
	 * @param line
	 */
	private void processLine(ArrayList<Character> resultLine, char[] line) {
		
		for (char character: line) {
			
			resultLine.add(character);
		}
	}
	
	/**
	 * @param lines
	 * @return
	 */
	private char[][] processResult(List<ArrayList<Character>> lines) {
		
		char[][] result = new char[lines.size()][lines.get(0).size()];
		
		int index = 0;
		for (ArrayList<Character> line: lines) {
			this.processResultLine(result, index, line);
			index++;
		}
		
		return result;
	}
	
	/**
	 * @param result
	 * @param currentLine
	 * @param line
	 * @return
	 */
	private char[][] processResultLine(char[][] result, int currentLine, ArrayList<Character> line) {
		
		int index = 0;
		for (Character character: line) {
			result[currentLine][index] = character;
			index++;
		}
		
		return result;
	}
	
	/**
	 * @param time
	 */
	public void printTime(char[][] time) {
		
		for (char[] line: time) {
			for (char character: line) {
				System.out.print(character);
			}
			System.out.println("");
		}
	}
	
}
