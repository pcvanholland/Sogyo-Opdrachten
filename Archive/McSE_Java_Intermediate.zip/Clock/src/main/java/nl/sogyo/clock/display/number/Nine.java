/**
 * 
 */
package nl.sogyo.clock.display.number;

import nl.sogyo.clock.display.DisplayItem;
import nl.sogyo.clock.display.EnlargedCharacterResult;

/**
 * @author rvvugt
 *
 */
public class Nine extends Number {
	
	public static final char[][] NINE = {
		{'#', '#', '#'},
		{'#', ' ', '#'},
		{'#', '#', '#'},
		{' ', ' ', '#'},
		{'#', '#', '#'}
	};
	
	/**
	 * 
	 */
	public Nine() {
		
		super(Nine.NINE);
	}
	
	/**
	 * 
	 */
	public Nine(int size) {
		
		super(Nine.NINE, size);
	}

	@Override
	public char[][] getNumber() {
		
		if (1 == this.getSize()) {
			return Nine.NINE;
		} else {
			return this.enlargeDisplayItem(Nine.NINE, this.getSize());
		}
	}
	
	@Override
	protected EnlargedCharacterResult enlarge(String line, int increaseFactor, EnlargedCharacterResult enlargedNumberResult) {
		
// TAKE ANOTHER LOOK AND REFACTOR THIS METHOD!
// TODO: REFACTOR
				
		String replacement = "";
		switch(line) {
			case "###":
				for (int i = 0; i < increaseFactor; i++) {
					line += DisplayItem.DISPLAY_CHAR;
				}
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				break;
			case "# #":
				for (int i = 0; i <= increaseFactor; i++) {
					replacement += " ";
				}
				line = line.replace(" ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				while (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor / 2)) {
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
			case "  #":
				for (int i = 0; i <= (increaseFactor / 2); i++) {
					replacement += " ";
				}
				line = line.replace(" ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				while (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor)) {
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
		}
		
		return enlargedNumberResult;
	}
	
}
