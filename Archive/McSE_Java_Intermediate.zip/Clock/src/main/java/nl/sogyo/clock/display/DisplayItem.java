/**
 * 
 */
package nl.sogyo.clock.display;



/**
 * @author rvvugt
 *
 */
public abstract class DisplayItem {

	public static final int DEFAULT_SIZE = 5;
	public static final int DEFAULT_WIDTH = 3;
	public static final char DISPLAY_CHAR = '#';
	
	private char[][] displayItem;
	private int size;
	
	/**
	 * @param displayItem
	 */
	public DisplayItem(char[][] displayItem) {
		
		this.displayItem = displayItem;
		this.size = 1;
	}
	
	/**
	 * @param displayItem
	 * @param size
	 */
	public DisplayItem(char[][] displayItem, int size) {
		
		this.displayItem = displayItem;
		this.size = size;
	}
	
	/**
	 * @return
	 */
	public char[][] getDisplayItem() {
		
		return this.displayItem;
	}
	
	/**
	 * @return
	 */
	public abstract char[][] getLines();
	
	/**
	 * @return
	 */
	public int getSize() {
		
		return this.size;
	}
	
	/**
	 * 
	 */
	public void print() {
		
		for (char[] line: this.displayItem) {
			for (char character: line) {
				System.out.print(character);
			}
			System.out.println("");
		}
	}
	
	/**
	 * @param displayItem
	 * @param size
	 * @return
	 */
	protected abstract char[][] enlargeDisplayItem(char[][] displayItem, int size);
	
}
