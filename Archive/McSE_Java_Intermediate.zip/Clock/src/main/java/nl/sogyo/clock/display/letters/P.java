/**
 * 
 */
package nl.sogyo.clock.display.letters;

import nl.sogyo.clock.display.EnlargedCharacterResult;


/**
 * @author rvvugt
 *
 */
public class P extends Letter {

	public static final char[][] LETTER_P = {
		{'#', '#', ' '},
		{'#', ' ', '#'},
		{'#', '#', ' '},
		{'#', ' ', ' '},
		{'#', ' ', ' '}
	};
	
	/**
	 * 
	 */
	public P() {
		
		super(P.LETTER_P);
	}
	
	/**
	 * 
	 */
	public P(int size) {
		
		super(P.LETTER_P, size);
	}

	@Override
	public char[][] getLetter() {
		
		if (1 == this.getSize()) {
			return P.LETTER_P;
		} else {
			return this.enlargeDisplayItem(P.LETTER_P, this.getSize());
		}
	}
	
	@Override
	protected EnlargedCharacterResult enlarge(String line, int increaseFactor, EnlargedCharacterResult enlargedNumberResult) {
		
// TAKE ANOTHER LOOK AND REFACTOR THIS METHOD!
// TODO: REFACTOR
				
		String replacement = "";
		switch(line) {
			case "## ":
				for (int i = 0; i < increaseFactor; i++) {
					replacement += "#";
				}
				if (increaseFactor <= 4) {
					replacement = "##" + replacement;
				} else {
					replacement = "#" + replacement + " ";
				}
				line = line.replace("##", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				break;
			case "# #":
				if (increaseFactor <= 4) {
					for (int i = 0; i <= increaseFactor; i++) {
						replacement += " ";
					}
					line = line.replace(" ", replacement);
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					while (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor / 2)) {
						enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
						enlargedNumberResult.increaseNumberOfLinesAdded();
					}
				} else {
					for (int i = 0; i < increaseFactor; i++) {
						replacement += " ";
					}
					line = line.replace(" ", replacement) + " ";
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					String originalReplacement = line;
					line = line.replaceFirst(" ", "  ");
					line = line.substring(0, line.length() - 1);
					while (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor / 2 - 1)) {
						enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
						enlargedNumberResult.increaseNumberOfLinesAdded();
					}
					enlargedNumberResult = this.processResultLine(originalReplacement, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
			case "#  ":
				for (int i = 0; i < increaseFactor; i++) {
					replacement += " ";
				}
				replacement = "#" + replacement;
				line = line.replace("#", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				for (int i = 0; i < (increaseFactor / 2); i++) {
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
		}
		
		return enlargedNumberResult;
	}

}
