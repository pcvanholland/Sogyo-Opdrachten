/**
 * 
 */
package nl.sogyo.clock.display.number;

import nl.sogyo.clock.display.DisplayItem;
import nl.sogyo.clock.display.EnlargedCharacterResult;

/**
 * @author rvvugt
 *
 */
public class Four extends Number {
	
	public static final char[][] FOUR = {
		{'#', ' ', '#'},
		{'#', ' ', '#'},
		{'#', '#', '#'},
		{' ', ' ', '#'},
		{' ', ' ', '#'}
	};
	
	/**
	 * 
	 */
	public Four() {
		
		super(Four.FOUR);
	}
	
	/**
	 * 
	 */
	public Four(int size) {
		
		super(Four.FOUR, size);
	}

	@Override
	public char[][] getNumber() {
		
		if (1 == this.getSize()) {
			return Four.FOUR;
		} else {
			return this.enlargeDisplayItem(Four.FOUR, this.getSize());
		}
	}
	
	@Override
	protected EnlargedCharacterResult enlarge(String line, int increaseFactor, EnlargedCharacterResult enlargedNumberResult) {
		
// TAKE ANOTHER LOOK AND REFACTOR THIS METHOD!
// TODO: REFACTOR
				
		String replacement = "";
		switch(line) {
			case "# #":
				for (int i = 0; i <= increaseFactor; i++) {
					replacement += " ";
				}
				line = line.replace(" ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				while (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor / 2)) {
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
			case "###":
				for (int i = 0; i < increaseFactor; i++) {
					line += DisplayItem.DISPLAY_CHAR;
				}
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				break;
			case "  #":
				for (int i = 0; i <= (increaseFactor / 2); i++) {
					replacement += " ";
				}
				replacement += replacement;
				line = line.replace("  ", replacement);
				enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
				while (enlargedNumberResult.getNumberOfLinesAdded() < (increaseFactor)) {
					enlargedNumberResult = this.processResultLine(line, enlargedNumberResult);
					enlargedNumberResult.increaseNumberOfLinesAdded();
				}
				break;
		}
		
		return enlargedNumberResult;
	}
	
}
