/**
 * 
 */
package nl.sogyo.clock.display.number;

import nl.sogyo.clock.display.NumberOrLetterCharacter;

/**
 * @author rvvugt
 *
 */
public abstract class Number extends NumberOrLetterCharacter {

	/**
	 * @param number
	 */
	public Number(char[][] number) {
		
		super(number);
	}
	
	/**
	 * @param number
	 */
	public Number(char[][] number, int size) {
		
		super(number, size);
	}
	
	@Override
	public char[][] getLines() {
		
		return this.getNumber();
	}
	
	/**
	 * @return
	 */
	public abstract char[][] getNumber();
	
}
