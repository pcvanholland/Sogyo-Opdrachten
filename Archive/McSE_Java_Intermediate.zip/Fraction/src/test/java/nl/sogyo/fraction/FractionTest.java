/**
 * 
 */
package nl.sogyo.fraction;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class FractionTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void toStringTest() {
		
		Fraction fraction = new Fraction(1, 3);
		assertTrue("1/3".equalsIgnoreCase(fraction.toString()));
	}
	
	@Test
	public void toDecimalNotationTest() {
		
		Fraction fraction = new Fraction(1, 3);
		assertEquals(0.3333333333333333, fraction.toDecimalNotation(), 0.0000000000000001);
	}
	
	@Test
	public void addTest() {
		
		Fraction fraction = new Fraction(1, 3);
		fraction.add(1);
		assertTrue("4/3".equalsIgnoreCase(fraction.toString()));
		assertEquals(1.3333333333333333, fraction.toDecimalNotation(), 0.0000000000000001);
	}
	
	@Test
	public void addFractionTest() {
		
		Fraction fraction = new Fraction(1, 3);
		fraction.add(new Fraction(1, 6));
		assertTrue("1/2".equalsIgnoreCase(fraction.toString()));
		assertEquals(0.5, fraction.toDecimalNotation(), 0.0000000000000001);
	}
	
	@Test
	public void subtractTest() {
		
		Fraction fraction = new Fraction(4, 3);
		fraction.subtract(1);
		assertTrue("1/3".equalsIgnoreCase(fraction.toString()));
		assertEquals(0.3333333333333333, fraction.toDecimalNotation(), 0.0000000000000001);
	}
	
	@Test
	public void subtractFractionTest() {
		
		Fraction fraction = new Fraction(1, 2);
		fraction.subtract(new Fraction(1, 6));
		assertTrue("1/3".equalsIgnoreCase(fraction.toString()));
		assertEquals(0.3333333333333333, fraction.toDecimalNotation(), 0.0000000000000001);
	}
	
	@Test
	public void multiplyTest() {
		
		Fraction fraction = new Fraction(3, 4);
		fraction.multiply(2);
		assertTrue("3/2".equalsIgnoreCase(fraction.toString()));
		assertEquals(1.5, fraction.toDecimalNotation(), 0.0000000000000001);
	}
	
	@Test
	public void multiplyFractionTest() {
		
		Fraction fraction = new Fraction(3, 4);
		fraction.multiply(new Fraction(2, 5));
		assertTrue("3/10".equalsIgnoreCase(fraction.toString()));
		assertEquals(0.3, fraction.toDecimalNotation(), 0.0000000000000001);
	}
	
	@Test
	public void divideTest() {
		
		Fraction fraction = new Fraction(3, 2);
		fraction.divide(2);
		assertTrue("3/4".equalsIgnoreCase(fraction.toString()));
		assertEquals(0.75, fraction.toDecimalNotation(), 0.0000000000000001);
	}
	
	@Test
	public void divideFractionTest() {
		
		Fraction fraction = new Fraction(3, 10);
		fraction.divide(new Fraction(2, 5));
		assertTrue("3/4".equalsIgnoreCase(fraction.toString()));
		assertEquals(0.75, fraction.toDecimalNotation(), 0.0000000000000001);
	}
	
}
