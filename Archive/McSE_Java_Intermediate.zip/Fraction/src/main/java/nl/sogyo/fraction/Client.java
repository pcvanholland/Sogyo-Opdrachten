/**
 * 
 */
package nl.sogyo.fraction;


/**
 * @author rvvugt
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Fraction fraction = new Fraction(3, 10);
//		fraction.divide(2);
		fraction.divide(new Fraction(2, 5));
		System.out.println(fraction.toString());
		System.out.println(fraction.toDecimalNotation());
	}

}
