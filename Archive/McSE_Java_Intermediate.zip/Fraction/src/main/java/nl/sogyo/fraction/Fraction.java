/**
 * 
 */
package nl.sogyo.fraction;

/**
 * @author rvvugt
 *
 */
public class Fraction {
	
	private int numerator;
	private int denominator;
	
	/**
	 * @param numerator
	 * @param denominator
	 */
	public Fraction(int numerator, int denominator) {
		
		this.numerator = numerator;
		this.denominator = denominator;
		
		if (denominator <= 0) {
			throw new IllegalArgumentException("Denominator must be greater than 0.");
		}
	}
	
	/**
	 * @return
	 */
	public int getNumerator() {
		
		return this.numerator;
	}
	
	/**
	 * @return
	 */
	public int getDenominator() {
		
		return this.denominator;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		
		return this.numerator + "/" + this.denominator;
	}
	
	/**
	 * @return
	 */
	public double toDecimalNotation() {
		
		return Double.valueOf(this.numerator) / Double.valueOf(this.denominator);
	}
	
	/**
	 * @param number
	 * @return
	 */
	public Fraction add(int number) {
		
		this.numerator += (number * this.denominator);
		this.normalizeFraction();
		
		return this;
	}
	
	/**
	 * @param fraction
	 * @return
	 */
	public Fraction add(Fraction fraction) {
		
		int numeratorA = this.numerator * fraction.denominator;
		int numeratorB = fraction.numerator * this.denominator;
		this.numerator = numeratorA + numeratorB;

		this.denominator = this.denominator * fraction.denominator;
		this.normalizeFraction();
		
		return this;
	}
	
	/**
	 * @param number
	 * @return
	 */
	public Fraction subtract(int number) {
		
		this.numerator -= (number * this.denominator);
		this.normalizeFraction();
		
		return this;
	}
	
	/**
	 * @param fraction
	 * @return
	 */
	public Fraction subtract(Fraction fraction) {
		
		int numeratorA = this.numerator * fraction.denominator;
		int numeratorB = fraction.numerator * this.denominator;
		this.numerator = numeratorA - numeratorB;

		this.denominator = this.denominator * fraction.denominator;
		this.normalizeFraction();
		
		return this;
	}
	
	/**
	 * @param number
	 * @return
	 */
	public Fraction multiply(int number) {
		
		this.numerator *= number;
		this.normalizeFraction();
		
		return this;
	}
	
	/**
	 * @param fraction
	 * @return
	 */
	public Fraction multiply(Fraction fraction) {
		
		this.numerator = this.numerator * fraction.numerator;
		this.denominator = this.denominator * fraction.denominator;
		this.normalizeFraction();
		
		return this;
	}
	
	/**
	 * @param number
	 * @return
	 */
	public Fraction divide(int number) {
		
		this.denominator *= number;
		this.normalizeFraction();
		
		return this;
	}
	
	/**
	 * @param fraction
	 * @return
	 */
	public Fraction divide(Fraction fraction) {
		
		this.numerator *= fraction.denominator;
		this.denominator *= fraction.numerator;
		this.normalizeFraction();
		
		return this;
	}
	
	/**
	 * 
	 */
	private void normalizeFraction() {
		
		boolean normalizationIncomplete = false;
		
		//TODO: Not the best way to do this, so REFACTOR!
		do {
			normalizationIncomplete = !normalizationIncomplete & !this.normalizeBy(2) & !this.normalizeBy(3) & !this.normalizeBy(5) & !this.normalizeBy(7);
		} while ( !normalizationIncomplete );
	}
	
	/**
	 * @param number
	 * @return
	 */
	private boolean normalizeBy(int number) {
		
		if (this.numerator % number == 0 && this.denominator % number == 0) {
			this.numerator /= number;
			this.denominator /= number;
			return true;
		} else {
			return false;
		}
	}
	
}
