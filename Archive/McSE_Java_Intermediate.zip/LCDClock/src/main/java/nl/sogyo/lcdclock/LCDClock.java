/**
 * 
 */
package nl.sogyo.lcdclock;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author rvvugt
 *
 */
public class LCDClock {
	
	private boolean is24HourDisplay = true;
	private int size = 1;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		LCDClock clock = new LCDClock();		
		clock.processInputArguments(new ArrayList<String>(Arrays.asList(args)));

		LocalTime time = LocalTime.now();
		char[] timeArray = clock.convertTimeToArray(time);
		System.out.print(clock.makeLCDClockString(timeArray, clock.size));
	}
	
	/**
	 * @param args
	 */
	private void processInputArguments(List<String> args) {
		
		if (args.size() > 3) {
			throw new IllegalArgumentException("Invalid number of arguments.");
		}
		
		this.processDisplaySize(args);
		this.process12Or24HourDisplay(args);
	}
	
	/**
	 * @param args
	 */
	private void processDisplaySize(List<String> args) {
		
		int indexOfSize = args.indexOf("-s");
		if (indexOfSize >= 0) {
			if (indexOfSize + 1 == args.size()) {
				throw new IllegalArgumentException("'-s' argument should be followed by a number (min=1 and max=5).");
			}
			this.size = Integer.parseInt(args.get(indexOfSize + 1));
			if (size < 1 || size > 5) {
				throw new IllegalArgumentException("Invalid value for '-s' argument, should be a number (min=1 and max=5).");
			}
		}		
	}
	
	/**
	 * @param args
	 */
	private void process12Or24HourDisplay(List<String> args) {
		
		int _12HourDisplay = args.indexOf("-12");
		int _24HourDisplay = args.indexOf("-24");
		if (_12HourDisplay >= 0 & _24HourDisplay >= 0) {
			throw new IllegalArgumentException("Invalid to specify both 12 and 24 hour display at the same time.");
		}
		if (_12HourDisplay >= 0) {
			this.is24HourDisplay = false;
		}
	}
	
	/**
	 * @param time
	 * @return
	 */
	private char[] convertTimeToArray(LocalTime time) {
		
		char[] resultTimeArray;
		if ( !is24HourDisplay ) {
			// "H H : m m AM"
			resultTimeArray = new char[13];
		} else {
			// "H H : m m"
			resultTimeArray = new char[10];
		}
		
		if ( !is24HourDisplay ) {
			
			resultTimeArray = this.addAM_PM(resultTimeArray, time);
			if (time.getHour() > 12) {
				time = time.minusHours(12);
			}
			if (time.getHour() == 0) {
				time = time.plusHours(12);
			}
		}
		
		char[] timeArray = time.toString().toCharArray();
		int index = 0;
		for (int i = 0; i < 5; i++) // HH:mm = 5
		{
			resultTimeArray[index] = timeArray[i];
			index++;
			resultTimeArray[index] = ' ';
			index++;
		}
		resultTimeArray[resultTimeArray.length - 1] = '\n';
		
		return resultTimeArray;
	}

	/**
	 * @param timeList
	 * @param time
	 * @param size
	 */
	private char[] addAM_PM(char[] timeArray, LocalTime time) {
		
		if ( !this.is24HourDisplay ) {
			if (time.getHour() < 12) {
				timeArray[timeArray.length - 3] = 'A';
			} else {
				timeArray[timeArray.length - 3] = 'P';
			}
			timeArray[timeArray.length - 2] = 'M';
			timeArray[timeArray.length - 1] = '\n';
		}
		
		return timeArray;
	}
	
	/**
	 * @param timeArray
	 * @param size
	 * @return
	 */
	private String makeLCDClockString(char[] timeArray, int size) {

		List<StringBuilder> timeDisplayLines = new ArrayList<StringBuilder>();
		for (int i = 0; i < this.calculateCharacterHeight(size); i++) {
			timeDisplayLines.add(new StringBuilder());
		}
		
		for (int i = 0; i < timeArray.length; i++) {
			char[][] characterArray = getCharacterArray(timeArray[i]);
			List<ArrayList<Character>> scaledCharacter = scaleCharacter(characterArray, size);
			this.addScaledCharacterToTimeDisplayLines(timeDisplayLines, scaledCharacter);
		}
		
		return this.timeDisplayLinesToString(timeDisplayLines);
	}
	
	/**
	 * @param character
	 * @return
	 */
	private char[][] getCharacterArray(char character) {
		
		switch (character) {
			case '0':
				return DisplayItem.ZERO;
			case '1':
				return DisplayItem.ONE;
			case '2':
				return DisplayItem.TWO;
			case '3':
				return DisplayItem.THREE;
			case '4':
				return DisplayItem.FOUR;
			case '5':
				return DisplayItem.FIVE;
			case '6':
				return DisplayItem.SIX;
			case '7':
				return DisplayItem.SEVEN;
			case '8':
				return DisplayItem.EIGHT;
			case '9':
				return DisplayItem.NINE;
			case ':':
				return DisplayItem.SEPARATOR;
			case ' ':
				return DisplayItem.SPACE;
			case 'A':
				return DisplayItem.A;
			case 'P':
				return DisplayItem.P;
			case 'M':
				return DisplayItem.M;
			case '\n':
				return DisplayItem.NEW_LINE;
			default:
				throw new IllegalArgumentException("Invalid character specified.");
		}
	}

	/**
	 * @param timeDisplayLines
	 * @param scaledCharacter
	 */
	private void addScaledCharacterToTimeDisplayLines(List<StringBuilder> timeDisplayLines, List<ArrayList<Character>> scaledCharacter) {
		
		int lineIndex = 0;
		for (List<Character> characterLine : scaledCharacter) {
			for (char character: characterLine) {
				timeDisplayLines.get(lineIndex).append(character);
			}
			lineIndex++;
		}
	}
	
	/**
	 * @param timeDisplayLines
	 * @return
	 */
	private String timeDisplayLinesToString(List<StringBuilder> timeDisplayLines) {
		
		String displayString = "";
		for (StringBuilder line: timeDisplayLines) {
			displayString += line.toString();
		}
		
		return displayString;
	}
	
	/**
	 * @param character
	 * @param size
	 * @return
	 */
	private List<ArrayList<Character>> scaleCharacter(char[][] character, int size) {
		
		List<ArrayList<Character>> scaledCharacter = new ArrayList<ArrayList<Character>>();
		
		if ((character[0].length == 1) && (character[1][0] != '|')) {
			// Special case for newline, easy to include space as well.
			this.scaleNewLineOrSpace(character[0][0], size, scaledCharacter);
		} else {			
			this.scaleTimeCharacter(character, size, scaledCharacter);
		}
		
		return scaledCharacter;
	}

	/**
	 * @param size
	 * @return
	 */
	private int calculateCharacterHeight(int size) {
		
		return 3 + 2 * size;
	}
	
	/**
	 * @param character
	 * @param size
	 * @param scaledCharacter
	 */
	private void scaleNewLineOrSpace(char character, int size, List<ArrayList<Character>> scaledCharacter) {
		
		int height = calculateCharacterHeight(size);
		ArrayList<Character> fill = new ArrayList<Character>(1);
		fill.add(character);
		for (int i = 0; i < height; i++) {
			scaledCharacter.add(fill);
		}
	}
	
	/**
	 * @param character
	 * @param size
	 * @param scaledCharacter
	 */
	private void scaleTimeCharacter(char[][] character, int size, List<ArrayList<Character>> scaledCharacter) {
		
		for (int lineIndex = 0; lineIndex < character.length; lineIndex++) {
			
			ArrayList<Character> scaledLine = this.createScaledLine(character, size, lineIndex);
			this.addScaledLineToScaledCharacter(scaledCharacter, scaledLine, size, lineIndex);
		}
	}
	
	/**
	 * @param character
	 * @param size
	 * @param lineIndex
	 * @return
	 */
	private ArrayList<Character> createScaledLine(char[][] character, int size, int lineIndex) {
		
		ArrayList<Character> scaledLine = new ArrayList<Character>();
		
		for (int characterIndex = 0; characterIndex < character[lineIndex].length; characterIndex++) {
			if ((characterIndex % 2) == 1) {
				for (int count = 0; count < size; count++) {
					// Odd columns are added *size* times.
					scaledLine.add(character[lineIndex][characterIndex]);
				}
			} else {
				scaledLine.add(character[lineIndex][characterIndex]);
			}
		}
		
		return scaledLine;
	}
	
	/**
	 * @param scaledCharacter
	 * @param scaledLine
	 * @param size
	 * @param lineIndex
	 */
	private void addScaledLineToScaledCharacter(List<ArrayList<Character>> scaledCharacter, ArrayList<Character> scaledLine, int size, int lineIndex) {
		
		if ((lineIndex % 2) == 1) {
			for (int count = 0; count < size; count++) {
				// Odd rows are duplicated *size* times.
				scaledCharacter.add(scaledLine);
			}
		} else {
			scaledCharacter.add(scaledLine);
		}
	}
	
}