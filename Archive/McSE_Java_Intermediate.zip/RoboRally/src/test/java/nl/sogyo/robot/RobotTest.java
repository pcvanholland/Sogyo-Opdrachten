/**
 * 
 */
package nl.sogyo.robot;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class RobotTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void robotTest() {
		
		Robot robot = new Robot();
		robot.turnRight();
		robot.moveForward(3);
		robot.turnRight();
		robot.moveBackward(2);
		robot.turnLeft();
		
		assertEquals("At position [3,2] facing East",robot.displayState());
	}

}
