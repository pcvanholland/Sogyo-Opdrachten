/**
 * 
 */
package nl.sogyo.robot;

/**
 * @author rvvugt
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Robot robot = new Robot();
		robot.setName("Happy");
		System.out.println(robot.getName() + ": " + robot.displayState());
		
		robot.turnRight();
		System.out.println(robot.getName() + ": " + robot.displayState());
		
		robot.moveForward(3);
		System.out.println(robot.getName() + ": " + robot.displayState());

		robot.turnRight();
		System.out.println(robot.getName() + ": " + robot.displayState());
		
		robot.moveBackward(2);
		System.out.println(robot.getName() + ": " + robot.displayState());

		robot.turnLeft();
		System.out.println(robot.getName() + ": " + robot.displayState());
	}

}
