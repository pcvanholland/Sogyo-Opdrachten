/**
 * 
 */
package nl.sogyo.robot;

/**
 * @author rvvugt
 *
 */
public class Robot {

	private int[] position = new int[] {0, 0};
	private Facing facing = Facing.North;
	private String name;
	
	/**
	 * 
	 */
	public Robot() {
		
	}
	
	/**
	 * @param x
	 * @param y
	 * @param facing
	 */
	public Robot(int x, int y, Facing facing) {
		
		this.position = new int[] {x, y};
		this.facing = facing;
	}
	
	/**
	 * 
	 */
	public void turnLeft() {
		
		this.facing = this.facing.turnLeft();
	}
	
	/**
	 * 
	 */
	public void turnRight() {
		
		this.facing = this.facing.turnRight();
	}
	
	/**
	 * @param steps
	 */
	public void moveForward(int steps) {
		
		switch(this.facing) {
			case North:
				this.position[1] += steps;
				break;
			case East:
				this.position[0] += steps;
				break;
			case South:
				this.position[1] -= steps;
				break;
			case West:
				this.position[0] -= steps;
				break;
		}		
	}
	
	/**
	 * @param steps
	 * @param speed
	 */
	public void moveForward(int steps, int speed) {
		
		if (speed < 1 || speed > 3) {
			throw new IllegalArgumentException("Illegal speed specified. Speed can be: 1, 2, or 3.");
		}
		
		this.moveForward(steps * speed);
	}
	
	/**
	 * @param steps
	 */
	public void moveBackward(int steps) {
		
		switch(this.facing) {
		case North:
			this.position[1] -= steps;
			break;
		case East:
			this.position[0] -= steps;
			break;
		case South:
			this.position[1] += steps;
			break;
		case West:
			this.position[0] += steps;
			break;
		}
	}
	
	/**
	 * @return
	 */
	public String displayState() {
		
		return ("At position [" + this.position[0] + "," + this.position[1] + "] facing " + this.facing);
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
}
