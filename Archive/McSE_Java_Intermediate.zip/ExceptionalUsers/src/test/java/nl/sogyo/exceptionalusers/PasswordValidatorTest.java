/**
 * 
 */
package nl.sogyo.exceptionalusers;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class PasswordValidatorTest {

	@Test
	public void validatePasswordSogyo123() {
		assertTrue(PasswordValidator.validate("Sogyo123"));
	}

	@Test
	public void validatePasswordSogyo() {
		assertFalse(PasswordValidator.validate("Sogyo"));
	}

	@Test
	public void validatePasswordNull() {
		assertFalse(PasswordValidator.validate(null));
	}

	@Test
	public void validate2PasswordSogyo123() {
		assertTrue(PasswordValidator.validate2("Sogyo123"));
	}

	@Test
	public void validate2PasswordSogyo() {
		assertFalse(PasswordValidator.validate2("Sogyo"));
	}

}
