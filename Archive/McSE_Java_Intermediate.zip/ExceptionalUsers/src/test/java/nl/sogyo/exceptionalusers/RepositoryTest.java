/**
 * 
 */
package nl.sogyo.exceptionalusers;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class RepositoryTest {

	@Test
	public void addUserWithUsernameSogyoAndPasswordSogyo123Test() {
		Repository repo = new Repository();
		assertTrue(repo.addUser("Sogyo", "Sogyo123"));
	}

	@Test
	public void addUserWithUsernameSogyoAndPasswordSogyoTest() {
		
		try {
			new Repository().addUser("Sogyo", "Sogyo");
			fail();
		} catch (IllegalArgumentException iae) {
			assertEquals("Username and/or password is invalid!", iae.getMessage());
		}
	}

	@Test
	public void addUserWithUsernameNullAndPasswordSogyoTest() {
		
		try {
			new Repository().addUser(null, "Sogyo456");
			fail();
		} catch (IllegalArgumentException iae) {
			assertEquals("Username and/or password is invalid!", iae.getMessage());
		}
	}

	@Test
	public void addUserThatAlreadyExistsTest() {
		
		Repository repo = new Repository();
		repo.addUser("Sogyo", "Sogyo123");
		assertFalse(repo.addUser("Sogyo", "Sogyo123"));
	}

	@Test
	public void validateGoodUserCredentialsTest() {
		
		Repository repo = new Repository();
		repo.addUser("Sogyo", "Sogyo123");
		assertTrue(repo.validateUserCredentials("Sogyo", "Sogyo123"));
	}
	
	@Test
	public void validateBadUserCredentialsTest() {
		
		Repository repo = new Repository();
		repo.addUser("Sogyo", "Sogyo123");
		assertFalse(repo.validateUserCredentials("Sogyo", "Sogyo12"));
	}
	
}
