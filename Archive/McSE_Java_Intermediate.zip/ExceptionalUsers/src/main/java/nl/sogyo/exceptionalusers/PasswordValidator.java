/**
 * 
 */
package nl.sogyo.exceptionalusers;

import java.util.regex.Pattern;

/**
 * @author rvvugt
 *
 */
public class PasswordValidator {

	private static final Pattern[] VALIDATIONS = new Pattern[3];

	static {
		VALIDATIONS[0] = Pattern.compile(".*[A-Z].*");
		VALIDATIONS[1] = Pattern.compile(".*[a-z].*");
		VALIDATIONS[2] = Pattern.compile(".*\\d.*");
	}

	/**
	 * @param password
	 * @return
	 */
	public static boolean validate(String password) {

		boolean passwordGood = true;

		for (Pattern validation : VALIDATIONS) {
			if (password == null || !validation.matcher(password).matches()) {
				passwordGood = false;
				break;
			}
		}

		return passwordGood;
	}

	/**
	 * @param password
	 * @return
	 */
	public static boolean validate2(String password) {
		
		boolean numberPresent = false;
		boolean upperCasePresent = false;
		boolean lowerCasePresent = false;
		char character;
		
		for (int i = 0; i < password.length(); i++) {
			
			character = password.charAt(i);
			if (Character.isDigit(character)) {
				numberPresent = true;
			} else if (Character.isUpperCase(character)) {
				upperCasePresent = true;
			} else if (Character.isLowerCase(character)) {
				lowerCasePresent = true;
			}
		}
		
		return numberPresent && upperCasePresent && lowerCasePresent;
	}

}
