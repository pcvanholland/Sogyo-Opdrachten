/**
 * 
 */
package nl.sogyo.exceptionalusers;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class Client {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {
		
		Scanner scanner = new Scanner(System.in);
		UserInteractionProcessor inputProcessor = new UserInteractionProcessor(scanner);
		
		Repository repo = new Repository();
		
		boolean createUsers = true;
		
		while (createUsers) {
			
			String[] userCredentials = inputProcessor.createNewUser();
			String username = userCredentials[0];
			String password = userCredentials[1];
			
			boolean userAddedToRepo = false;
			if (password != null && PasswordValidator.validate(password)) {
				userAddedToRepo = repo.addUser(username, password);
			}
			if (userAddedToRepo) {
				inputProcessor.printSuccessMessage(username);
				userAddedToRepo = false;
			} else {
				inputProcessor.printUserAlreadyExistsMessage(username);
			}
			
			createUsers = inputProcessor.proceedWithAnotherNewUser();
		}
		
		((Closeable) scanner).close();
	}
	
}
