/**
 * 
 */
package nl.sogyo.exceptionalusers;

import java.util.HashMap;
import java.util.Map;

/**
 * @author rvvugt
 *
 */
public class Repository {

	private Map<String, String> users = new HashMap<String, String>();
	
	/**
	 * @param username
	 * @param password
	 * @return
	 */
	public boolean addUser(String username, String password) {
		
		if (username != null && users.containsKey(username)) {
			return false;
		} else if (username != null && !users.containsKey(username) && PasswordValidator.validate(password)) {
			users.put(username, password);
			return true;
		}
		
		throw new IllegalArgumentException("Username and/or password is invalid!");
	}
	
	/**
	 * @param username
	 * @param password
	 * @return
	 */
	public boolean validateUserCredentials(String username, String password) {
		
		if (users.containsKey(username)) {
			return users.get(username).equals(password);
		} else {
			return false;
		}
	}
	
}
