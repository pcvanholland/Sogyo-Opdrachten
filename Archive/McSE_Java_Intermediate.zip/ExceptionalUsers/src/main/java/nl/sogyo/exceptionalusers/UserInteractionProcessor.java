/**
 * 
 */
package nl.sogyo.exceptionalusers;

import java.io.IOException;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class UserInteractionProcessor {
	
	private Scanner scanner;
	
	/**
	 * @param scanner
	 */
	public UserInteractionProcessor(Scanner scanner) {
		
		this.scanner = scanner;
	}
	
	/**
	 * @throws IOException
	 */
	public String[] createNewUser() throws IOException {
		
		System.out.println();
		String username = this.askQuestion("Enter a username: ");
		System.out.println();
		System.out.println("Passwords should have at least 1 lowercase letter, 1 UPPERCASE letter, and 1 digit!");
		String password = this.askQuestion("Enter a password: ");
		
		boolean passwordValid = PasswordValidator.validate(password);
		
		while (!passwordValid) {
			System.out.println();
			System.out.println("Invalid password, please enter a valid password");
			password = this.askQuestion("Enter a password: ");
			passwordValid = PasswordValidator.validate(password);
		}
		
		return new String[] {username, password};
	}
	
	/**
	 * @param message
	 * @return
	 * @throws IOException
	 */
	private String askQuestion(String message) throws IOException {
		
		String input = "";
		
		System.out.print(message + " ");
       	input = (scanner.nextLine()).trim();
		
        return input.trim();
	}
	
	/**
	 * @return
	 * @throws IOException
	 */
	public boolean proceedWithAnotherNewUser() throws IOException {
		
		System.out.println();
		String anotherNewUser = this.askQuestion("Would you like to add another new user (Y/N): ");
		System.out.println("------------------------------------------------------------------------");
		
		if ("Y".equalsIgnoreCase(anotherNewUser.trim())) {
			return true;
		} else {
			System.out.println();
			System.out.println("END PROGRAM!");
			return false;
		}
	}
	
	/**
	 * @param username
	 */
	public void printSuccessMessage(String username) {
		System.out.println("Registered user: " + username);
	}
	
	/**
	 * @param username
	 */
	public void printUserAlreadyExistsMessage(String username) {
		System.out.println("User with username '" + username + "' already exists!");
	}
	
}
