/**
 * 
 */
package nl.sogyo.robot.command;

import nl.sogyo.robot.RobotState;

/**
 * @author rvvugt
 *
 */
public class TurnLeftCommand extends Command {

	@Override
	public RobotState execute(RobotState robotState) {
		
		robotState.setFacing(robotState.getFacing().turnLeft());		
		return this.processNextCommand(robotState);
	}
	
}
