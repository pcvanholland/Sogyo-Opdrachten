/**
 * 
 */
package nl.sogyo.robot;

import java.util.Arrays;
import java.util.List;

/**
 * @author rvvugt
 *
 */
public enum Facing {
	
	North,
	East,
	South,
	West;
	
	public Facing turnLeft() {
		
		Facing[] facings = Facing.values();
		List<Facing> facingsList = Arrays.asList(facings);
		int index = facingsList.indexOf(this);
		
		if (index >= 1) {
			return facings[index - 1];
		} else {
			return facings[facings.length - 1];
		}
	}
	
	public Facing turnRight() {
		
		Facing[] facings = Facing.values();
		List<Facing> facingsList = Arrays.asList(facings);
		int index = facingsList.indexOf(this);
		
		if (index == facings.length - 1) {
			return facings[0];
		} else {
			return facings[index + 1];
		}
	}
	
}
