/**
 * 
 */
package nl.sogyo.robot.command;

import nl.sogyo.robot.Facing;
import nl.sogyo.robot.RobotState;

/**
 * @author rvvugt
 *
 */
public class MoveBackwardCommand extends Command {

	private int steps = 0;
	
	/**
	 * @param steps
	 */
	public MoveBackwardCommand(int steps) {
		
		this.steps = steps;
	}
	
	@Override
	public RobotState execute(RobotState robotState) {
		
		int[] position = robotState.getPosition();
		Facing facing = robotState.getFacing();
		
		switch(facing) {
			case North:
				position[1] -= steps;
				break;
			case East:
				position[0] -= steps;
				break;
			case South:
				position[1] += steps;
				break;
			case West:
				position[0] += steps;
				break;
		}
		
		robotState.setPosition(position);
		robotState.setFacing(facing);
		
		return this.processNextCommand(robotState);
	}
	
}
