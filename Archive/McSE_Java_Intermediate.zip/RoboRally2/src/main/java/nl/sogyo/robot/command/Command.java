/**
 * 
 */
package nl.sogyo.robot.command;

import nl.sogyo.robot.RobotState;

/**
 * @author rvvugt
 *
 */
public abstract class Command {

	private Command nextCommand = null;
	
	public abstract RobotState execute(RobotState state);
	
	/**
	 * @return
	 */
	public boolean hasNextCommand() {
		
		if (this.nextCommand != null) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @return
	 */
	public Command getNextCommand() {
		
		return this.nextCommand;
	}

	
	/**
	 * @param nextCommand
	 */
	public void setNextCommand(Command nextCommand) {
		
		this.nextCommand = nextCommand;
	}

	/**
	 * @return
	 */
	public Command getLastCommand() {
		
		if (this.nextCommand != null) {
			return this.nextCommand.getLastCommand();
		} else {
			return this;
		}
	}
	
	/**
	 * @param robot
	 */
	RobotState processNextCommand(RobotState robotState) {
		
		if (this.getNextCommand() != null) {
			return this.getNextCommand().execute(robotState);
		} else {
			return robotState;
		}
	}
	
}
