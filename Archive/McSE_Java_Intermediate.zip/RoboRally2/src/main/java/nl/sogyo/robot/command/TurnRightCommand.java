/**
 * 
 */
package nl.sogyo.robot.command;

import nl.sogyo.robot.RobotState;

/**
 * @author rvvugt
 *
 */
public class TurnRightCommand extends Command {

	@Override
	public RobotState execute(RobotState robotState) {
		
		robotState.setFacing(robotState.getFacing().turnRight());		
		return this.processNextCommand(robotState);
	}
	
}
