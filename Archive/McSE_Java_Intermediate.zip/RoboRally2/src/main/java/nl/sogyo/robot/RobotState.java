/**
 * 
 */
package nl.sogyo.robot;

/**
 * @author rvvugt
 *
 */
public class RobotState {
	
	private int[] position;
	private Facing facing;
	
	/**
	 * @param position
	 * @param facing
	 */
	public RobotState(int[] position, Facing facing) {
		
		this.position = position;
		this.facing = facing;
	}

	/**
	 * @return
	 */
	public int[] getPosition() {
		
		return position;
	}

	/**
	 * @param position
	 */
	public void setPosition(int[] position) {
		
		this.position = position;
	}

	/**
	 * @return
	 */
	public Facing getFacing() {
		
		return facing;
	}

	/**
	 * @param facing
	 */
	public void setFacing(Facing facing) {
		
		this.facing = facing;
	}
	
}
