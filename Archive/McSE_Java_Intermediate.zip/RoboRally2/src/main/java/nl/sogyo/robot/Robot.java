/**
 * 
 */
package nl.sogyo.robot;

import nl.sogyo.robot.command.Command;
import nl.sogyo.robot.command.MoveBackwardCommand;
import nl.sogyo.robot.command.MoveForwardCommand;
import nl.sogyo.robot.command.TurnLeftCommand;
import nl.sogyo.robot.command.TurnRightCommand;

/**
 * @author rvvugt
 *
 */
public class Robot {

	private int[] position = new int[] {0, 0};
	private Facing facing = Facing.North;
	private String name;
	private Command command;
	
	/**
	 * 
	 */
	public Robot() {
		
	}
	
	/**
	 * @param x
	 * @param y
	 * @param facing
	 */
	public Robot(int x, int y, Facing facing) {
		
		this.position = new int[] {x, y};
		this.facing = facing;
	}
	
	/**
	 * 
	 */
	public void turnLeft() {
		
		Command command = new TurnLeftCommand();
		
		if (this.command == null) {
			this.command = command;
		} else {
			this.command.getLastCommand().setNextCommand(command);
		}
	}
	
	/**
	 * 
	 */
	public void turnRight() {
		
		Command command = new TurnRightCommand();
		
		if (this.command == null) {
			this.command = command;
		} else {
			this.command.getLastCommand().setNextCommand(command);
		}
	}
	
	/**
	 * @param steps
	 */
	public void moveForward(int steps) {
		
		Command command = new MoveForwardCommand(steps);
		
		if (this.command == null) {
			this.command = command;
		} else {
			this.command.getLastCommand().setNextCommand(command);
		}
	}
	
	/**
	 * @param steps
	 * @param speed
	 */
	public void moveForward(int steps, int speed) {
				
		Command command = new MoveForwardCommand(steps, speed);
		
		if (this.command == null) {
			this.command = command;
		} else {
			this.command.getLastCommand().setNextCommand(command);
		}
	}
	
	/**
	 * @param steps
	 */
	public void moveBackward(int steps) {
		
		Command command = new MoveBackwardCommand(steps);
		
		if (this.command == null) {
			this.command = command;
		} else {
			this.command.getLastCommand().setNextCommand(command);
		}
	}
	
	/**
	 * 
	 */
	public void execute() {
		
		RobotState resultState = this.getState();
		if (this.command != null) {
			resultState = this.command.execute(resultState);
		}
		
		this.position = resultState.getPosition();
		this.facing = resultState.getFacing();
		this.command = null;
	}
	
	/**
	 * @return
	 */
	public RobotState getState() {
		
		return new RobotState(this.position, this.facing);
	}
	
	/**
	 * @return
	 */
	public String displayState() {
		
		return ("At position [" + this.position[0] + "," + this.position[1] + "] facing " + this.facing);
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return
	 */
	public int[] getPosition() {
		
		return position;
	}

	/**
	 * @return
	 */
	public Facing getFacing() {
		
		return facing;
	}
	
}
