/**
 * 
 */
package nl.sogyo.robot.command;

import nl.sogyo.robot.Facing;
import nl.sogyo.robot.RobotState;

/**
 * @author rvvugt
 *
 */
public class MoveForwardCommand extends Command {

	private int steps = 0;
	
	/**
	 * @param steps
	 */
	public MoveForwardCommand(int steps) {
		
		this.steps = steps;
	}
	
	/**
	 * @param steps
	 * @param speed
	 */
	public MoveForwardCommand(int steps, int speed) {
		
		if (speed < 1 || speed > 3) {
			throw new IllegalArgumentException("Illegal speed specified. Speed can be: 1, 2, or 3.");
		}
		
		this.steps = steps * speed;
	}
	
	@Override
	public RobotState execute(RobotState robotState) {
		
		int[] position = robotState.getPosition();
		Facing facing = robotState.getFacing();
		
		switch(facing) {
			case North:
				position[1] += steps;
				break;
			case East:
				position[0] += steps;
				break;
			case South:
				position[1] -= steps;
				break;
			case West:
				position[0] -= steps;
				break;
		}
		
		robotState.setPosition(position);
		robotState.setFacing(facing);
		
		return this.processNextCommand(robotState);
	}
	
}
