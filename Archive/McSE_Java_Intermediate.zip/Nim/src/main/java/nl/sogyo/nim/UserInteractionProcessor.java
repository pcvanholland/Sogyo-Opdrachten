/**
 * 
 */
package nl.sogyo.nim;

import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * @author rvvugt
 *
 */
public class UserInteractionProcessor {

    private Scanner scanner;
    private int maxNumberOfMatchesPerTurn;
    
    /**
     * @param br
     */
    public UserInteractionProcessor(Scanner scanner, int maxNumberOfMatchesPerTurn) {
    	
    	this.scanner = scanner;
    	this.maxNumberOfMatchesPerTurn = maxNumberOfMatchesPerTurn;
    }
    
    /**
     * @param maxNumberToTake
     */
    public void printInitializationMsg(int maxNumberToTake) {
    	
		System.out.println("This is Nim!");
		System.out.println("The max amount of matches you can take is " + maxNumberToTake);
		System.out.println("Press 'Q' to quite the game");
		System.out.println();
    }
    
	/**
	 * @param namePlayerToMove
	 * @return
	 */
	public int readInput(String namePlayerToMove) {
		
		char input = 'Q';
		boolean validInput = false;
		String pattern = "[1-" + this.maxNumberOfMatchesPerTurn + "Q]";
		
		do {
			System.out.println("Next turn is for " + namePlayerToMove);
			System.out.print("How many do you want to take?: ");
		
			try {
				input = this.scanner.next(Pattern.compile(pattern)).charAt(0);
				validInput = true;
			} catch(Exception e) {
				System.out.println();
				System.err.println("Invalid Format! Please try again.");
				System.out.println();
			} finally {
				// Needed as a kind of "flush" to clear the previous input that was read.
				this.scanner.skip(".*");
			}
		} while ( !validInput );
		System.out.println();
		
		if ( input == 'Q' ) {
			System.err.println("Thank you for playing. Please come again!");
			System.exit(0);
		}
		
        return Character.getNumericValue(input);
	}
	
	/**
	 * @param numberOfMatches
	 */
	public void printNumberOfMatchesMsg(int numberOfMatches) {
		
		System.out.println("There are " + numberOfMatches + " matches.");
	}
	
	/**
	 * 
	 */
	public void printInvalidNumberOfMatchesMsg() {
		
		System.out.println();
		System.out.println("Invalid number of matches.");
		System.out.println("Please try again!");
		System.out.println();
	}
	
	/**
	 * @param winner
	 */
	public void printWinner(String winner) {
		
		System.out.println("Player " + winner + " has WON!");
	}

}
