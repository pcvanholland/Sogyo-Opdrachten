/**
 * 
 */
package nl.sogyo.nim;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class GameRunner {
	
	private Nim nim;
	private Scanner scanner;
    private UserInteractionProcessor userInteractionProcessor;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		GameRunner gameRunner = new GameRunner();
		gameRunner.initialize();
		gameRunner.play();
	}
	
	/**
	 * 
	 */
	private void initialize() {
		
		int numberOfMatches = 11;
		int maxNumberOfMatchesPerTurn = 4;
		
		this.scanner = this.openScannerResource();
		this.userInteractionProcessor = new UserInteractionProcessor(this.scanner, maxNumberOfMatchesPerTurn);
		this.nim = new Nim(numberOfMatches, maxNumberOfMatchesPerTurn);
		
		this.userInteractionProcessor.printInitializationMsg(maxNumberOfMatchesPerTurn);
		this.userInteractionProcessor.printNumberOfMatchesMsg(nim.getNumberOfMatches());
	}
	
	/**
	 * 
	 */
	private void play() {
		
		int numberOfMatchesTaken;
		boolean endOfGame = false;
		
		do {
			numberOfMatchesTaken = this.userInteractionProcessor.readInput(this.nim.getPlayer().getPlayerToMove().getName());
			if ( !nim.isValidNumberOfMatchesTaken(numberOfMatchesTaken) ) {
				this.userInteractionProcessor.printInvalidNumberOfMatchesMsg();
				continue;
			}
			endOfGame = this.nim.processTurn(numberOfMatchesTaken);
			
			this.userInteractionProcessor.printNumberOfMatchesMsg(nim.getNumberOfMatches());
			
		} while ( !endOfGame );
		
		this.userInteractionProcessor.printWinner(this.nim.getPlayer().getWinner().getName());

        try {
        	this.closeScannerResource(this.scanner);
        } catch ( IOException ioe ) {
        	System.err.println(ioe.getMessage());
        }
	}
	
	/**
	 * @return
	 */
	private Scanner openScannerResource() {
		
		return new Scanner(System.in);
	}
	
	/**
	 * @param resource
	 */
	private void closeScannerResource(Closeable resource) throws IOException {
		
		resource.close();
	}
	
}
