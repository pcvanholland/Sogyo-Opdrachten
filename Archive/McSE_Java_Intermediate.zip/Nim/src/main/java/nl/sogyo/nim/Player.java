/**
 * 
 */
package nl.sogyo.nim;

/**
 * @author rvvugt
 *
 */
public class Player {
	
	private String name;	
	private Player opponent;	
	private boolean toMove;
	private boolean winner = false;
	
	/**
	 * @param name
	 */
	public Player(String name) {
		
		this.name = name;
	}
	
	/**
	 * @param opponent
	 */
	public void setOpponent(Player opponent) {
		
		this.opponent = opponent;
	}
	
	/**
	 * @return
	 */
	public Player getOpponent() {
		
		return this.opponent;
	}
	
	/**
	 * @return
	 */
	public String getName() {
		
		return this.name;
	}
	
	/**
	 * @param toMove
	 */
	void setToMove(boolean toMove) {
		
		this.toMove = toMove;
		
		if (this.opponent.isToMove() == toMove) {
			this.opponent.setToMove(!toMove);
		}
	}
	
	/**
	 * @return
	 */
	public boolean isToMove() {
		
		return this.toMove;
	}
	
	/**
	 * @return
	 */
	public Player getPlayerToMove() {
		
		if (this.isToMove()) {
			return this;
		} else {
			return this.getOpponent();
		}
	}
	
	/**
	 * @param winner
	 */
	void setWinner(boolean winner) {
		
		this.winner = winner;
		
		if (this.opponent.isWinner() == winner) {
			this.opponent.setWinner(!winner);
		}
	}
	
	/**
	 * @return
	 */
	public boolean isWinner() {
		
		return this.winner;
	}
	
	/**
	 * @return
	 */
	public Player getWinner() {
		
		if (this.isWinner()) {
			return this;
		} else if (this.opponent.isWinner()) {
			return this.opponent;
		} else {
			return null;
		}
	}

}
