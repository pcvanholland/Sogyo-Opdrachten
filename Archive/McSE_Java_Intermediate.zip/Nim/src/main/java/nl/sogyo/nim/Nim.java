/**
 * 
 */
package nl.sogyo.nim;

import java.util.Random;

/**
 * @author rvvugt
 *
 */
public class Nim {
	
	private int numberOfMatches;
	private int maxNumberOfMatchesPerTurn;
	private Player player;
	
	/**
	 * @param numberOfMatches
	 * @param maxNumberOfMatchesPerTurn
	 * @param player
	 */
	public Nim(int numberOfMatches, int maxNumberOfMatchesPerTurn) {
		
		this.numberOfMatches = numberOfMatches;
		this.maxNumberOfMatchesPerTurn = maxNumberOfMatchesPerTurn;
		this.initializePlayers();
	}
	
	/**
	 * 
	 */
	private void initializePlayers() {
		
		this.player = new Player("Player1");
		player.setOpponent(new Player("Player2"));
		player.getOpponent().setOpponent(player);
		
		int toMove = new Random().nextInt(2);
		if (toMove != 1) {
			player.setToMove(true);
		} else {
			player.getOpponent().setToMove(true);
		}
	}
	
	/**
	 * @param numberOfMatches
	 * @return
	 */
	public boolean processTurn(int numberOfMatches) {
		
		if (numberOfMatches > this.numberOfMatches) {
			throw new IllegalArgumentException("Not that many matches left.");
		}
		
		if ( !this.isValidNumberOfMatchesTaken(numberOfMatches) ) {
			throw new IllegalArgumentException("Not a valid number of matches taken.");
		}
		
		this.numberOfMatches -= numberOfMatches;
		return this.verifyEndOfGame(this.player.getPlayerToMove());
	}
	
	/**
	 * @param numberOfMatchesTaken
	 * @return
	 */
	public boolean isValidNumberOfMatchesTaken(int numberOfMatchesTaken) {
		
		if (numberOfMatchesTaken <= this.numberOfMatches && numberOfMatchesTaken <= maxNumberOfMatchesPerTurn && numberOfMatchesTaken > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @param player
	 * @return
	 */
	private boolean verifyEndOfGame(Player player) {
		
		if (this.numberOfMatches == 0) {
			player.setWinner(false);
			return true;
		} else {
			player.setToMove(false);
		}
		
		return false;
	}
	
	/**
	 * @return
	 */
	public int getNumberOfMatches() {
		return this.numberOfMatches;
	}

	/**
	 * @return the player
	 */
	public Player getPlayer() {
		
		return player;
	}

}
