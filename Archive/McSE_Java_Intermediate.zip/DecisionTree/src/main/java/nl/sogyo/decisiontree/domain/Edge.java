/**
 * 
 */
package nl.sogyo.decisiontree.domain;

/**
 * @author rvvugt
 *
 */
public class Edge {
	
	private String origin;
	private String destination;
	private boolean yesAnswer;
	
	/**
	 * @param answer
	 * @param message
	 */
	public Edge(String origin, String destination, String yesAnswer) {
		
		this.origin = origin;
		this.destination = destination;
		this.yesAnswer = this.processYesAnswer(yesAnswer);
	}
	
	/**
	 * @param yesAnswer
	 * @return
	 */
	private boolean processYesAnswer(String yesAnswer) {
		
		if ("JA".equalsIgnoreCase(yesAnswer)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @return
	 */
	public String getOrigin() {
		
		return origin;
	}

	/**
	 * @return
	 */
	public String getDestination() {
		
		return destination;
	}

	/**
	 * @return
	 */
	public boolean isYesAnswer() {
		
		return yesAnswer;
	}

}
