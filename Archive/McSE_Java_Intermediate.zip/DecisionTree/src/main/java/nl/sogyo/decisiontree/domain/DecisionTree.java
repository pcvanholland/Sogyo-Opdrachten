/**
 * 
 */
package nl.sogyo.decisiontree.domain;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import nl.sogyo.decisiontree.persistence.IDecisionTreeRepository;

/**
 * @author rvvugt
 *
 */
public class DecisionTree {

	private Node rootNode;
	
	public DecisionTree(IDecisionTreeRepository repository) {
		
		try {
			repository.connect();
			this.initialize(repository.getNodes(), repository.getEdges());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
			throw new InstantiationError("Error creating decision tree.");
		}
	}
	
	/**
	 * @param nodes
	 * @param edges
	 */
	private void initialize(Map<String, Node> nodes, List<Edge> edges) {
		
		Node lastNodeProcessed = null;
		
		for (Edge edge: edges) {
			Node origin = nodes.get(edge.getOrigin());
			Node destination = nodes.get(edge.getDestination());
			boolean isYesAnswer = edge.isYesAnswer();
			
			processOriginDestinationRelation(origin, destination, isYesAnswer);
			lastNodeProcessed = origin;
		}
		
		this.processRootNode(lastNodeProcessed);
	}

	/**
	 * @param origin
	 * @param destination
	 * @param isYesAnswer
	 */
	private void processOriginDestinationRelation(Node origin, Node destination, boolean isYesAnswer) {
		
		if (isYesAnswer) {
			origin.setYesNode(destination);
		} else {
			origin.setNoNode(destination);
		}
		destination.setParent(origin);
	}
	
	/**
	 * @param node
	 */
	private void processRootNode(Node node) {
		
		Node currentNode = node;
		while (currentNode.hasParent()) {
			currentNode = currentNode.getParent();
		}
		
		this.rootNode = currentNode;
	}
	
	/**
	 * @return
	 */
	public Node getRootNode() {
		
		return this.rootNode;
	}
	
}
