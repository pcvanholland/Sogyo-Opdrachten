/**
 * 
 */
package nl.sogyo.decisiontree.domain;

/**
 * @author rvvugt
 *
 */
public class Node {
	
	private String id;
	private String message;
	
	private Node parent;
	private Node yesNode;
	private Node noNode;
	
	/**
	 * @param id
	 * @param message
	 */
	public Node(String id, String message) {
		
		this.id = id;
		this.message = message;
	}

	/**
	 * @return
	 */
	public String getId() {
		
		return id;
	}

	/**
	 * @return
	 */
	public String getMessage() {
		
		return message;
	}

	/**
	 * @return
	 */
	public Node getParent() {
		
		return parent;
	}

	/**
	 * @param parent
	 */
	void setParent(Node parent) {
		
		this.parent = parent;
	}
	
	/**
	 * @return
	 */
	public boolean hasParent() {
		
		return this.parent != null;
	}

	/**
	 * @return
	 */
	public Node getYesNode() {
		
		return yesNode;
	}

	/**
	 * @param yesNode
	 */
	void setYesNode(Node yesNode) {
		
		this.yesNode = yesNode;
	}

	/**
	 * @return
	 */
	public Node getNoNode() {
		
		return noNode;
	}

	/**
	 * @param noNode
	 */
	void setNoNode(Node noNode) {
		
		this.noNode = noNode;
	}

	/**
	 * @return
	 */
	public boolean isQuestion() {
		
		return !this.isAnswer();
	}
	
	/**
	 * @return
	 */
	public boolean isAnswer() {
		
		if (this.yesNode != null || this.noNode != null) {
			return false;
		} else {
			return true;
		}
	}
	
}
