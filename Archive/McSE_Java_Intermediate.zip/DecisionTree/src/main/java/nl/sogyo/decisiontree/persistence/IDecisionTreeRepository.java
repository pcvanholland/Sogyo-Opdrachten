/**
 * 
 */
package nl.sogyo.decisiontree.persistence;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import nl.sogyo.decisiontree.domain.Edge;
import nl.sogyo.decisiontree.domain.Node;

/**
 * @author rvvugt
 *
 */
public interface IDecisionTreeRepository {
	
	/**
	 * @throws IOException
	 */
	public void connect() throws IOException;
	
	/**
	 * @return
	 */
	public Map<String, Node> getNodes();
	
	/**
	 * @return
	 */
	public List<Edge> getEdges();
	
}
