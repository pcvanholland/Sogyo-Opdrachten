/**
 * 
 */
package nl.sogyo.decisiontree.client;

import java.io.IOException;

import nl.sogyo.decisiontree.domain.DecisionTree;
import nl.sogyo.decisiontree.persistence.DecisionTreeFileProcessor;
import nl.sogyo.decisiontree.persistence.IDecisionTreeRepository;

/**
 * @author rvvugt
 *
 */
public class Client {
	
	// See:
	//	- https://www.usna.edu/Users/cs/aviv/classes/ic312/f16/units/04/unit.html
	//	- https://www.edureka.co/blog/decision-trees/
	//	- https://cgi.csc.liv.ac.uk/~frans/OldLectures/COMP101/AdditionalStuff/javaDecTree.html
	
	private static final String TREEDATA_FILENAME = "decision-tree-data.txt";
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {
		
		IDecisionTreeRepository repository = new DecisionTreeFileProcessor(Client.TREEDATA_FILENAME);
		DecisionTree decisionTree = new DecisionTree(repository);
		repository = null;
		new UserInteractionProcessor().executeDecisionTree(decisionTree);
	}
	
}
