/**
 * 
 */
package nl.sogyo.decisiontree.persistence;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import nl.sogyo.decisiontree.domain.Edge;
import nl.sogyo.decisiontree.domain.Node;

/**
 * @author rvvugt
 *
 */
public class DecisionTreeFileProcessor implements IDecisionTreeRepository {
	
	private String filename;
	private Map<String, Node> nodes = new Hashtable<String, Node>();
	private List<Edge> edges = new ArrayList<Edge>();
	
	/**
	 * @param filename
	 */
	public DecisionTreeFileProcessor(String filename) {
		
		this.filename = filename;
	}
	
	@Override
	public void connect() throws IOException {
		
		this.processFile(this.getFile(this.filename));
	}
	
	/**
	 * @param filename
	 * @return
	 */
	private File getFile(String filename) {
		
		ClassLoader classLoader = this.getClass().getClassLoader();
		File file = new File(classLoader.getResource(filename).getFile());
		
		return file;
	}
	
	/**
	 * @param file
	 * @return
	 * @throws IOException
	 */
	private void processFile(File file) throws IOException {
		
		Scanner scanner = new Scanner(file);
		
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			this.processLine(line);
		}

		scanner.close();
	}
	
	private void processLine(String line) {
		
		String[] lineElements = line.split(",");
		if (lineElements.length == 2) {
			this.nodes.put(lineElements[0].trim(), new Node(lineElements[0].trim(), lineElements[1].trim()));
		} else if (lineElements.length == 3) {
			this.edges.add(new Edge(lineElements[0].trim(), lineElements[1].trim(), lineElements[2].trim()));
		}
	}

	@Override
	public Map<String, Node> getNodes() {
		
		return nodes;
	}

	@Override
	public List<Edge> getEdges() {
		
		return edges;
	}

}
