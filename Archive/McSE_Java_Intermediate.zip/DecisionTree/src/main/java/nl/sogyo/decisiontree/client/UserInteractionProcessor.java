/**
 * 
 */
package nl.sogyo.decisiontree.client;

import java.io.Closeable;
import java.io.IOException;
import java.util.Scanner;

import nl.sogyo.decisiontree.domain.DecisionTree;
import nl.sogyo.decisiontree.domain.Node;

/**
 * @author rvvugt
 *
 */
public class UserInteractionProcessor {
	
	private Scanner scanner;
	
	/**
	 * @param decisionTree
	 * @throws IOException
	 */
	public void executeDecisionTree(DecisionTree decisionTree) throws IOException {
		
		Node rootNode = decisionTree.getRootNode();
		
		System.out.println("Give answers with 'J' or 'N'.");
		System.out.println("");
		this.scanner = new Scanner(System.in);
		
		Node currentNode = rootNode;
		while (currentNode.isQuestion()) {
			String input = this.askQuestion(currentNode.getMessage());
			currentNode = this.processInputAnswer(input, currentNode);
		}
		
		if (currentNode.isAnswer()) {
			this.displayAnswer(currentNode.getMessage());
		}
		
		((Closeable) this.scanner).close();
	}
	
	/**
	 * @param input
	 * @param currentNode
	 * @return
	 */
	private Node processInputAnswer(String input, Node currentNode) {
		
		if ("J".equalsIgnoreCase(input)) {
			return currentNode.getYesNode();
		} else if ("N".equalsIgnoreCase(input)) {
			return currentNode.getNoNode();
		} else {
			System.out.println("Invalid answer given. Please try again.");
			return currentNode;
		}
	}

	/**
	 * @param message
	 * @return
	 * @throws IOException
	 */
	private String askQuestion(String message) throws IOException {
		
		String input = "";
		
		System.out.print(message + " ");
       	input = (scanner.nextLine()).trim();
		
        return input;
	}
	
	/**
	 * @param message
	 */
	private void displayAnswer(String message) {
		
		System.out.println("");
		System.out.println("The answer is: " + message);
	}
	
}
