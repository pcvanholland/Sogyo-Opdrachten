/**
 * 
 */
package nl.sogyo.quotes;

import java.time.LocalDate;
import java.util.Random;

/**
 * @author rvvugt
 *
 */
public class Quote {

	String[][] quotes = {
		{"galileo", "eppur si muove"},
		{"archimedes", "eureka!"},
		{"erasmus", "in regione caecorum rex est luscus"},
		{"socrates", "I know nothing except the fact of my ignorance"},
		{"ren� descartes", "cogito, ergo sum"},
		{"sir isaac newton", "if I have seen further it is by standing on the shoulders of giants"}
	};
	
	/**
	 * 
	 */
	public Quote() {
		
	}
	
	/**
	 * @param quotes
	 */
	public Quote(String[][] quotes) {
		this.quotes = quotes;
	}
	
	/**
	 * @return
	 */
	public String[] getRandomQuote() {
		
		int index = new Random().nextInt(quotes.length);
		return this.formatQuote(quotes[index]);
	}
	
	/**
	 * @param quote
	 * @return
	 */
	private String[] formatQuote(String[] quote) {
		
		String quotee = this.formatQuotee(quote[0]);
		String resultQuote = this.formatResultQuote(quote[1]);
		
		
		return new String[] {quotee.trim(), resultQuote.trim()};
	}
	
	/**
	 * @param quotee
	 * @return
	 */
	private String formatQuotee(String quotee) {
		
		StringBuffer sb = new StringBuffer();
		String[] quoteeWords = quotee.split(" ");
		for (String word: quoteeWords) {
			sb.append(word.replaceFirst("" + word.charAt(0), ("" + word.charAt(0)).toUpperCase()));
			sb.append(" ");
		}
		
		return sb.toString().trim();
	}
	
	/**
	 * @param resultQuote
	 * @return
	 */
	private String formatResultQuote(String resultQuote) {
		
		resultQuote = resultQuote.replaceFirst("" + resultQuote.charAt(0), ("" + resultQuote.charAt(0)).toUpperCase());
		if ( !(resultQuote.endsWith("!") || resultQuote.endsWith("?") || resultQuote.endsWith(".")) ) {
			resultQuote = resultQuote + ".";
		}
		
		return resultQuote;
	}
	
	/**
	 * 
	 */
	public void quoteOfTheDay() {
		
		String[] resultQuote = this.getRandomQuote();
		
		System.out.println(this.formateDateString(LocalDate.now()));		
		System.out.println("\"" + resultQuote[1] + "\" -- " + resultQuote[0]);
	}
	
	/**
	 * @param date
	 * @return
	 */
	private String formateDateString(LocalDate date) {
		
		LocalDate workingDate = date;
		String dayOfWeek = ("" + workingDate.getDayOfWeek()).toLowerCase();
		dayOfWeek = dayOfWeek.replaceFirst("" + dayOfWeek.charAt(0), ("" + dayOfWeek.charAt(0)).toUpperCase());
		String dayOfMonth = "" + workingDate.getDayOfMonth();
		String monthOfYear = ("" + workingDate.getMonth()).toLowerCase();
		monthOfYear = monthOfYear.replaceFirst("" + monthOfYear.charAt(0), ("" + monthOfYear.charAt(0)).toUpperCase());
		
		return ("Quote for " + dayOfWeek + " the " + dayOfMonth + "th of " + monthOfYear + ":");
	}
	
}
