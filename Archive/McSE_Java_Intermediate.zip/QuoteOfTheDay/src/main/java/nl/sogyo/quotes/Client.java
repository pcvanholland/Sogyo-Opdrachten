/**
 * 
 */
package nl.sogyo.quotes;


/**
 * @author rvvugt
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Quote quote = new Quote();
		quote.quoteOfTheDay();
	}

}
