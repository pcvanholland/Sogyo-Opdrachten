/**
 * 
 */
package nl.sogyo.quotes;

import static org.junit.Assert.*;

import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.Month;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class QuoteTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void quoteFormatTest1() {

		Quote quote = new Quote(new String[][] {{"archimedes", "eureka!"}});
		String[] resultQuote = quote.getRandomQuote();
		
		assertTrue(resultQuote[1].startsWith("E"));
		assertTrue(resultQuote[1].endsWith("!"));
		
		assertTrue(resultQuote[0].startsWith("A"));
		assertTrue(resultQuote[0].endsWith("s"));
	}

	@Test
	public void quoteFormatTest2() {

		Quote quote = new Quote(new String[][] {{"ren� descartes", "cogito, ergo sum"}});
		String[] resultQuote = quote.getRandomQuote();
		
		assertTrue(resultQuote[1].startsWith("C"));
		assertTrue(resultQuote[1].endsWith("."));
		
		assertTrue(resultQuote[0].startsWith("R"));
		assertTrue(resultQuote[0].charAt(5) == 'D');
		assertTrue(resultQuote[0].endsWith("s"));
	}
	
	@Test
	public void formatDateStringTest() {

		String dateString = "";
		Quote quote = new Quote();

		Class[] args = new Class[1];
        args[0] = LocalDate.class;
		try {
	        Method method = Quote.class.getDeclaredMethod("formateDateString", args);
			method.setAccessible(true);
			
			Object result = method.invoke(quote, new Object[] {LocalDate.of(2017, Month.SEPTEMBER, 11)});

			dateString = (String) result;
		} catch (Exception e) {
			fail("Better luck next time!");
		}
		
		assertEquals("Quote for Monday the 11th of September:", dateString);
	}
	
}
