/**
 * 
 */
package nl.sogyo.csvparser;

import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class CSVFileProcessorTest {

	private static final String CSV_FILENAME = "csv-parser.csv";
	private static final String RESULT_FILENAME = "result.csv";
	private String sourceFile;
	private String destinationFile;
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		
		ClassLoader cl = this.getClass().getClassLoader();
		this.sourceFile = cl.getResource(CSVFileProcessorTest.CSV_FILENAME).getPath();
		this.destinationFile = this.sourceFile.replaceFirst(CSVFileProcessorTest.CSV_FILENAME, CSVFileProcessorTest.RESULT_FILENAME);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		
		File file = new File(this.destinationFile);
		file.delete();
	}

	@Test
	public void replaceAgeTest() {
		
		// This is not really a unit test, but more an integration test.
		// Integrating functional code with external resources like files on the filesystem.
		
		new CSVFileProcessor(this.sourceFile, this.destinationFile, "Age", "100");
		
		String line = "";
		boolean firstLine = true;
		
		try (BufferedReader reader = new BufferedReader(new FileReader(this.destinationFile))) {
			
			while ((line = reader.readLine()) != null) {
				if (firstLine) {
					firstLine = false;
					continue;
				}
				String[] items = line.split(",");
				assertTrue("100".equalsIgnoreCase(items[2]));
			}
		} catch (IOException ioe) {
			System.out.println("Error reading file!");
		}
	}

	@Test
	public void replaceCiryTest() {
		
		// This is not really a unit test, but more an integration test.
		// Integrating functional code with external resources like files on the filesystem.
		
		new CSVFileProcessor(this.sourceFile, this.destinationFile, "City", "Lutjebroek");
		
		String line = "";
		boolean firstLine = true;
		
		try (BufferedReader reader = new BufferedReader(new FileReader(this.destinationFile))) {
			
			while ((line = reader.readLine()) != null) {
				if (firstLine) {
					firstLine = false;
					continue;
				}
				String[] items = line.split(",");
				assertTrue("Lutjebroek".equalsIgnoreCase(items[3]));
			}
		} catch (IOException ioe) {
			System.out.println("Error reading file!");
		}
	}

}
