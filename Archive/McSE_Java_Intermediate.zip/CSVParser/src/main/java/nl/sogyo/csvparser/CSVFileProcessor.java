/**
 * 
 */
package nl.sogyo.csvparser;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author rvvugt
 * 
 * @see https://www.hangmanwords.com/words
 */
public class CSVFileProcessor {
	
	private File sourceFile;
	private File destinationFile;
	private String columnName;
	private int columnIndex;
	private String replacementValue;
	
	/**
	 * @param sourceFilename
	 * @param destinationFilename
	 * @param columnName
	 * @param replacementValue
	 */
	public CSVFileProcessor(String sourceFilename, String destinationFilename, String columnName, String replacementValue) {
		
		this.columnName = columnName;
		this.replacementValue = replacementValue;
		this.sourceFile = new File(sourceFilename);
		this.destinationFile = new File(destinationFilename);
		
		this.processSource2DestinationFile();
	}
	
	/**
	 * 
	 */
	private void processSource2DestinationFile() {
		
		String line = "";
		boolean firstLine = true;
		
		try (BufferedReader reader = new BufferedReader(new FileReader(this.sourceFile))) {
		
			while ((line = reader.readLine()) != null) {
				String newLine = this.processLine(line, firstLine);
				this.writeLineToFile(newLine);
				firstLine = false;
			}
		} catch (IOException ioe) {
			System.out.println("Error reading file!");
		}
	}
	
	/**
	 * @param line
	 * @param firstLine
	 * @return
	 */
	private String processLine(String line, boolean firstLine) {
		
		StringBuffer resultLine = new StringBuffer();
		String[] columns = line.split(",");
		
		if (firstLine) {
			this.processReplacementColumnIndex(columns);
		} else {
			columns[this.columnIndex] = this.replacementValue;
		}
		
		for (String column : columns) {
			resultLine.append(column);
			resultLine.append(",");
		}
		resultLine.deleteCharAt(resultLine.length()-1);
		
		return resultLine.toString();
	}
	
	/**
	 * @param columns
	 */
	private void processReplacementColumnIndex(String[] columns) {
		
		int index = 0;
		
		for (String column : columns) {
			if ( column.trim().equalsIgnoreCase(this.columnName.trim()) ) {
				this.columnIndex = index;
				break;
			} else {
				index++;
			}
		}
	}
	
	/**
	 * @param line
	 */
	private void writeLineToFile(String line) {
		
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(this.destinationFile, true))) {
			
			writer.write(line);
			writer.newLine();
		} catch (IOException ioe) {
			System.out.println("Error reading file!");
		}
	}
	
}
