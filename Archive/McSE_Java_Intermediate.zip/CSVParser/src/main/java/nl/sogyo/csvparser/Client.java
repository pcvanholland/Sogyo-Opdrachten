/**
 * 
 */
package nl.sogyo.csvparser;

/**
 * @author rvvugt
 *
 */
public class Client {
	
	/* RUN CONFIGURATIONS FOR TESTING!
	 * 
	 * (you can use the "csv-parser.csv" out of the "src/test/resources" folder)
	 * 
	 * ==> c:/testfile/csv-parser.csv c:/testfile/result.csv Age 100
	 * ==> c:/testfile/csv-parser.csv c:/testfile/result.csv City "st. Lutjebroek"
	 * 
	 * OpenCSV:
	 * For more complex CSV processing you can use OpenCSV: http://opencsv.sourceforge.net/
	*/
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		if (args.length != 4) {
			System.out.println("Invalid number of arguments!");
			System.out.println();
			System.out.println("Run with arguments: [sourcefile] [destinationfile] [column_name] [replacement_value]");
			System.exit(0);
		}
		
		new CSVFileProcessor(args[0], args[1], args[2], args[3]);
		System.out.println("Processing DONE!");
	}
	
}
