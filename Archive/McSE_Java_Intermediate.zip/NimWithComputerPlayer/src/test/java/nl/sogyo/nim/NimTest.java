/**
 * 
 */
package nl.sogyo.nim;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rvvugt
 *
 */
public class NimTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void player1WonTest() {
		
		Nim nim = new Nim(11, 4, 2);
		Player player = nim.getPlayer();
		player.setToMove(true);
		
		nim.processTurn(4); // Player 1
		nim.processTurn(4);
		nim.processTurn(2); // Player 1
		nim.processTurn(1);
		
		assertTrue(player.isWinner());
	}

	@Test
	public void player2WonTest() {
		
		Nim nim = new Nim(11, 4, 2);
		Player player = nim.getPlayer();
		player.setToMove(true);
		
		nim.processTurn(4); // Player 1
		nim.processTurn(3);
		nim.processTurn(2); // Player 1
		nim.processTurn(1);
		nim.processTurn(1); // Player 1
		
		assertTrue(player.getOpponent().isWinner());
	}

	@Test
	public void validNumberOfMatchesTest() {
		
		Nim nim = new Nim(11, 4, 2);
		Player player = nim.getPlayer();
		player.setToMove(true);
		
		try {
			nim.processTurn(5);
			fail("Illegal number of matches taken");
		} catch (Exception e) {
			
		}
	}

	@Test
	public void notEnoughMatchesLeftTest() {
		
		Nim nim = new Nim(11, 4, 2);
		Player player = nim.getPlayer();
		player.setToMove(true);
		
		nim.processTurn(4); // Player 1
		nim.processTurn(4);
		try {
			nim.processTurn(4); // Player 1
			fail("Illegal number of matches taken");
		} catch (Exception e) {
			
		}
	}

	@Test
	public void humanPlayerWonTest() {
		
		Nim nim = new Nim(11, 4, 1);
		Player player = nim.getPlayer();
		player.setToMove(true);
		
		nim.processTurn(4);
		nim.processTurn(1); // ComputerPlayer
		nim.processTurn(3);
		nim.processTurn(1); // ComputerPlayer
		nim.processTurn(1);
		nim.processTurn(1); // ComputerPlayer
		
		assertTrue(player.isWinner());
	}

	@Test
	public void ComputerPlayerWonTest() {
		
		Nim nim = new Nim(11, 4, 1);
		Player player = nim.getPlayer();
		player.setToMove(true);
		
		nim.processTurn(4);
		nim.processTurn(1); // ComputerPlayer
		nim.processTurn(4);
		nim.processTurn(1); // ComputerPlayer
		nim.processTurn(1);
		
		assertTrue(player.getOpponent().isWinner());
	}

}
