/**
 * 
 */
package nl.sogyo.nim;

import java.util.Random;

/**
 * @author rvvugt
 *
 */
public class Nim {
	
	private int numberOfMatches;
	private int maxNumberOfMatchesPerTurn;
	private Player player;
	
	/**
	 * @param numberOfMatches
	 * @param maxNumberOfMatchesPerTurn
	 * @param player
	 */
	public Nim(int numberOfMatches, int maxNumberOfMatchesPerTurn, int numberOfPlayers) {
		
		this.numberOfMatches = numberOfMatches;
		this.maxNumberOfMatchesPerTurn = maxNumberOfMatchesPerTurn;
		this.initializePlayers(numberOfPlayers);
	}
	
	/**
	 * 
	 */
	private void initializePlayers(int numberOfPlayers) {
		
		if (numberOfPlayers == 1) {
			this.player = new Player("HumanPlayer");
			player.setOpponent(new ComputerPlayer("ComputerPlayer"));
		} else if (numberOfPlayers == 2) {
			this.player = new Player("Player1");
			player.setOpponent(new Player("Player2"));
		}
		player.getOpponent().setOpponent(player);
		
		int toMove = new Random().nextInt(2);
		if (toMove != 1) {
			player.setToMove(true);
		} else {
			player.getOpponent().setToMove(true);
		}
	}
	
	/**
	 * @param numberOfMatches
	 * @return
	 */
	public boolean processTurn(int numberOfMatches) {
		
		if (numberOfMatches > this.numberOfMatches) {
			throw new IllegalArgumentException("Not that many matches left.");
		}
		
		if ( !this.isValidNumberOfMatchesTaken(numberOfMatches) ) {
			throw new IllegalArgumentException("Not a valid number of matches taken.");
		}
		
		this.numberOfMatches -= numberOfMatches;
		return this.verifyEndOfGame(this.player.getPlayerToMove());
	}

	// For assignment 2
//	/**
//	 * @param numberOfMatchesTaken
//	 * @return
//	 */
//	public boolean isValidNumberOfMatchesTaken(int numberOfMatchesTaken) {
//		
//		if (player.getPlayerToMove() instanceof ComputerPlayer) {
//			return numberOfMatchesTaken == 1;
//		} else if (numberOfMatchesTaken <= this.numberOfMatches && numberOfMatchesTaken <= maxNumberOfMatchesPerTurn && numberOfMatchesTaken > 0) {
//			return true;
//		} else {
//			return false;
//		}
//	}
	
	// For assignment 3
	/**
	 * @param numberOfMatchesTaken
	 * @return
	 */
	public boolean isValidNumberOfMatchesTaken(int numberOfMatchesTaken) {
		
		if (numberOfMatchesTaken <= this.numberOfMatches && numberOfMatchesTaken <= maxNumberOfMatchesPerTurn && numberOfMatchesTaken > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @param player
	 * @return
	 */
	private boolean verifyEndOfGame(Player player) {
		
		if (this.numberOfMatches == 0) {
			player.setWinner(false);
			return true;
		} else {
			player.setToMove(false);
		}
		
		return false;
	}
	
	/**
	 * @return
	 */
	public int getNumberOfMatches() {
		return this.numberOfMatches;
	}

	/**
	 * @return the player
	 */
	public Player getPlayer() {
		
		return player;
	}

}
