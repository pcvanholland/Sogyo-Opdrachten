/**
 * 
 */
package nl.sogyo.nim;

import java.io.BufferedReader;
import java.io.IOException;

/**
 * @author rvvugt
 *
 */
public class UserInteractionProcessor {
	
    private BufferedReader bufferedReader;
    private int maxNumberOfMatchesPerTurn;
    
    /**
     * @param br
     */
    public UserInteractionProcessor(BufferedReader bufferedReader, int maxNumberOfMatchesPerTurn) {
    	
    	this.bufferedReader = bufferedReader;
    	this.maxNumberOfMatchesPerTurn = maxNumberOfMatchesPerTurn;
    }
    
    /**
     * @param maxNumberToTake
     */
    public void printInitializationMsg(int maxNumberToTake) {
    	
		System.out.println("This is Nim!");
		System.out.println("The max amount of matches you can take is " + maxNumberToTake);
		System.out.println("Press 'Q' to quite the game");
		System.out.println();
    }
    
	/**
	 * @return
	 */
	public int readNumberOfPlayers() {
		
		int numberOfPlayers = 0;
		System.out.print("Will this be a 1 or 2 player game: ");
		
		do {
			try {
				numberOfPlayers = Integer.parseInt(bufferedReader.readLine());
			} catch (Exception e) {
				System.out.println("Invalid Format!");
				System.out.print("Please try again: ");
				continue;
			}
			
			if (numberOfPlayers < 1 | numberOfPlayers > 2) {
				System.out.println("Invalid number of Players. Should be 1 or 2.");
				System.out.print("Please try again: ");
			}
		} while ( !(numberOfPlayers > 0 & numberOfPlayers <= 2) );
		
		System.out.println("");
		
        return numberOfPlayers;
	}
	
	/**
	 * @return
	 */
	public int readInput(Player playerToMove, int numberOfMatchesLeft) {
		
		System.out.println("Next turn is for " + playerToMove.getName());
		
		if (playerToMove instanceof ComputerPlayer) { 
			return this.readComputerInput((ComputerPlayer) playerToMove, numberOfMatchesLeft);
		} else {
			return this.readHumanInput();
		}
	}
	
	/**
	 * @return
	 */
	private int readHumanInput() {
		
		char input = 'Q';
		boolean validInput = false;
		
		do {
	        try {
	    		System.out.print("How many do you want to take?: ");
	        	input = this.bufferedReader.readLine().charAt(0);
	        	validInput = this.validateInput(input);
	        } catch(IOException e) {
				System.out.println();
				System.err.println("Invalid Input! Please try again.");
				System.out.println();
	        } 
		} while ( !validInput );
		System.out.println();
		
		if ( input == 'Q' ) {
			System.err.println("Thank you for playing. Please come again!");
			System.exit(0);
		}
		
        return Character.getNumericValue(input);
	}
	
	/**
	 * @param input
	 * @return
	 */
	private boolean validateInput(char input) {
		
		int inputNumber = Character.getNumericValue(input);
		
		if (input == 'Q') {
			return true;
		} else if (inputNumber >= 0 && inputNumber <= this.maxNumberOfMatchesPerTurn) {
			return true;
		} else if (inputNumber != -1) {
			this.printInvalidNumberOfMatchesMsg();
			return false;
		} else {
			return false;
		}
	}

	/**
	 * @param player
	 * @param numberOfMatchesLeft
	 * @return
	 */
	private int readComputerInput(ComputerPlayer player, int numberOfMatchesLeft) {
		
		// Assignment 2
//		int result = 1;
		
		// Assignment 3
		int result = player.takeStrategicTurn(numberOfMatchesLeft);
		
		System.out.println("How many do you want to take?: " + result);
		System.out.println();
		
        return result;
	}

	/**
	 * @param numberOfMatches
	 */
	public void printNumberOfMatchesMsg(int numberOfMatches) {
		
		System.out.println("There are " + numberOfMatches + " matches.");
	}
	
	/**
	 * 
	 */
	public void printInvalidNumberOfMatchesMsg() {
		
		System.out.println();
		System.out.println("Invalid number of matches.");
		System.out.println("Please try again!");
		System.out.println();
	}
	
	/**
	 * @param winner
	 */
	public void printWinner(String winner) {
		
		System.out.println("Player " + winner + " has WON!");
	}

}
