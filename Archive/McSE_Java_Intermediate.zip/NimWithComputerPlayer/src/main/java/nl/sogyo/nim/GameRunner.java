/**
 * 
 */
package nl.sogyo.nim;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author rvvugt
 *
 */
public class GameRunner {
	
	private Nim nim;
    private BufferedReader bufferedReader;
    private UserInteractionProcessor userInteractionProcessor;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		GameRunner gameRunner = new GameRunner();
		gameRunner.initialize();
		gameRunner.play();
	}

	/**
	 * 
	 */
	private void initialize() {
		
		int numberOfMatches = 11;
		int maxNumberOfMatchesPerTurn = 4;
		
	    this.bufferedReader = this.openBufferedReaderResource();
		this.userInteractionProcessor = new UserInteractionProcessor(bufferedReader, maxNumberOfMatchesPerTurn);

		this.userInteractionProcessor.printInitializationMsg(maxNumberOfMatchesPerTurn);
		this.nim = new Nim(numberOfMatches, maxNumberOfMatchesPerTurn, this.userInteractionProcessor.readNumberOfPlayers());
		
		this.userInteractionProcessor.printNumberOfMatchesMsg(nim.getNumberOfMatches());
	}
	
	/**
	 * 
	 */
	private void play() {
		
		int numberOfMatchesTaken;
		boolean endOfGame = false;
		
		do {
			numberOfMatchesTaken = this.userInteractionProcessor.readInput(this.nim.getPlayer().getPlayerToMove(), this.nim.getNumberOfMatches());
			if ( !nim.isValidNumberOfMatchesTaken(numberOfMatchesTaken) ) {
				this.userInteractionProcessor.printInvalidNumberOfMatchesMsg();
				continue;
			}
			endOfGame = this.nim.processTurn(numberOfMatchesTaken);
			
			this.userInteractionProcessor.printNumberOfMatchesMsg(nim.getNumberOfMatches());
			
		} while ( !endOfGame );
		
		this.userInteractionProcessor.printWinner(this.nim.getPlayer().getWinner().getName());
		
        try {
        	this.closeBufferedReaderResource(this.bufferedReader);
        } catch ( IOException ioe ) {
        	System.err.println(ioe.getMessage());
        }
	}
	
	/**
	 * @return
	 */
	private BufferedReader openBufferedReaderResource() {
		
		return new BufferedReader(new InputStreamReader(System.in));
	}
	
	/**
	 * @param resource
	 */
	private void closeBufferedReaderResource(Closeable resource) throws IOException {
		
		resource.close();
	}
	
}
