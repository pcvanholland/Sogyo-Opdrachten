/**
 * 
 */
package nl.sogyo.nim;

/**
 * @author rvvugt
 *
 */
public class ComputerPlayer extends Player {

	/**
	 * @param name
	 */
	public ComputerPlayer(String name) {
		
		super(name);
	}
	
	/**
	 * @param numberOfMatchesLeft
	 * @return
	 */
	int takeStrategicTurn(int numberOfMatchesLeft) {
		
		int result;
		
		if (numberOfMatchesLeft == 5) {
			result = 4;
		} else if (numberOfMatchesLeft > 1 & numberOfMatchesLeft < 5) {
			result = numberOfMatchesLeft -1;
		} else {
			result = 1;
		}
		
		return result;
	}
	
}
