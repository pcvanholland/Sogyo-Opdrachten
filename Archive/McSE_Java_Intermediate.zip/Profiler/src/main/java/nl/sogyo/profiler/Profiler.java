/**
 * 
 */
package nl.sogyo.profiler;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author rvvugt
 *
 */
public class Profiler {
	
	private Dictionary<String, Profile> readerProfiles;
	private Dictionary<String, Set<String>> bookProfiles = new Hashtable<String, Set<String>>();
	private String filename;
	
	/**
	 * @param filename
	 */
	public Profiler(String filename) throws InstantiationException {
		
		this.filename = filename;
		this.initializeReaderProfiles();
		this.initializeBookProfiles();
	}
	
	/**
	 * @throws InstantiationException
	 */
	private void initializeReaderProfiles() throws InstantiationException {
		
		try {
			FileProcessor fileProcessor = new FileProcessor();
			File profileDataFile = fileProcessor.getFile(this.filename);
			readerProfiles = fileProcessor.processFileToProfiles(profileDataFile);
		} catch (IOException ioe) {
			throw new InstantiationException("Error reading profiledata.");
		}
	}
	
	/**
	 * @throws InstantiationException
	 */
	private void initializeBookProfiles() {
		
		Profile readerProfile = null;
		Enumeration<String> keys = this.readerProfiles.keys();
		while (keys.hasMoreElements()) {
			String readerKey = keys.nextElement();
			readerProfile = this.readerProfiles.get(readerKey);
			this.addToBookProfile(readerProfile);
		}
	}
	
	/**
	 * @param readerProfile
	 */
	private void addToBookProfile(Profile readerProfile) {
		
		for (String bookTitle: readerProfile.getBookTitles()) {
			Set<String> bookReaders = this.bookProfiles.get(bookTitle);
			if (bookReaders != null) {
				bookReaders.add(readerProfile.getName());
			} else {
				bookReaders = new TreeSet<String>();
				bookReaders.add(readerProfile.getName());
				this.bookProfiles.put(bookTitle, bookReaders);
			}
		}
	}
	
	/**
	 * @param key
	 * @return
	 */
	public Profile getProfile(String key) {
		
		Profile profile = null;
		profile = this.readerProfiles.get(key);
		
		return profile;
	}
	
	/**
	 * @param partialName
	 * @return
	 */
	public List<Profile> getProfileByPartialName(String partialName) {
		
		List<Profile> profilesFound = new ArrayList<Profile>();
		
		Enumeration<String> keys = this.readerProfiles.keys();
		while (keys.hasMoreElements()) {
			String readerKey = keys.nextElement();
			if (readerKey.contains(partialName)) {
				profilesFound.add(this.readerProfiles.get(readerKey));
			}
		}
		
		return profilesFound;
	}
	
	/**
	 * @param bookTitle
	 * @return
	 */
	public Set<String> getReaders(String bookTitle) {
		
		return this.bookProfiles.get(bookTitle);
	}
	
	/**
	 * @param name
	 * @return
	 * @throws NotFoundException
	 */
	public Set<String> makeReadingSuggestion(String name) throws NotFoundException {
		
		Profile clientProfile = this.readerProfiles.get(name);
		if (clientProfile == null) {
			throw new NotFoundException("We could not find a profile for this name.");
		}
		
		Set<String> suggestions = new TreeSet<String>();
		Set<Profile> suggestedProfiles = this.selectAppropriateProfiles(clientProfile);
		
		for (Profile profile: suggestedProfiles) {
			suggestions.addAll(Arrays.asList(profile.getBookTitles()));
		}
		suggestions.removeAll(Arrays.asList(clientProfile.getBookTitles()));
		
		return suggestions;
	}
	
	/**
	 * @param clientProfile
	 * @param suggestedProfiles
	 */
	private Set<Profile> selectAppropriateProfiles(Profile clientProfile) {
		
		Set<Profile> suggestedProfiles = new TreeSet<Profile>();
		Comparator<Profile> suggestionsComparator = new SuggestionsComparator();
		
		Enumeration<String> keys = this.readerProfiles.keys();
		while (keys.hasMoreElements()) {
			String key  = keys.nextElement();
			Profile suggestion = this.readerProfiles.get(key);
			int suggestionResult = suggestionsComparator.compare(clientProfile, suggestion);
			if (suggestionResult >= 3) {
				suggestedProfiles.add(suggestion);
			}
		}
		
		return suggestedProfiles;
	}
	
}
