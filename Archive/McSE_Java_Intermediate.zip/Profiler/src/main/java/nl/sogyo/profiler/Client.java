/**
 * 
 */
package nl.sogyo.profiler;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

/**
 * @author rvvugt
 *
 */
public class Client {

	private static final String PROFILEDATE_FILENAME = "profiling-data.txt";
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		
		Client client = new Client();
		Profiler profiler = new Profiler(Client.PROFILEDATE_FILENAME);
		
		// Assignment 1
//		FileProcessor fileProcessor = new FileProcessor();
//		File file = fileProcessor.getFile(Client.PROFILEDATE_FILENAME);
//		for (String line: fileProcessor.processFile(file)) {
//			System.out.println(line);
//		}
		
		// Assignment 4
//		String name = client.readPersontName();
//		Profile profile = profiler.getProfile(name);
//		client.printProfile(name, profile);
		
		// Assignment 5
//		String name = client.readPersontName();
//		List<Profile> profiles = profiler.getProfileByPartialName(name);
//		client.printFoundProfiles(name, profiles);
		
		// Assignment 6
//		String bookTitle = client.readBookTitle();
//		Set<String> readers = profiler.getReaders(bookTitle);
//		client.printReaders(bookTitle, readers);
		
		// Assignment 7
		String name = client.readPersontName();
		try {
			Set<String> bookSuggestions = profiler.makeReadingSuggestion(name);
			client.printReadingSuggestions(name, bookSuggestions);
		} catch (NotFoundException nfe) {
			System.out.println("Sorry \"" + name + "\": " + nfe.getMessage());
		}
	}

	/**
	 * @return
	 */
	private String readPersontName() throws IOException {
		
		System.out.print("Enter persons name: ");
        return this.readInput();
	}
	
	/**
	 * @return
	 */
	private String readBookTitle() throws IOException {
		
		System.out.print("Enter book title: ");		
        return this.readInput();
	}
	
	/**
	 * @return
	 */
	private String readInput() throws IOException {
		
		String input = "";
		
		Scanner scanner = new Scanner(System.in);
		Closeable resource = scanner;
        try {
        	input = (scanner.nextLine()).trim();
        } catch (Exception e) {
        	System.err.println("Invalid Format!");
        } finally {
        	resource.close();
        }
		
        return input;
	}
	
	/**
	 * @param name
	 * @param profile
	 */
	private void printProfile(String name, Profile profile) {
		
		System.out.println("");
		System.out.println(name + " has read the following books:");
		if (profile != null) {
			for (String bookTitle: profile.getBookTitles()) {
				System.out.println("\t- " + bookTitle);
			}
		} else {
			System.out.println("\t- NO LISTINGS FOUND");
		}
	}
	
	private void printFoundProfiles(String name, List<Profile> profiles) {
		
		if (profiles == null || profiles.isEmpty()) {
			System.out.println("");
			System.out.println("Based on the input \"" + name + "\", no profiles were found.");
		} else {
			System.out.println("");
			System.out.println("Based on the input \"" + name + "\", the following profiles were found:");
			for (Profile profile: profiles) {
				this.printProfile(profile.getName(), profile);
			}
		}
	}
	
	private void printReaders(String name, Set<String> readers) {
		
		if (readers == null || readers.isEmpty()) {
			System.out.println("");
			System.out.println("The book \"" + name + "\" is not found in out collection.");
		} else {
			System.out.println("");
			System.out.println("\"" + name + "\" is read by the following people:");
			for (String reader: readers) {
				System.out.println("\t- " + reader);
			}
		}
	}
	
	private void printReadingSuggestions(String name, Set<String> readingSuggestions) {
		
		if (readingSuggestions == null || readingSuggestions.isEmpty()) {
			System.out.println("");
			System.out.println("Dear " + name + ", we are sorry to say that there are currently no suggestions for you.");
		} else {
			System.out.println("");
			System.out.println("Dear " + name + ", the following books are suggested to you:");
			for (String suggestions: readingSuggestions) {
				System.out.println("\t- " + suggestions);
			}
		}
	}

}
