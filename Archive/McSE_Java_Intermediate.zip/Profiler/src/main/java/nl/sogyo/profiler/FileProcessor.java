/**
 * 
 */
package nl.sogyo.profiler;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;

/**
 * @author rvvugt
 *
 */
public class FileProcessor {

	/**
	 * @param filename
	 * @return
	 */
	public File getFile(String filename) {
		
		ClassLoader classLoader = this.getClass().getClassLoader();
		File file = new File(classLoader.getResource(filename).getFile());
		
		return file;
	}
	
	/**
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public List<String> processFile(File file) throws IOException {
		
		List<String> result = new ArrayList<String>();
		Scanner scanner = new Scanner(file);
		
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			result.add(line);
		}

		scanner.close();
		return result;
	}
	
	/**
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public Dictionary<String, Profile> processFileToProfiles(File file) throws IOException {
		
		Dictionary<String, Profile> result = new Hashtable<String, Profile>();
		Scanner scanner = new Scanner(file);
		
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			Profile profile = this.processLine(line);
			if (profile != null) {
				result.put(profile.getName(), profile);
			}
		}

		scanner.close();
		return result;
	}
	
	/**
	 * @param line
	 * @return
	 */
	private Profile processLine(String line) {
		
		Profile profile = null;
		String[] lineElements = line.split(",");
		
		if (lineElements.length > 0) {
			
			int index = 0;
			profile = new Profile();
			String name = lineElements[index].replace("  ", " ").trim();
			profile.setName(name);
			index++;
			while (index < lineElements.length) {
				profile.addBook(lineElements[index].trim());
				index++;
			}
		}
		
		return profile;
	}
	
}
