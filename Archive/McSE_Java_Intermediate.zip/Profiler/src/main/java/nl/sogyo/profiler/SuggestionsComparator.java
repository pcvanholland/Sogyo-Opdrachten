/**
 * 
 */
package nl.sogyo.profiler;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author rvvugt
 *
 */
public class SuggestionsComparator implements Comparator<Profile> {
	
	// See: https://docs.oracle.com/javase/tutorial/collections/interfaces/set.html
	
	@Override
	public int compare(Profile profile1, Profile profile2) {
		
		List<String> booklist = Arrays.asList(profile1.getBookTitles());
		Set<String> intersection = new HashSet<String>(booklist);
		intersection.retainAll(Arrays.asList(profile2.getBookTitles()));
		
		return intersection.size();
	}

}
