/**
 * 
 */
package nl.sogyo.profiler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author rvvugt
 *
 */
public class Profile implements Comparable<Profile> {
	
	private String name;
	private List<String> bookTitles = new ArrayList<String>();
	
	/**
	 * @return
	 */
	public String getName() {
		
		return name;
	}
	
	/**
	 * @param name
	 */
	public void setName(String name) {
		
		this.name = name;
	}
	
	/**
	 * @return
	 */
	public String[] getBookTitles() {
		
		return bookTitles.toArray(new String[bookTitles.size()]);
	}
	
	/**
	 * @param bookTitles
	 */
	public void setBookTitles(String[] bookTitles) {
		
		this.bookTitles = Arrays.asList(bookTitles);
	}
	
	/**
	 * @param bookTitle
	 */
	public void addBook(String bookTitle) {
		
		this.bookTitles.add(bookTitle);
	}

	@Override
	public int compareTo(Profile profile) {
		
		// Simple implementation, no ordering no "name"
		String comparableName = profile.getName();
		if (this.name.equalsIgnoreCase(comparableName)) {
			return 0;
		} else {
			return 1;
		}
	}

}
